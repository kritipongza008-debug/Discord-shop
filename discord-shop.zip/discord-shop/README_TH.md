# Discord Shop TH — คู่มือติดตั้งผ่าน Cockpit

บอทขายข้อความจากสต็อก ใช้ Node.js 24 + discord.js 14 + SQLite ในตัว Node
ไม่มีค่า AI/API ตรวจสลิป: เจ้าของร้านตรวจเงินเข้าเองแล้วกดอนุมัติ
รองรับ QR พร้อมเพย์และ TrueMoney แบบโอนเข้าเบอร์ รุ่นนี้ยังไม่รับซองอั่งเปา

## 1. สิ่งที่ต้องเตรียม

- เซิร์ฟเวอร์ Ubuntu 22.04/24.04 หรือ Debian รุ่นใหม่ แบบ x64/ARM64 ที่ใช้ systemd และออกอินเทอร์เน็ตได้
- บัญชี Linux ที่ใช้ sudo ได้ และเข้า Cockpit ได้อยู่แล้ว
- ไม่ต้องเปิดพอร์ตขาเข้าสำหรับบอท บอทเชื่อมต่อ Discord ออกไปเองผ่าน HTTPS/WebSocket
- โทเคนบอทใหม่ที่ Reset แล้ว ห้ามใช้โทเคนที่เคยส่งลงแชต
- เครื่องทดสอบนี้ใช้ Node 24.22.1; ยังไม่ได้ทดสอบกับ Discord จริงหรือเซิร์ฟเวอร์ของคุณ
- สคริปต์ติดตั้งดาวน์โหลด Node 24 รุ่นล่าสุดในสาย 24 จาก nodejs.org ตรวจ SHA256 และติดตั้งเฉพาะแอป ไม่แทน Node ของระบบ
- สคริปต์ไม่ติดตั้ง Cockpit ให้ หากเข้า Cockpit ได้แล้ว ข้ามการติดตั้ง Cockpit ทั้งหมด

## 2. เตรียม Discord

1. เข้า https://discord.com/developers/applications สร้างหรือเลือก Application
2. หน้า Bot กด Reset Token แล้วเก็บ Token ไว้เอง จะใช้ใน .env เท่านั้น
3. หน้า General Information คัดลอก Application ID ใช้เป็น CLIENT_ID
4. หน้า Installation หรือ OAuth2 URL Generator เลือก Guild Install / scopes `bot` และ `applications.commands`
5. ให้บอทมีสิทธิ์ View Channels, Send Messages, Read Message History, Attach Files, Embed Links, Manage Channels และ Manage Roles (Discord ใช้สิทธิ์ Manage Roles สำหรับตั้ง permission overwrites)
6. เปิดลิงก์เชิญและเลือกเซิร์ฟเวอร์ของคุณ ไม่ต้องเปิด privileged intents; โค้ดใช้ Guilds intent อย่างเดียว
7. ใน Discord เปิด User Settings → Advanced → Developer Mode เพื่อให้กด Copy ID ได้
8. สร้าง Role ชื่อ Shop Admin แล้วมอบให้คนที่ตรวจเงินได้จริง คัดลอก Role ID
9. วาง Role บอทสูงกว่า Shop Admin ในลำดับ Roles เพื่อให้ตั้งสิทธิ์ห้องได้
10. สร้างห้อง #shop สำหรับหน้าร้าน และ #payment-review สำหรับตรวจเงิน
11. ตั้ง #payment-review ไม่ให้ @everyone ดูได้ ให้เฉพาะ Shop Admin และบอทดู/ส่ง/อ่านประวัติได้
12. สร้าง Category ชื่อ Orders แล้วคัดลอก Category ID
13. คัดลอก Server ID และ Channel ID ของ #payment-review
14. ผู้ซื้อที่มี Administrator จะมองเห็นทุกห้องได้ตามสิทธิ์ Discord; ทดสอบความเป็นส่วนตัวด้วยบัญชีสมาชิกธรรมดา

บอทตรวจสิทธิ์แอดมินสองชั้น: คำสั่งแอดมินซ่อนจากสมาชิกทั่วไปโดย default_member_permissions=Manage Server และในโค้ดตรวจ Shop Admin/Administrator อีกครั้ง
หาก Shop Admin มองไม่เห็นคำสั่ง ไป Server Settings → Integrations → บอท → Commands อนุญาต Role นี้ อย่าให้ Manage Server ทั้งเซิร์ฟเวอร์โดยไม่จำเป็น
สมาชิกต้องมี Use Application Commands ในห้องคำสั่งซื้อเพื่อใช้ /pay

## 3. เข้า Cockpit และเตรียมเครื่อง

เข้า URL Cockpit ที่คุณใช้อยู่ เช่น https://SERVER_IP:9090 แล้ว Login ด้วยบัญชี Linux
เลือก Terminal ทางซ้าย คำสั่งในหน้านี้ทำงานบนเซิร์ฟเวอร์จริง ไม่ใช่บนเครื่องที่เปิดเว็บ
ถ้ามีปุ่มเปิด Administrative access สามารถเปิดได้ แต่คำสั่งด้านล่างยังใช้ sudo อย่างชัดเจน

เช็กระบบ:

```bash
cat /etc/os-release
uname -m
```

คู่มือนี้ใช้ Ubuntu/Debian หากเป็น Rocky/Fedora อย่ารัน apt ให้ติดตั้งแพ็กเกจเทียบเท่าผ่าน dnf ก่อน

```bash
sudo apt update
sudo apt install -y curl ca-certificates xz-utils unzip nano
```

## 4. ติดตั้งด้วยการวางข้อความ (เหมาะกับ iPhone)

ถ้าไม่มีเมนู Files/SFTP: แตก ZIP ในแอป Files บน iPhone เปิด INSTALL_COCKPIT.txt เลือกทั้งหมดและคัดลอก
กลับไป Cockpit → Terminal แล้ววางข้อความทั้งหมดครั้งเดียว กด Enter
ไฟล์นี้ฝังโค้ดโปรเจกต์ไว้เอง ไม่ต้องอัปโหลด ZIP ไปเซิร์ฟเวอร์ และไม่รวม Token
ต้องรันคำสั่ง apt ในข้อ 3 ก่อน โดยเพิ่ม python3 หากเครื่องไม่มี Python
ข้อความจะสร้างโฟลเดอร์ชั่วคราวใน home แล้วเรียก install.sh ผ่าน sudo อาจถามรหัสผ่าน Linux
เมื่อขึ้น Installed ให้ไปข้อ 5 ได้เลย ไม่ต้องติดตั้งซ้ำในวิธีอัปโหลดด้านล่าง

## 4 ทางเลือก. ส่ง ZIP เข้าเซิร์ฟเวอร์

ดาวน์โหลด discord-shop.zip จากแชตลงเครื่องก่อน
ถ้า Cockpit มีเมนู Files ให้เข้าโฟลเดอร์ home ของบัญชีที่ Login แล้วกด Upload
เมนู Files เป็นส่วนเสริม บางเครื่องไม่มี ไม่ใช่ความผิดพลาดของบอท

ถ้าไม่มี Files ใช้ Terminal บนคอมตัวเอง ส่งไฟล์ด้วย scp (แทน youruser และ SERVER_IP):

```bash
scp discord-shop.zip youruser@SERVER_IP:~/
```

บน Windows ใช้ PowerShell ในโฟลเดอร์ที่มี ZIP ได้ หรือใช้โปรแกรม SFTP เช่น WinSCP อัปโหลดไป home เดียวกัน
หากใช้ iPhone และไม่มี Files ต้องใช้แอป SFTP หรืออัปโหลดจากคอมก่อน ไม่สามารถเอาลิงก์ไฟล์ส่วนตัวจากแชตไป wget บนเซิร์ฟเวอร์ตรงๆ ได้

จากนั้นกลับมาที่ Cockpit → Terminal:

```bash
cd ~
unzip discord-shop.zip
cd discord-shop
sudo bash deploy/install.sh
```

สคริปต์สร้าง Linux user `discordshop`, โฟลเดอร์ `/opt/discord-shop`, ติดตั้ง dependencies ตาม package-lock และไฟล์ systemd
ยังไม่เปิดบอท จนกว่าคุณใส่ค่าและสั่งเริ่มเอง
หาก /opt/discord-shop มีอยู่ สคริปต์จะหยุด ไม่เขียนทับข้อมูลเดิม
หากติดตั้งค้าง ให้ตรวจว่าข้อมูลสำคัญมีหรือไม่ก่อนแก้ ห้ามลบ data/ ทิ้งเพื่อแก้ปัญหา

## 5. ตั้งค่า .env

```bash
sudo nano /opt/discord-shop/.env
```

ใส่ค่าจริง:

```dotenv
DISCORD_TOKEN=โทเคนใหม่ของคุณ
CLIENT_ID=Application_ID
GUILD_ID=Server_ID
ADMIN_ROLE_ID=Shop_Admin_Role_ID
ADMIN_CHANNEL_ID=payment_review_Channel_ID
ORDER_CATEGORY_ID=Orders_Category_ID
PROMPTPAY_ID=0812345678
PAYEE_NAME=ชื่อเจ้าของบัญชีผู้รับเงิน
TRUEMONEY_PHONE=0812345678
DB_PATH=./data/shop.sqlite
RESERVATION_MINUTES=15
```

ใช้ตัวเลขจริงแทนตัวอย่าง หมายเลขพร้อมเพย์รองรับรูปแบบที่ไลบรารี promptpay-qr รองรับ เช่น เบอร์โทร/เลขบัตรประชาชนที่ผูกพร้อมเพย์แล้ว
ข้อมูลสองช่องทางในรุ่นนี้ใช้ PAYEE_NAME เดียวกัน จึงควรเป็นชื่อผู้รับคนเดียวกัน
ไม่ต้องใส่ช่องว่างหน้าเครื่องหมาย = และชื่อภาษาไทยใส่ได้ตามตัวอย่าง
กด Ctrl+O → Enter เพื่อบันทึก แล้ว Ctrl+X เพื่อออก
ถ้าคีย์ลัดติดกับเบราว์เซอร์ ใช้เมนูแป้นพิมพ์ของ Terminal หรือแก้ไฟล์ผ่านโปรแกรม SFTP ที่เชื่อถือได้
อย่าถ่ายภาพไฟล์นี้หรือส่งเนื้อหาทั้งไฟล์มาให้ผู้อื่น

```bash
sudo chown discordshop:discordshop /opt/discord-shop/.env
sudo chmod 600 /opt/discord-shop/.env
```

## 6. ลงทะเบียนคำสั่งและเริ่มบอท

```bash
cd /opt/discord-shop
sudo -u discordshop /opt/discord-shop/runtime/bin/node --env-file=/opt/discord-shop/.env src/register.js
sudo systemctl enable --now discord-shop.service
sudo systemctl enable --now discord-shop-backup.timer
sudo systemctl status discord-shop.service --no-pager
```

ถ้าเห็น active (running) และ Log ว่า Shop bot online ถือว่ากระบวนการเริ่มแล้ว ตรวจบัญชีบอทใน Discord ต่อ
จาก Cockpit → Services ค้นหา discord-shop เพื่อดูสถานะ Start/Stop/Restart ได้เช่นกัน
ปิดแท็บ Cockpit ได้ บอทยังทำงาน และเริ่มเองเมื่อเครื่องเปิดใหม่
ห้ามรัน npm start อีกตัวขณะ service ทำงาน ฐานข้อมูลเดียวกันควรใช้บอทหนึ่ง instance

## 7. ทดลองเปิดร้าน

ที่ Discord ใช้บัญชีเจ้าของเซิร์ฟเวอร์หรือแอดมินที่ตั้งค่าไว้:

1. `/product-add name:สินค้าทดลอง satang:9900 description:ข้อความทดลอง` → ได้รหัสสินค้า เช่น 1
2. `/stock-add product:1` → ฟอร์มเติมข้อความ 1 ชิ้น ใส่ `สินค้า TEST-A` แล้วส่ง
3. ใช้ `/stock-add product:1` อีกครั้ง ใส่ `สินค้า TEST-B` เพื่อเติมอีกชิ้น
4. ไปห้อง #shop แล้วใช้ `/shop`
5. ใช้บัญชีสมาชิกธรรมดาเลือกสินค้า กรอกชื่อผู้โอน และกดเลือกวิธีชำระเงิน
6. บอทสร้างห้อง order-เลขรายการเฉพาะผู้ซื้อ บอท และแอดมิน
7. กด QR พร้อมเพย์จะได้รูป QR ตามยอด หรือกด TrueMoney เพื่อดูเบอร์รับเงิน
8. หากเป็นการทดสอบ ใช้ภาพเขียน TEST แล้ว `/pay proof:แนบภาพ` ไม่จำเป็นต้องโอนเงินจริง
9. ใน #payment-review แอดมินจะได้รับรายการและปุ่ม ตรวจเงินเข้าแล้ว/ยืนยัน, ขอหลักฐานเพิ่ม, ปฏิเสธ
10. ในคำสั่งซื้อทดสอบเท่านั้น กดยืนยันเพื่อทดสอบการส่งไฟล์ order-เลข.txt ที่มีข้อความสต็อก
11. สำหรับการขายจริง ตรวจยอดเข้าจริงในแอปธนาคาร/วอลเล็ตเสมอ ไม่ยืนยันจากภาพสลิปอย่างเดียว
12. ให้บัญชีสมาชิกสองคนทดสอบพร้อมกันเพื่อดูคิว เมื่ออนุมัติ/ปฏิเสธรายการก่อนหน้า จำนวนคิวจะเปลี่ยน
13. ซื้อจนหมดแล้วลองเลือกอีกครั้ง ต้องถูกปฏิเสธทันทีโดยไม่สร้างคำสั่งซื้อใหม่
14. รีสตาร์ต service ระหว่างมีคิว แล้วตรวจว่ารายการยังอยู่ก่อนเปิดขายจริง

ราคาหน่วยสตางค์: 100 = 1 บาท, 9900 = 99 บาท, 9950 = 99.50 บาท
สต็อกหนึ่งฟอร์ม = หนึ่งชิ้น ข้อความหลายบรรทัดในฟอร์มเดียวกันจะส่งรวมเป็นสินค้าชิ้นเดียว ไม่แยกตามบรรทัด
สินค้าส่งเป็นไฟล์ UTF-8 .txt ในห้องส่วนตัว เพื่อรองรับข้อความหลายบรรทัดและลดปัญหา Discord ตีความอักขระ

## 8. คำสั่งทั้งหมด

| คำสั่ง | ใช้ทำอะไร |
|---|---|
| /product-add | เพิ่มสินค้า ตั้งราคาเป็นสตางค์ |
| /product-edit | แก้ชื่อ ราคา หรือ active:false เพื่อปิดขาย |
| /stock-add | ฟอร์มส่วนตัว เติมข้อความหนึ่งชิ้น |
| /stock-list | ดูไฟล์สรุปจำนวน available/reserved/sold |
| /shop | สร้างหน้าร้านในห้องปัจจุบัน หน้าร้านเดิมอัปเดตตามสต็อก |
| /pay | ลูกค้าส่งภาพหลักฐานในห้องคำสั่งซื้อของตน |
| /queue | แอดมินดูคิว 50 รายการแรก |
| /order id:เลข | ดูสถานะและลิงก์ห้อง |
| /delivery-confirm order:เลข message:Message_ID | ปิดสถานะส่งค้าง โดยตรวจข้อความสินค้าที่มีอยู่แล้ว |
| /resend order:เลข accept-duplicate-risk:true | แอดมินตรวจห้องแล้วค่อยใช้กรณีส่งค้าง |

รองรับไม่เกิน 100 ชนิดสินค้า หน้าร้านแสดงเมนูเลือกพร้อมจำนวนคงเหลือ
Discord ไม่รองรับปิดเฉพาะตัวเลือกหนึ่งใน select menu รุ่นนี้จึงตรวจและปฏิเสธสินค้าหมดเมื่อเลือก และตรวจซ้ำใน transaction ตอนจอง
หมายเลขคำสั่งซื้อคงเดิม จำนวนคิวก่อนหน้าขยับได้ คิวคิดจากเวลาส่งหลักฐานครั้งแรก
ขอหลักฐานเพิ่มยังคงตำแหน่งคิวและเก็บสินค้าไว้ ส่งใหม่ด้วย /pay
รายการแจ้งชำระแล้วไม่หมดเวลาอัตโนมัติ แอดมินต้องตรวจ/ปฏิเสธ เพื่อป้องกันคืนสินค้าที่ลูกค้าโอนแล้ว
หากโอนหลังหมดเวลาจอง หรือกดยกเลิกหลังโอนแล้ว ให้ติดต่อแอดมิน การคืนเงินทำภายนอกบอท
หนึ่งคนมีรายการที่ยังไม่จบได้หนึ่งรายการ

## 9. ถ้าส่งสินค้าค้าง

การส่ง Discord เป็นเครือข่าย อาจเกิดกรณีส่งสำเร็จแล้วแต่ไม่ได้รับคำตอบ
บอทเก็บสถานะ sending และไม่คืนสต็อก/ไม่ส่งซ้ำเอง
เปิดห้อง order-เลข ตรวจว่ามี order-เลข.txt แล้วหรือไม่
ถ้ามีแล้ว ลูกค้าได้รับสินค้าแล้ว กดค้าง/คลิกขวาข้อความสินค้าของบอท → Copy Message ID แล้วใช้ `/delivery-confirm order:เลข message:Message_ID` เพื่อปิดสถานะโดยไม่ส่งซ้ำ
หากตรวจแล้วไม่มีจริง ค่อย /resend และยอมรับความเสี่ยงข้อความซ้ำ
คำสั่งนี้ส่งข้อความสต็อกเดิมเท่านั้น ไม่ดึงสินค้าชิ้นใหม่
/delivery-confirm ตรวจว่าข้อความมาจากบอทและมีไฟล์ order-เลข.txt ของคำสั่งซื้อนั้นจริง ห้ามลบข้อความสินค้าเดิมก่อนตรวจผล
หากไม่แน่ใจ หยุดบอทและสำรองก่อน ขอความช่วยเหลือโดยส่งเลขคำสั่งซื้อ/สถานะได้ ห้ามส่งสต็อกหรือ Token

## 10. ดู Log / รีสตาร์ต

```bash
sudo journalctl -u discord-shop.service -n 80 --no-pager
sudo systemctl restart discord-shop.service
sudo systemctl stop discord-shop.service
sudo systemctl start discord-shop.service
```

- Invalid token / TokenInvalid: Reset Token แล้วใส่ใหม่ใน .env และ restart
- Missing Access / 50001 / 50013: เช็ก ID, สิทธิ์ห้อง, Manage Channels/Manage Roles และลำดับ Role บอท
- คำสั่งไม่ขึ้น: ตรวจ CLIENT_ID/GUILD_ID แล้วรัน register ใหม่ จากนั้นปิดเปิด Discord และตรวจ Integrations → Commands
- ลูกค้าใช้ /pay ไม่ได้: ตรวจ Use Application Commands ในห้อง/หมวด Orders
- QR ผิด: เช็กหมายเลขผูกพร้อมเพย์และทดลองสแกน ตรวจชื่อผู้รับก่อนเปิดขาย
- โอนแล้วคิวไม่ขึ้น: ต้องใช้ /pay แนบภาพ ไม่ใช่กดชำระแล้วอย่างเดียว
- ลิงก์หลักฐานหมดอายุ: เปิดภาพที่บอทคัดลอกไว้ในห้อง order-เลข
- บอทเริ่มแล้วหยุด: ดู Log ระบบ จำกัด restart 5 ครั้งใน 5 นาที หลังแก้ใช้ `sudo systemctl reset-failed discord-shop` แล้ว start
- ปิดอินเทอร์เน็ต/ไฟดับ บอทไม่ทำงานจนเครื่องและเน็ตกลับมา เซิร์ฟเวอร์เปิดตลอดไม่ได้รับประกันว่าไม่ดับ

## 11. สำรองและกู้คืน

มี timer สำรอง SQLite ทุกวันด้วย online backup API ไม่คัดลอกเฉพาะ shop.sqlite ระหว่าง WAL กำลังทำงาน

```bash
sudo systemctl start discord-shop-backup.service
sudo systemctl list-timers discord-shop-backup.timer
sudo ls -lh /opt/discord-shop/backups
```

สำเนาอยู่ใน /opt/discord-shop/backups และมีข้อมูลลูกค้า/สต็อก จัดเก็บเป็นความลับ
คัดลอกสำเนาที่ตรวจแล้วออกไปอีกเครื่องด้วย SFTP เป็นระยะ เพื่อรับมือดิสก์เซิร์ฟเวอร์เสีย
รุ่นนี้ไม่ลบสำเนาเก่าเอง ผู้ดูแลตรวจพื้นที่และลบเฉพาะสำเนาที่ไม่ต้องการ
.env ไม่รวมอยู่ในสำเนาฐานข้อมูล ควรเก็บข้อมูลตั้งค่าในที่ส่วนตัวแยกไว้

กู้คืน: หยุด discord-shop และ backup.timer ก่อน ตรวจว่าฐานข้อมูลสำเนาถูกต้อง เก็บ data/ ทั้งโฟลเดอร์ปัจจุบันไว้ก่อน แล้วนำสำเนาที่เลือกกลับเป็น data/shop.sqlite โดยไม่ให้มี WAL/SHM จากฐานข้อมูลคนละชุดค้างอยู่ ตั้งเจ้าของเป็น discordshop:discordshop สิทธิ์ 600 แล้วค่อย start
หากกู้คืนจากสำเนาเก่า จะไม่มีประวัติธุรกรรมหลังเวลาสำรอง ต้องตรวจเทียบข้อความใน Discord ก่อนเปิดขาย เพื่อไม่ขายสต็อกที่ส่งไปแล้วซ้ำ

## 12. อัปเดตโค้ดในภายหลัง

ไม่รัน deploy/install.sh ซ้ำทับระบบเดิม
สำรองฐานข้อมูลและ .env ก่อน หยุด service แทนที่เฉพาะ src/, package.json, package-lock.json ด้วยเวอร์ชันที่ตรวจแล้ว
รัน npm ci ด้วย runtime ที่อยู่ใน /opt/discord-shop/runtime/bin/ และรัน register ใหม่หากคำสั่งเปลี่ยน
อย่าเขียนทับ data/, backups/, .env หากมีการเปลี่ยน schema ต้องทำ migration ก่อน
แล้วเริ่ม service และตรวจ Log/ทดลองร้าน

## 13. ขอบเขตการทดสอบ

ผ่าน unit/integration ภายในเครื่อง 14 กรณี: จองชิ้นสุดท้าย, คนเดิมสั่งซ้ำ, คืนสต็อกหมดเวลา, เก็บสต็อกระหว่างตรวจ, ตรวจเจ้าของ, อัปเดตคิว, หลักฐานเพิ่ม, เปิดฐานข้อมูลใหม่, ปิดสินค้า, สอง process แย่งจอง, ส่งข้อมูลถูกชิ้น, ไม่ส่งซ้ำ, เครือข่ายส่งค้าง, และห้ามส่งก่อนอนุมัติ
ตรวจสร้าง slash-command JSON และ QR ได้จริง ติดตั้ง dependencies จาก lockfile ได้
ยังไม่ทดสอบ Discord API ด้วยบอทจริง หรือรันสคริปต์ติดตั้งด้วย root บนเซิร์ฟเวอร์จริง
ตรวจ unit ด้วย systemd-analyze ได้แต่มีคำเตือนว่า ExecStart ยังไม่มีในเครื่องทดสอบ เพราะไม่ได้ติดตั้ง /opt/discord-shop ที่นี่

แหล่งอ้างอิงทางการ:
- https://docs.discord.com/developers/interactions/application-commands
- https://discord.js.org/docs/packages/discord.js/main
- https://nodejs.org/api/sqlite.html
- https://nodejs.org/en/download
- https://docs.cockpit-project.org/cockpit-guide/368/guide/feature-terminal.html
