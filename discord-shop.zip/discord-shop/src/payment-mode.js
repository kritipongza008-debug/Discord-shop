export const paymentMethods = {promptpay:'พร้อมเพย์',truemoney:'TrueMoney Wallet'};
export const paymentModes = {
 manual:'ตรวจเอง',
 assist:'บอทตรวจ · แอดมินยืนยัน',
 auto:'ตรวจและส่งอัตโนมัติ'
};

export function paymentPolicy(store,config,method) {
 const saved = store.paymentMode(method);
 if (!config.slipKey) return {mode:'manual',revision:saved?.revision ?? 0};
 return saved ?? {mode:config.slipAutoSend ? 'auto' : 'assist',revision:0};
}
