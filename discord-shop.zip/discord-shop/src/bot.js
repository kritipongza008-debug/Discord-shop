import {randomUUID} from 'node:crypto';
import {Client,GatewayIntentBits,ChannelType,PermissionFlagsBits as P,ActionRowBuilder as Row,ButtonBuilder as Button,ButtonStyle as BS,ContainerBuilder,TextDisplayBuilder,ModalBuilder as Modal,TextInputBuilder as Input,TextInputStyle as IS,AttachmentBuilder,EmbedBuilder,MessageFlags,StringSelectMenuBuilder} from 'discord.js';
import {ephemeralCleanup} from './ephemeral-cleanup.js';
import {deliverOrder,sendPrivateProduct,receiptDelivery,isProductDelivery} from './delivery.js';
import {config} from './config.js';
import {catalogPayload,productPayload} from './catalog.js';
import {appearancePreview} from './appearance-preview.js';
import {syncReviewMessage} from './review-message.js';
import {downloadProductImage} from './product-image.js';
import {commands,settingsCommand} from './commands.js';
import {handleSettings,hasShopRole,settingsPanel,shopReady} from './settings.js';import {Store,activeSalePrice,effectivePrice,reviewStatuses} from './store.js';
import {downloadStockFile,parseStockFile} from './stock-import.js';
import {createOrderRoomGuard,removeFinishedOrderRoom} from './order-room.js';
import {supportPicker,customerSupport,adminSupport} from './support-ui.js';
import {orderCard,checkoutCard,orderStatusLabel,slipModal} from './order-ui.js';
import {adminEntry,adminHome,productPicker,productForm,saleForm,stockLinesForm,importForm,publishPicker,parseBaht,parseSaleEnd,appearanceFields,appearanceForm,bannerForm,couponForm,parseCouponFields,stockRemovalPicker} from './control-ui.js';
process.umask(0o077);
const c=config(),s=new Store(c.db),client=new Client({intents:[GatewayIntentBits.Guilds],allowedMentions:{parse:[]}});
if (!s.settings() && c.legacy) s.saveSettings(null,c.legacy);
Object.assign(c,s.settings());
const stockImports = new Map();
const catalogSearches = new Map();
const cleanupPreviews = new Map();
const stockRemovals = new Map();
const appearanceDrafts = new Map();
const reviewRefreshes = new Map();
const reviewStamps = new Map();
const buyerStamps = new Map();
const refreshWindow = 60_000;
const roomJobs = createOrderRoomGuard();
const deliveryJobs = createOrderRoomGuard();
const testOrders = new Map();

async function registerGuild(guild) {
 try {
  const guildCommands = c.guild === guild.id ? commands : [settingsCommand];
  await guild.commands.set(guildCommands);
 } catch (error) {
  console.error('Slash command registration failed for guild',guild.id,error.code || error.name);
 }
}

const money=n=>(n/100).toFixed(2)+' บาท';
const button=(id,label,style=BS.Secondary)=>new Button().setCustomId(id).setLabel(label).setStyle(style);
const isAdmin=i=>hasShopRole(i,c.role);
function requireAdmin(i){if(!isAdmin(i))throw Error('เฉพาะแอดมินร้านเท่านั้น')}
function modal(id,title,label,maxLength=3500,required=true){return new Modal().setCustomId(id).setTitle(title).addComponents(new Row().addComponents(new Input().setCustomId('value').setLabel(label).setStyle(IS.Paragraph).setRequired(required).setMaxLength(maxLength)))}
function validationFields(errors, path='') {
 return Object.entries(errors ?? {}).flatMap(([key, value]) => {
  if (key==='_errors') return value.map(issue=>`${path || 'body'} (${issue.code})`);
  return validationFields(value,path ? `${path}.${key}` : key);
 });
}
const safeError=e=>{
 const code = e.code || e.name || 'Error';
 const fields = code===50035 ? validationFields(e.rawError?.errors).slice(0,8) : [];
 console.error('Operation failed',code,...fields);
};
const watchPrivateReplies = ephemeralCleanup(safeError);
async function channel(id){const ch=await client.channels.fetch(id);if(!ch?.isTextBased())throw Error('ไม่พบห้อง กรุณาตรวจการตั้งค่าและสิทธิ์');return ch}
const statusButton = (id) => button(`status:${id}`,'เช็กสถานะ');
const slipButton = (id) => button(`paid:${id}`,'แนบสลิป',BS.Success).setEmoji('📎');
function orderButtons(order) {
 if (order.status === 'pending') {
  return [
   new Row().addComponents(
    button(`method:${order.id}:promptpay`,'QR พร้อมเพย์',order.method==='promptpay'?BS.Primary:BS.Secondary),
    button(`method:${order.id}:truemoney`,'TrueMoney',order.method==='truemoney'?BS.Primary:BS.Secondary)
   ),
   new Row().addComponents(slipButton(order.id).setDisabled(!order.method),statusButton(order.id),button(`cancel:${order.id}`,'ยกเลิก'))
  ];
 }
 if (order.method && ['info','late_info'].includes(order.status)) {
  return [new Row().addComponents(slipButton(order.id),statusButton(order.id))];
 }
 if (order.status==='delivered') return [new Row().addComponents(button(`receipt:${order.id}`,'รับสินค้าและดูบิล',BS.Success))];
 return [new Row().addComponents(statusButton(order.id))];
}
function orderPayload(order, admin = false) {
 const ahead = reviewStatuses.includes(order.status) ? s.ahead(order) : undefined;
 let components = orderButtons(order);
 if (admin) {
  components = [];
  if (ahead !== undefined) {
   components.push(new Row().addComponents(
    button(`approve:${order.id}`,'ยืนยันยอดเข้า',BS.Success),
    button(`info:${order.id}`,'ขอสลิปเพิ่ม'),
    button(`refund:${order.id}`,'รอคืนเงิน'),
    button(`reject:${order.id}`,'ปฏิเสธ',BS.Danger)
   ));
  } else if (order.status === 'refund_pending') {
   components.push(new Row().addComponents(button(`refund-done:${order.id}`,'บันทึกว่าคืนเงินแล้ว',BS.Success)));
  }
 }
 return {embeds:[orderCard(order,ahead,admin)],components};
}
async function refreshPanels(){
 s.resetStockAlerts(c.stockThreshold ?? 2);
 let refreshed = true;
 for (const panel of s.all('SELECT * FROM panels')) {
  try {
   const room = await channel(panel.channel_id);
   await room.messages.edit(panel.message_id,{...catalogPayload(s),content:null,embeds:[],attachments:[]});
  } catch (error) {
   safeError(error);
   if (![10003,10008,50001,50013].includes(error.code)) refreshed = false;
  }
 }
 return refreshed;
}
function alreadyRefreshed(cache,id,signature) {
 const entry = cache.get(id);
 return entry?.signature===signature && entry.expires>Date.now();
}
function markRefreshed(cache,id,signature) {
 cache.set(id,{signature,expires:Date.now()+refreshWindow});
}
async function refreshBuyerOrder(id) {
 const order = s.order(id);
 if (!order?.channel_id || !order.message_id) return;
 const signature = JSON.stringify([
  order.channel_id,order.message_id,order.status,order.name,order.description,order.price,order.method,
  order.expires,order.room_close_at,order.payer,order.reason,order.coupon_code,order.coupon_discount,
  reviewStatuses.includes(order.status) ? s.ahead(order) : null,
  order.status==='pending' && order.method ? [c.payee,c.pp,c.wallet] : null
 ]);
 if (alreadyRefreshed(buyerStamps,id,signature)) return;
 const room = await channel(order.channel_id);
 const current = s.order(id);
 if (current.channel_id!==order.channel_id || current.message_id!==order.message_id) return;
 const ahead = reviewStatuses.includes(current.status) ? s.ahead(current) : undefined;
 const card = await checkoutCard(current,c,ahead);
 const latest = s.order(id);
 if (latest.status!==current.status || latest.method!==current.method || latest.message_id!==current.message_id) return;
 await room.messages.edit(current.message_id,{content:null,...card,components:orderButtons(current),attachments:[]});
 markRefreshed(buyerStamps,id,signature);
}
async function refreshReview(id) {
 const previous = reviewRefreshes.get(id);
 const task = (previous ?? Promise.resolve()).catch(()=>{}).then(async()=>{
  const order = s.order(id);
  if (!order?.proof) return;
  const payload = orderPayload(order,true);
  const signature = JSON.stringify([c.admin,payload]);
  if (alreadyRefreshed(reviewStamps,id,signature)) return;
  const room = await privateAdminRoom();
  const messageId = await syncReviewMessage(room,order.admin_message_id,payload,id,reviewStamps.get(id)?.signature===signature);
  if (messageId!==order.admin_message_id) s.run('UPDATE orders SET admin_message_id=? WHERE id=?',messageId,id);
  markRefreshed(reviewStamps,id,signature);
 });
 reviewRefreshes.set(id,task);
 try { await task; }
 finally { if (reviewRefreshes.get(id)===task) reviewRefreshes.delete(id); }
}
async function refreshOrder(id) {
 try { await refreshBuyerOrder(id); } catch (error) { safeError(error); }
 try { await refreshReview(id); } catch (error) { safeError(error); }
}
async function refreshQueue(){for(const o of s.reviewOrders())await refreshOrder(o.id)}
async function deliver(id,force=false) {
 await deliveryJobs.run(id,()=>deliverOrder(s,id,(order,content)=>sendPrivateProduct(()=>client.users.send(order.user_id,{
  ...receiptDelivery(order,content,s.appearance()),nonce:String(id),enforceNonce:true
 })),force));
 await refreshOrder(id);
}
async function findDeliveryMessage(order,messageId) {
 const stock = s.get('SELECT content FROM stock WHERE id=?',order.stock_id).content;
 const availableRooms = [
  ()=>client.users.createDM(order.user_id),
  ...(order.channel_id ? [()=>channel(order.channel_id)] : [])
 ];
 for (const getRoom of availableRooms) {
  try {
   const message = await (await getRoom()).messages.fetch(messageId);
   if (isProductDelivery(message,order.id,stock,client.user.id)) return message;
  } catch (error) {
   if (![10003,10008,50001,50007,50278].includes(error.code)) throw error;
  }
 }
 throw Error('ไม่พบสินค้าที่บอทส่งใน DM หรือห้องออเดอร์');
}
async function ensureOrderRoom(o,guild){const category=await guild.channels.fetch(c.category);if(category?.type!==ChannelType.GuildCategory)throw Error('ORDER_CATEGORY_ID ต้องเป็นหมวดหมู่');
 const ch=await guild.channels.create({name:`order-${o.id}`,type:ChannelType.GuildText,parent:c.category,permissionOverwrites:[{id:guild.id,deny:[P.ViewChannel]},{id:o.user_id,allow:[P.ViewChannel,P.ReadMessageHistory,P.SendMessages,P.AttachFiles],deny:[P.MentionEveryone,P.CreatePublicThreads,P.CreatePrivateThreads]},{id:c.role,allow:[P.ViewChannel,P.ReadMessageHistory,P.SendMessages]},{id:client.user.id,allow:[P.ViewChannel,P.ReadMessageHistory,P.SendMessages,P.AttachFiles,P.EmbedLinks]}]});s.run('UPDATE orders SET channel_id=? WHERE id=?',ch.id,o.id);const m=await ch.send(orderPayload(o));s.run('UPDATE orders SET message_id=? WHERE id=?',m.id,o.id);return ch}
function requireBuyerRoom(interaction,order) {
 if (!order || order.user_id!==interaction.user.id || order.channel_id!==interaction.channelId) {
  throw Error('ส่งสลิปในห้องออเดอร์ของคุณ');
 }
}
async function submitProof(i, orderId, proof, recovery = false) {
 if (!proof || !['image/png','image/jpeg','image/webp'].includes(proof.contentType) || proof.size>8*1024*1024) {
  throw Error('ใช้ PNG JPG WEBP ขนาดไม่เกิน 8MB');
 }
 const result = await roomJobs.run(orderId, async () => {
  const order = s.order(orderId);
  if (!order || order.user_id !== i.user.id || (recovery && order.status !== 'expired')) {
   throw Error('รายการนี้ไม่สามารถส่งสลิปย้อนหลังได้');
  }
  if (!recovery) requireBuyerRoom(i,order);
  if (!order.method) throw Error('เลือกวิธีชำระก่อน หากโอนไปแล้วให้แจ้งแอดมิน');
  if (!s.canSubmitProof(order,i.user.id)) throw Error('ออเดอร์นี้ส่งหลักฐานเพิ่มไม่ได้ กรุณาติดต่อแอดมิน');
  let room = i.channel;
  if (recovery) {
   room = null;
   if (order.channel_id) {
    try { room = await client.channels.fetch(order.channel_id,{force:true}); }
    catch (error) { if (error.code !== 10003) throw error; }
   }
   if (!room) room = await ensureOrderRoom(order,i.guild);
   if (room.guildId !== c.guild || room.type !== ChannelType.GuildText || room.id !== s.order(orderId).channel_id) {
    throw Error('ไม่พบห้องออเดอร์ส่วนตัว');
   }
  }
  const extension = proof.contentType === 'image/png' ? 'png' : proof.contentType === 'image/webp' ? 'webp' : 'jpg';
  const message = await room.send({
   content:`หลักฐานออเดอร์ #${orderId} · รอตรวจยอดจริง`,
   files:[new AttachmentBuilder(proof.url,{name:`proof-${orderId}.${extension}`})]
  });
  return {room,status:s.submit(orderId,i.user.id,message.attachments.first().url)};
 });
 const late = result.status === 'late_review';
 await i.editReply({
  content:late
   ? '**รับสลิปย้อนหลังแล้ว**\nรอแอดมินตรวจยอดและเช็กสต็อก กรุณาอย่าโอนซ้ำ'
   : '**รับสลิปแล้ว**\nขั้นต่อไป รอแอดมินตรวจยอด ดูคิวได้จากใบออเดอร์ในห้องนี้',
  components:recovery?[new Row().addComponents(
   new Button().setStyle(BS.Link).setLabel('เปิดห้องออเดอร์').setURL(result.room.url)
  )]:[]
 });
 await refreshQueue();
 if (late) await refreshPanels();
}
const ephemeral = {flags:MessageFlags.Ephemeral};
const channelLink = (guildId,channelId) => `https://discord.com/channels/${guildId}/${channelId}`;

async function privateAdminRoom() {
 const room = await channel(c.admin);
 if (room.guildId !== c.guild || room.type !== ChannelType.GuildText ||
  room.permissionsFor(room.guild.roles.everyone)?.has(P.ViewChannel)) {
  throw Error('ตั้งห้องตรวจเงินให้เป็นส่วนตัวก่อน');
 }
 return room;
}

async function sendSupportNotice(id) {
 const ticket = s.get('SELECT * FROM order_support WHERE id=?',id);
 if (!ticket || ticket.admin_message_id) return;
 const order = s.order(ticket.order_id);
 const room = await privateAdminRoom();
 const message = await room.send({...adminSupport(order,ticket),nonce:`support${id}`,enforceNonce:true});
 s.run('UPDATE order_support SET admin_message_id=? WHERE id=?',message.id,id);
}

async function sendStockAlerts() {
 const threshold = c.stockThreshold ?? 2;
 s.resetStockAlerts(threshold);
 const products = s.lowStock(threshold).slice(0,10);
 if (!products.length) return;
 const room = await privateAdminRoom();
 await room.send({
  embeds:[new EmbedBuilder().setColor(0xe3a32f).setTitle('📦 สต็อกใกล้หมด')
   .setDescription(products.map(product=>`**${product.name}** · เหลือ ${product.remaining} ชิ้น`).join('\n'))],
  components:[new Row().addComponents(button('shop-admin:pick:stock:0','เติมสต็อก',BS.Success))]
 });
 s.tx(()=>{
  const stillLow = new Set(s.lowStock(c.stockThreshold ?? 2).map(product=>product.id));
  for (const product of products) {
   if (stillLow.has(product.id)) s.run('INSERT OR IGNORE INTO stock_alerts(product_id) VALUES(?)',product.id);
  }
 });
}

async function sendRestockNotices() {
 const panel = s.get('SELECT channel_id,message_id FROM panels ORDER BY rowid DESC LIMIT 1');
 const components = panel ? [new Row().addComponents(new Button().setStyle(BS.Link)
  .setLabel('เปิดหน้าร้าน').setURL(`${channelLink(c.guild,panel.channel_id)}/${panel.message_id}`))] : [];
 for (const notice of s.restockNotices()) {
  if (!s.claimRestockNotice(notice.id,notice.user_id)) continue;
  try {
   await client.users.send(notice.user_id,{
    embeds:[new EmbedBuilder().setColor(0x27835f).setTitle('🔔 สินค้ากลับมาแล้ว')
     .setDescription(notice.name)],
    components
   });
  } catch (error) {
   if (![50007,50278].includes(error.code)) safeError(error);
  }
 }
}

async function handleSupport(i) {
 if (!i.customId?.startsWith('support:')) return false;
 const [,action,arg] = i.customId.split(':');
 if (i.isButton() && action === 'open') {
  const orders = s.all(`SELECT o.id,p.name FROM orders o JOIN products p ON p.id=o.product_id
   WHERE o.user_id=? ORDER BY o.id DESC LIMIT 25`,i.user.id);
  await i.reply({...supportPicker(orders),...ephemeral});
  return true;
 }
 if (action === 'reply' && i.isButton()) {
  requireAdmin(i);
  const ticket = s.get('SELECT * FROM order_support WHERE id=?',Number(arg));
  if (!ticket || ticket.answer) throw Error('ข้อความนี้มีคำตอบแล้วหรือไม่พบรายการ');
  await i.showModal(modal(`support:answer:${arg}`,'ตอบลูกค้า','คำตอบที่จะให้ลูกค้าเห็น'));
  return true;
 }
 if (action === 'answer' && i.isModalSubmit()) {
  requireAdmin(i);
  const answer = i.fields.getTextInputValue('value').trim();
  if (!answer || answer.length>1000) throw Error('กรอกคำตอบไม่เกิน 1,000 ตัวอักษร');
  await i.deferReply(ephemeral);
  requireAdmin(i);
  s.answerSupport(Number(arg),i.user.id,answer);
  const ticket = s.get('SELECT * FROM order_support WHERE id=?',Number(arg));
  const order = s.order(ticket.order_id);
  await i.editReply('**บันทึกคำตอบแล้ว** ลูกค้าอ่านได้จากออเดอร์ของฉัน → ติดต่อร้าน');
  if (ticket.admin_message_id) {
   try {
    const room = await privateAdminRoom();
    await room.messages.edit(ticket.admin_message_id,adminSupport(order,ticket));
   } catch (error) { safeError(error); }
  }
  return true;
 }
 const orderId = Number(action==='pick' && i.isStringSelectMenu() ? i.values[0] : arg);
 const order = s.order(orderId);
 if (!order || order.user_id!==i.user.id) throw Error('ไม่พบออเดอร์ของคุณ');
 if (action === 'pick' && i.isStringSelectMenu()) {
  await i.update({content:null,...customerSupport(order,s.latestSupport(orderId,i.user.id))});
 } else if (action === 'write' && i.isButton()) {
  if (s.latestSupport(orderId,i.user.id)?.answer === null) throw Error('ร้านยังไม่ได้ตอบข้อความก่อนหน้า');
  await i.showModal(modal(`support:send:${orderId}`,'ติดต่อร้าน','อธิบายปัญหา (ไม่เกิน 1,000 ตัวอักษร)'));
 } else if (action === 'send' && i.isModalSubmit()) {
  const question = i.fields.getTextInputValue('value').trim();
  if (!question || question.length>1000) throw Error('กรอกข้อความไม่เกิน 1,000 ตัวอักษร');
  await i.deferReply(ephemeral);
  const id = s.createSupport(orderId,i.user.id,question);
  await i.editReply({
   content:`**รับข้อความของออเดอร์ #${orderId} แล้ว**\nกลับมาอ่านคำตอบจาก **ออเดอร์ของฉัน → ติดต่อร้าน**`
  });
  try { await sendSupportNotice(id); } catch (error) { safeError(error); }
 } else {
  throw Error('เปิดติดต่อร้านใหม่จากออเดอร์ของฉัน');
 }
 return true;
}


async function ensureAdminPanel() {
 if (!shopReady(c) || s.get('SELECT channel_id FROM shop_admin_panel WHERE id=1')?.channel_id === c.admin) return;
 try {
  const room = await privateAdminRoom();
  const message = await room.send({...adminEntry(),nonce:`ctl${room.id}`,enforceNonce:true});
  s.run('INSERT INTO shop_admin_panel(id,channel_id,message_id) VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET channel_id=excluded.channel_id,message_id=excluded.message_id',room.id,message.id);
 } catch (error) { safeError(error); }
}

async function publishShop(room) {
 const panel = s.get('SELECT message_id FROM panels WHERE channel_id=? ORDER BY rowid DESC LIMIT 1',room.id);
 const payload = catalogPayload(s);
 if (panel) {
  try {
   await room.messages.edit(panel.message_id,{...payload,content:null,embeds:[],attachments:[]});
   return 'อัปเดตหน้าร้านเดิมแล้ว';
  } catch (error) {
   if (error.code !== 10008) throw error;
   s.run('DELETE FROM panels WHERE message_id=?',panel.message_id);
  }
 }
 const message = await room.send(payload);
 s.run('INSERT INTO panels VALUES(?,?)',room.id,message.id);
 return 'เผยแพร่หน้าร้านแล้ว';
}

async function saveProduct(interaction, id, fields) {
 const image = await downloadProductImage(fields.image);
 requireAdmin(interaction);
 const result = s.tx(() => {
  if (id === null) {
   if (s.get('SELECT count(*) n FROM products').n >= 100) throw Error('รุ่นนี้รองรับ 100 สินค้า');
   id = s.addProduct(fields.name,fields.description ?? '',fields.price);
  } else {
   const previous = s.get('SELECT * FROM products WHERE id=?',id);
   if (!previous) throw Error('ไม่พบสินค้า');
   const sale = activeSalePrice(previous,s.now());
   if (sale!==null && fields.price!=null && fields.price<=sale) {
    throw Error('ราคาปกติต้องสูงกว่าราคาโปร กรุณาปรับหรือปิดโปรก่อน');
   }
   if (sale===null && previous.sale_price!==null) {
    s.run('UPDATE products SET sale_price=NULL WHERE id=?',id);
   }
   s.run('UPDATE products SET name=?,price=?,description=?,active=? WHERE id=?',
    fields.name ?? previous.name,fields.price ?? previous.price,
    fields.description ?? previous.description,fields.active ?? previous.active,id);
   if (fields.price!=null && fields.price!==previous.price) {
    s.recordActivity(interaction.user.id,`เปลี่ยนราคาสินค้า #${id} จาก ${money(previous.price)} เป็น ${money(fields.price)}`);
   }
  }
  if (image) s.setProductImage(id,image);
  return id;
 });
 await interaction.editReply({
  content:`**บันทึกสินค้า #${result} แล้ว**${image ? '\nบอทย่อรูปใหม่ให้แล้ว' : ''}\nเติมสต็อกเพื่อให้ลูกค้าสั่งซื้อได้`,
  components:[new Row().addComponents(button('shop-admin:home','กลับแผงจัดการ',BS.Primary))]
 });
 await refreshPanels();
}

async function prepareStockImport(interaction, productId, attachment) {
 const lines = await downloadStockFile(attachment);
 return await prepareStockPreview(interaction,productId,lines);
}

async function prepareStockPreview(interaction,productId,lines) {
 requireAdmin(interaction);
 const plan = s.stockImportPlan(productId,lines);
 if (!plan.fresh.length) return await interaction.editReply(`**ไม่มีสต็อกใหม่** · ข้ามรายการซ้ำ ${plan.skipped} บรรทัด`);
 const token = randomUUID();
 stockImports.set(interaction.user.id,{productId,lines,token,expires:Date.now()+300000});
 return await interaction.editReply({
  content:`**สินค้า #${productId}** · จะเพิ่ม **${plan.fresh.length} ชิ้น**\nข้ามรายการซ้ำ ${plan.skipped} บรรทัด · กดยืนยันใน 5 นาที`,
  components:[new Row().addComponents(
   button(`stock-import:confirm:${token}`,'ยืนยันเติมสต็อก',BS.Success),button(`stock-import:cancel:${token}`,'ยกเลิก')
  )]
 });
}

function queuePayload() {
 const rows = s.reviewOrders();
 const description = rows.slice(0,15).map(({id},index)=>{
  const order = s.order(id);
  const destination = order.admin_message_id
   ? `${channelLink(c.guild,c.admin)}/${order.admin_message_id}`
   : channelLink(c.guild,c.admin);
  return `${index+1}. [ออเดอร์ #${id}](${destination}) · **${money(order.price)}**`;
 }).join('\n');
 return {
  embeds:[new EmbedBuilder().setColor(0xe3a32f).setTitle(`คิวตรวจยอด · ${rows.length} รายการ`)
   .setDescription(description || 'ยังไม่มีออเดอร์รอตรวจยอด')],
  components:[new Row().addComponents(
   new Button().setStyle(BS.Link).setLabel('เปิดห้องตรวจเงิน').setURL(channelLink(c.guild,c.admin)),
   button('shop-admin:home','กลับแผงจัดการ')
  )]
 };
}

function adminFollowUpPayload(kind) {
 const refunds = kind === 'refunds';
 const rows = refunds
  ? s.all("SELECT id order_id,admin_message_id FROM orders WHERE status='refund_pending' ORDER BY id")
  : s.all("SELECT order_id,admin_message_id FROM order_support WHERE answer IS NULL ORDER BY id");
 const roomUrl = channelLink(c.guild,c.admin);
 return {
  embeds:[new EmbedBuilder().setColor(0xe3a32f)
   .setTitle(`${refunds?'รอคืนเงิน':'ข้อความที่รอตอบ'} · ${rows.length} รายการ`)
   .setDescription(rows.slice(0,15).map(({order_id,admin_message_id})=>
    `[ออเดอร์ #${order_id}](${admin_message_id?`${roomUrl}/${admin_message_id}`:roomUrl})`
   ).join('\n') || 'ไม่มีรายการค้าง')],
  components:[new Row().addComponents(button('shop-admin:home','กลับแผงจัดการ'))]
 };
}
function stockPayload() {
 const rows = s.all(`SELECT p.id,p.name,
  sum(CASE WHEN s.status='available' THEN 1 ELSE 0 END) available,
  sum(CASE WHEN s.status='reserved' THEN 1 ELSE 0 END) reserved
  FROM products p LEFT JOIN stock s ON s.product_id=p.id GROUP BY p.id ORDER BY p.id`);
 const lines = rows.map(product=>`#${product.id} ${product.name} · เหลือ ${product.available} · กันไว้สำหรับออเดอร์ ${product.reserved}`);
 return {
  embeds:[new EmbedBuilder().setColor(0xc32d36).setTitle('สต็อกสินค้า')
   .setDescription(lines.slice(0,12).join('\n') || 'ยังไม่มีสินค้า')],
  files:rows.length>12?[new AttachmentBuilder(Buffer.from(lines.join('\n')),{name:'stock-summary.txt'})]:[],
  components:[new Row().addComponents(button('shop-admin:pick:stock:0','เติมสต็อก',BS.Success),button('shop-admin:pick:remove:0','ลบสต็อก'),button('shop-admin:inventory','กลับสินค้าและสต็อก'))]
 };
}

function myOrdersPayload(userId) {
 const orders = s.all(`SELECT o.id,o.status,o.channel_id,o.method,p.name FROM orders o
  JOIN products p ON p.id=o.product_id WHERE o.user_id=? ORDER BY o.id DESC LIMIT 8`,userId);
 const description = orders.map(order=>{
  const title = `ออเดอร์ #${order.id}`;
  return `${order.channel_id && order.status!=='expired' ? `[${title}](${channelLink(c.guild,order.channel_id)})` : title} · **${orderStatusLabel(order.status)}**\n${order.name}`;
 }).join('\n\n');
 const components = [new Row().addComponents(button('catalog:orders','อัปเดตสถานะ'),
  button('catalog:find-order','ค้นหาจากเลขออเดอร์',BS.Primary),button('support:open','ติดต่อร้าน'))];
 const delivered = orders.filter(order=>order.status==='delivered');
 if (delivered.length) {
  components.unshift(new Row().addComponents(new StringSelectMenuBuilder()
   .setCustomId('catalog:download').setPlaceholder('รับสินค้าและดูบิล · เลือกออเดอร์')
   .addOptions(delivered.map(order=>({label:`#${order.id} · ${order.name}`,value:String(order.id)})))));
 }
 const expired = orders.filter(order=>order.status==='expired' && order.method);
 if (expired.length) {
  components.unshift(new Row().addComponents(new StringSelectMenuBuilder()
   .setCustomId('catalog:late-slip').setPlaceholder('โอนแล้วแต่หมดเวลา? เลือกออเดอร์เพื่อแนบสลิป')
   .addOptions(expired.map(order=>({label:`#${order.id} · ${order.name}`,value:String(order.id)})))));
 }
 return {
  embeds:[new EmbedBuilder().setColor(0xc32d36).setTitle('ออเดอร์ของฉัน')
   .setDescription(description || 'ยังไม่มีออเดอร์ กด **ดูสินค้า** จากหน้าร้านเพื่อเริ่มซื้อ')],
  components
 };
}

async function handleOrderCleanup(i,action,token) {
 if (action==='cleanup') {
  const rooms = s.roomsForAdminCleanup();
  const unstarted = rooms.filter(room=>room.status==='pending').length;
  const confirmToken = randomUUID();
  if (rooms.length) cleanupPreviews.set(i.user.id,{token:confirmToken,rooms,expires:Date.now()+30000});
  return await i.reply({
   content:rooms.length
    ? `**เคลียร์ห้องออเดอร์ · สูงสุด 25 ห้องต่อรอบ**\nยังไม่ได้เลือกวิธีจ่าย **${unstarted}** ห้อง · ปิดรายการแล้ว **${rooms.length-unstarted}** ห้อง\nห้องที่ยังไม่ได้เลือกวิธีจ่ายจะถูกยกเลิกและคืนสต็อก ประวัติออเดอร์ยังอยู่\nข้อความในห้องจะถูกลบเมื่อยืนยัน`
    : '**ไม่มีห้องออเดอร์ที่เคลียร์ได้**',
   components:rooms.length ? [new Row().addComponents(
    button(`shop-admin:cleanup-confirm:${confirmToken}`,'ยืนยันเคลียร์ห้อง',BS.Danger),
    button('shop-admin:home','กลับแผงจัดการ')
   )] : [new Row().addComponents(button('shop-admin:home','กลับแผงจัดการ'))],...ephemeral
  });
 }
 const preview = cleanupPreviews.get(i.user.id);
 if (!preview || preview.token!==token || preview.expires<=Date.now()) throw Error('รายการเคลียร์หมดเวลา เปิดเมนูใหม่อีกครั้ง');
 cleanupPreviews.delete(i.user.id);
 await i.deferReply(ephemeral);
 let closed=0, failed=0;
 for (const room of preview.rooms) {
  if (roomJobs.isBusy(room.id)) continue;
  try {
   const removed = await roomJobs.run(room.id,()=>removeFinishedOrderRoom(s,room.id,c.guild,
    id=>client.channels.fetch(id,{force:true}),{...room,adminId:i.user.id}));
   if (removed) {
    closed++;
    if (s.order(room.id)?.proof) await refreshOrder(room.id);
   }
  } catch (error) {
   failed++;
   safeError(error);
  }
 }
 const skipped = preview.rooms.length-closed-failed;
 await i.editReply({
  content:`**เคลียร์แล้ว ${closed} ห้อง** · ข้าม ${skipped} ห้อง · ลบไม่สำเร็จ ${failed} ห้อง`,
  components:[new Row().addComponents(button('shop-admin:cleanup','ดูรอบถัดไป'),button('shop-admin:home','กลับแผงจัดการ'))]
 });
 await refreshPanels();
}

function orderLookup(order) {
 const payload = orderPayload(order,true);
 payload.embeds[0].addFields(
  {name:'Discord ID ลูกค้า',value:order.user_id,inline:true},
  {name:'สลิป',value:order.proof?'แนบแล้ว':'ยังไม่ได้แนบ',inline:true},
  {name:'ส่งสินค้า',value:order.status==='delivered' ? (order.delivery_id ? 'ส่งแล้ว' : 'เปิดรับจากออเดอร์ของฉัน') : order.status==='sending' ? 'กำลังส่งหรือต้องตรวจผล' : 'ยังไม่ได้ส่ง',inline:true}
 );
 return payload;
}

const adminAction = (action,label,style) => button('shop-admin:'+action,label,style);
const adminRow = (...buttons) => new Row().addComponents(...buttons);

async function confirmDelivery(id,messageId,actor) {
 await deliveryJobs.run(id,async()=>{
  const order = s.order(id);
  if (order?.status!=='sending') throw Error('ใช้เฉพาะรายการที่ยังยืนยันผลการส่งไม่ได้');
  const message = await findDeliveryMessage(order,messageId);
  s.completeDelivery(id,message.id,actor);
 });
 await refreshOrder(id);
}

function previewPayload(draft,view) {
 return appearancePreview(s,draft,view,c.minutes);
}
async function stageAppearance(i,patch,view,banner) {
 const draft = {token:randomUUID(),patch,banner,expires:Date.now()+120_000};
 appearanceDrafts.set(i.user.id,draft);
 const payload = previewPayload(draft,view);
 if (i.deferred) return await i.editReply(payload);
 return await i.reply({...payload,flags:MessageFlags.IsComponentsV2|MessageFlags.Ephemeral});
}
async function handleAppearancePreview(i,action,arg,token) {
 if (!i.isButton()) return false;
 if (action==='preview-current') {
  await i.reply({...previewPayload(null,'shop'),flags:MessageFlags.IsComponentsV2|MessageFlags.Ephemeral});
  return true;
 }
 if (action==='preview-view') {
  const draft = token ? appearanceDrafts.get(i.user.id) : null;
  if (token && (draft?.token!==token || draft.expires<=Date.now())) throw Error('ฉบับร่างหมดเวลา กรุณาเปิดตั้งค่าอีกครั้ง');
  await i.deferUpdate();
  await i.editReply({...previewPayload(draft,arg),attachments:[]});
  return true;
 }
 if (action==='preview-apply' || action==='preview-discard') {
  const draft = appearanceDrafts.get(i.user.id);
  if (draft?.token!==arg || draft.expires<=Date.now()) throw Error('ฉบับร่างหมดเวลา กรุณาเปิดตั้งค่าอีกครั้ง');
  appearanceDrafts.delete(i.user.id);
  if (action==='preview-apply') s.saveAppearance(draft.patch,i.user.id,draft.banner);
  const result = new ContainerBuilder()
   .addTextDisplayComponents(new TextDisplayBuilder().setContent(
    action==='preview-apply'?'**บันทึกตั้งค่าหน้าร้านแล้ว**':'**ทิ้งฉบับร่างแล้ว**'))
   .addActionRowComponents(adminRow(adminAction('extras','กลับตั้งค่าหน้าร้าน')));
  await i.update({components:[result],attachments:[]});
  if (action==='preview-apply') await refreshPanels();
  return true;
 }
 return false;
}
async function handleExtras(i,action,arg,token) {
 if (await handleAppearancePreview(i,action,arg,token)) return true;
 const field = name => (i.fields.fields.has(name) ? i.fields.getTextInputValue(name) ?? '' : '').trim();
 const reply = (content,components=[]) => i.reply({content,components,...ephemeral});
 if (i.isButton()) {
  if (action==='extras') {
   await reply('**ตั้งค่าหน้าร้าน** เลือกสิ่งที่ต้องการแก้',[
    adminRow(new StringSelectMenuBuilder().setCustomId('shop-admin:appearance-menu').setPlaceholder('เลือกหมวดตั้งค่า')
     .addOptions(
      {label:'ชื่อร้านและข้อความ',value:'copy'},
      {label:'ข้อความปุ่ม',value:'labels'},
      {label:'ชื่อหมวด',value:'categories'},
      {label:'สีและเวลาชำระ',value:'style'},
      {label:'ปุ่มนำทาง',value:'navigation'}
     )),
    adminRow(adminAction('preview-current','ดูตัวอย่าง',BS.Primary),adminAction('banner-menu','จัดการแบนเนอร์'),adminAction('settings','ข้อมูลร้านและรับเงิน'),adminAction('publish','ลงหน้าร้าน'),adminAction('home','กลับแผงจัดการ'))
   ]);
  } else if (action==='banner-menu') {
   await reply('**จัดการแบนเนอร์หน้าร้าน**',[
    adminRow(adminAction('preview-current','ดูแบนเนอร์ปัจจุบัน'),adminAction('banner','เปลี่ยนรูป',BS.Primary),adminAction('banner-default','คืนรูปเดิม'),adminAction('banner-hide','ซ่อนรูป'),adminAction('extras','กลับตั้งค่าหน้าร้าน'))
   ]);
  } else if (action==='inventory') {
   await reply('**สินค้าและสต็อก**',[
    adminRow(adminAction('pick:edit:0','แก้สินค้า'),adminAction('pick:sale:0','ลดราคา'),adminAction('coupon-list','คูปอง')),
    adminRow(adminAction('stock','ดูสต็อก'),adminAction('pick:stock:0','เติมสต็อก',BS.Success),adminAction('pick:import:0','เติมจากไฟล์'),adminAction('pick:remove:0','ลบสต็อก',BS.Danger)),
    adminRow(adminAction('alerts','ตั้งเตือนสต็อก'),adminAction('home','กลับแผงจัดการ'))
   ]);
  } else if (action==='orders-tools') {
   await reply('**จัดการออเดอร์**',[
    adminRow(adminAction('find-order','ค้นหาออเดอร์'),adminAction('delivery-list','รายการส่งค้าง'),adminAction('refunds','รายการคืนเงิน')),
    adminRow(adminAction('messages','ข้อความลูกค้า'),adminAction('cleanup','เคลียร์ห้อง'),adminAction('test-start','ออเดอร์ทดสอบ')),
    adminRow(adminAction('activity','ประวัติการจัดการ'),adminAction('home','กลับแผงจัดการ'))
   ]);
  } else if (action==='appearance' && Object.hasOwn(appearanceFields,arg)) {
   await i.showModal(appearanceForm(arg,s.appearance()));
  } else if (action==='banner') {
   await i.showModal(bannerForm());
  } else if (action==='banner-default' || action==='banner-hide') {
   await stageAppearance(i,{bannerMode:action==='banner-hide'?'none':'default'},'shop',null);
  } else if (action==='coupon-list') {
   const lines = s.recentCoupons().map(coupon=>{
    const active = coupon.active && (coupon.expires===null || coupon.expires>s.now()) && coupon.used<coupon.max_uses;
    const expiry = coupon.expires===null ? '' : ` · หมดอายุ <t:${Math.floor(coupon.expires/1000)}:R>`;
    return `${coupon.code} · ลด ${money(coupon.discount)} · ใช้ ${coupon.used}/${coupon.max_uses} · ${coupon.product_id===null?'ทุกสินค้า':'สินค้า #'+coupon.product_id} · ${active?'ใช้ได้':'ใช้ไม่ได้'}${expiry}`;
   });
   await reply('**คูปองล่าสุด**\n'+(lines.join('\n') || 'ยังไม่มีคูปอง'),[
    adminRow(adminAction('coupon-new','สร้างคูปอง',BS.Primary),adminAction('coupon-disable','ปิดคูปอง'))
   ]);
  } else if (action==='coupon-new') {
   await i.showModal(couponForm());
  } else if (action==='coupon-disable') {
   await i.showModal(modal('shop-admin:coupon-disable-save','ปิดคูปอง','รหัสคูปอง',20));
  } else if (action==='delivery-list') {
   const orders = s.all("SELECT id,status FROM orders WHERE status IN ('approved','sending') ORDER BY id LIMIT 25");
   const components = orders.length ? [adminRow(new StringSelectMenuBuilder().setCustomId('shop-admin:delivery-detail')
    .setPlaceholder('เลือกออเดอร์').addOptions(orders.map(order=>({label:`#${order.id} · ${orderStatusLabel(order.status)}`,value:String(order.id)}))))] : [];
   await reply(orders.length?'**รายการส่งค้าง** เลือกออเดอร์เพื่อจัดการ':'**ไม่มีรายการส่งค้าง**',components);
  } else if (action==='delivery-verify' || action==='delivery-retry') {
   if (!/^\d+$/.test(arg)) throw Error('เลขออเดอร์ไม่ถูกต้อง');
   await i.showModal(action==='delivery-verify'
    ? modal('shop-admin:delivery-verify-save:'+arg,'ยืนยันข้อความที่ส่งแล้ว','Message ID ของข้อความที่บอทส่ง',20)
    : modal('shop-admin:delivery-retry-save:'+arg,'ส่งสินค้าอีกครั้ง','พิมพ์ ยืนยัน เพื่อยอมรับความเสี่ยงส่งซ้ำ',20));
  } else if (action==='test-start') {
   const id = Date.now();
   testOrders.set(i.user.id,{id,stage:'proof',expires:id+5*60*1000});
   await reply('**🧪 ออเดอร์ทดสอบ**\nยอดตัวอย่าง 1.00 บาท ใช้รูปตัวอย่างแนบเป็นสลิปได้เลย โดยไม่ต้องโอนเงินจริง',[
    adminRow(adminAction('test-proof:'+id,'แนบสลิปทดสอบ',BS.Primary))
   ]);
  } else if (action==='test-proof' || action==='test-send') {
   const test = testOrders.get(i.user.id);
   const stage = action==='test-proof'?'proof':'send';
   if (test?.id!==Number(arg) || test.expires<=Date.now() || test.stage!==stage) throw Error('ออเดอร์ทดสอบหมดอายุ เปิดใหม่อีกครั้ง');
   if (stage==='proof') {
    await i.showModal(slipModal(test.id).setCustomId('shop-admin:test-proof-save:'+test.id));
   } else {
    test.stage='sending';
    try {
     await i.deferReply(ephemeral);
     const order = {id:test.id,test:true,name:'สินค้าจำลอง',price:100,method:'promptpay',paid_at:Date.now()};
     const payload = receiptDelivery(order,'โค้ดตัวอย่าง TEST-ONLY',s.appearance());
     const sent = await sendPrivateProduct(()=>client.users.send(i.user.id,{...payload,nonce:'t'+test.id,enforceNonce:true}));
     if (testOrders.get(i.user.id)===test) testOrders.delete(i.user.id);
     await i.editReply(sent ? '**ส่งบิลและโค้ดทดสอบเข้า DM แล้ว**' : {content:'**ส่ง DM ไม่ได้** ตัวอย่างบิลและโค้ดทดสอบอยู่ด้านล่าง',embeds:payload.embeds,files:payload.files});
    } catch (error) { test.stage='send'; throw error; }
   }
  } else return false;
  return true;
 }
 if (action==='appearance-menu' && i.isStringSelectMenu() && Object.hasOwn(appearanceFields,i.values[0])) {
  await i.showModal(appearanceForm(i.values[0],s.appearance()));
  return true;
 }
 if (action==='delivery-detail' && i.isStringSelectMenu()) {
  const order = s.order(Number(i.values[0]));
  if (!order || !['approved','sending'].includes(order.status)) throw Error('รายการนี้ไม่ค้างส่งแล้ว');
  await i.reply({...orderLookup(order),components:[adminRow(
   adminAction('delivery-verify:'+order.id,'ยืนยันข้อความที่ส่งแล้ว').setDisabled(order.status!=='sending'),
   adminAction('delivery-retry:'+order.id,'ส่งสินค้าอีกครั้ง',BS.Danger)
  )],...ephemeral});
  return true;
 }
 if (!i.isModalSubmit()) return false;
 if (action==='appearance-save' && Object.hasOwn(appearanceFields,arg)) {
  const patch = Object.fromEntries(appearanceFields[arg].map(([id])=>[id,field(id)||null]));
  if (arg==='style') {
   if (patch.color && !/^#?[0-9a-f]{6}$/i.test(patch.color)) throw Error('สีต้องเป็นเลข Hex 6 หลัก เช่น C32D36');
   if (patch.minutes && (!/^\d{1,3}$/.test(patch.minutes) || Number(patch.minutes)<1 || Number(patch.minutes)>120)) throw Error('เวลาชำระเงินต้องอยู่ระหว่าง 1–120 นาที');
   patch.color = patch.color ? parseInt(patch.color.replace(/^#/,''),16) : null;
   patch.minutes = patch.minutes ? Number(patch.minutes) : null;
  }
  const view = {categories:'categories',navigation:'categories'}[arg] ?? 'shop';
  await stageAppearance(i,patch,view);
 } else if (action==='banner-save') {
  const attachment = i.fields.getUploadedFiles('file',true).first();
  if (!attachment) throw Error('กรุณาแนบรูปแบนเนอร์');
  await i.deferReply(ephemeral);
  const image = await downloadProductImage(attachment);
  requireAdmin(i);
  await stageAppearance(i,{bannerMode:'custom'},'shop',image.bytes);
 } else if (action==='coupon-save') {
  const {code,discount,maxUses,productId,expires} = parseCouponFields(
   Object.fromEntries(['code','discount','uses','product','ends'].map(name=>[name,field(name)]))
  );
  s.createCoupon(code,discount,maxUses,productId,expires,i.user.id);
  await reply('**สร้างคูปอง '+code+' แล้ว**');
 } else if (action==='coupon-disable-save') {
  s.disableCoupon(field('value').toUpperCase(),i.user.id);
  await reply('**ปิดคูปองแล้ว**');
 } else if (action==='delivery-verify-save' || action==='delivery-retry-save') {
  const value = field('value');
  if (action==='delivery-retry-save' && value!=='ยืนยัน') throw Error('พิมพ์ ยืนยัน ก่อนส่งอีกครั้ง');
  if (action==='delivery-verify-save' && !/^\d{17,20}$/.test(value)) throw Error('Message ID ไม่ถูกต้อง');
  await i.deferReply(ephemeral);
  if (action==='delivery-verify-save') await confirmDelivery(Number(arg),value,i.user.id);
  else await deliver(Number(arg),true);
  await i.editReply('**บันทึกผลการส่งสินค้าแล้ว**');
 } else if (action==='test-proof-save') {
  const test = testOrders.get(i.user.id);
  if (test?.id!==Number(arg) || test.expires<=Date.now() || test.stage!=='proof') throw Error('ออเดอร์ทดสอบหมดอายุ');
  const proof = i.fields.getUploadedFiles('proof',true).first();
  if (!proof || !['image/png','image/jpeg','image/webp'].includes(proof.contentType) || proof.size>8*1024*1024) throw Error('ใช้ PNG JPG WEBP ขนาดไม่เกิน 8MB');
  test.stage='send';
  await reply('**🧪 รับสลิปทดสอบแล้ว** กดยืนยันเพื่อส่งบิลและโค้ดตัวอย่างเข้า DM ของคุณ',[
   adminRow(adminAction('test-send:'+test.id,'ยืนยันและส่งทดสอบ',BS.Success))
  ]);
 } else return false;
 return true;
}

function stockRemovalPage(productId,page=0) {
 const product = s.get('SELECT id FROM products WHERE id=?',productId);
 if (!product) throw Error('ไม่พบสินค้า');
 return stockRemovalPicker(product,s.availableStockPage(productId,page));
}

async function handleStockRemoval(i,action,arg,page) {
 if (action==='stock-remove-page' && i.isButton()) {
  await i.update(stockRemovalPage(Number(arg),Number(page)||0));
  return true;
 }
 const select = action==='stock-remove-select' && i.isStringSelectMenu();
 if (select || (action==='stock-remove-all' && i.isButton())) {
  const productId = Number(arg);
  const ids = s.stockRemovalCandidates(productId,select ? i.values.map(Number) : null);
  if (!ids.length) throw Error('รายการที่เลือกไม่มีสต็อกว่างให้ลบแล้ว');
  const token = randomUUID();
  stockRemovals.set(i.user.id,{token,productId,ids,expires:Date.now()+30000});
  const items = select ? ' · ชิ้น '+ids.map(id=>'#'+id).join(', ') : '';
  await i.update({
   content:`**ยืนยันลบสต็อกสินค้า #${productId} จำนวน ${ids.length} ชิ้น**${items}\nระบบจะตรวจสถานะอีกครั้งก่อนลบ`,
   components:[adminRow(adminAction('stock-remove-confirm:'+token,'ยืนยันลบ',BS.Danger),adminAction('stock-remove-page:'+productId+':0','กลับไปรายการสต็อก'))]
  });
  return true;
 }
 if (action==='stock-remove-confirm' && i.isButton()) {
  const pending = stockRemovals.get(i.user.id);
  if (!pending || pending.token!==arg || pending.expires<=Date.now()) throw Error('รายการยืนยันหมดอายุ กรุณาเลือกสต็อกอีกครั้ง');
  stockRemovals.delete(i.user.id);
  await i.deferUpdate();
  const removed = s.removeAvailableStock(pending.productId,pending.ids,i.user.id);
  await i.editReply({content:`**ลบสต็อกแล้ว ${removed} ชิ้น** · ข้าม ${pending.ids.length-removed} ชิ้น`,
   components:[adminRow(adminAction('stock-remove-page:'+pending.productId+':0','ดูสต็อกสินค้านี้'),adminAction('inventory','กลับสินค้าและสต็อก'))]});
  if (removed) await refreshPanels();
  return true;
 }
 return false;
}

async function handleAdminControl(i) {
 if (!i.customId?.startsWith('shop-admin:')) return false;
 requireAdmin(i);
 const [,action,arg,page] = i.customId.split(':');
 if (await handleStockRemoval(i,action,arg,page) || await handleExtras(i,action,arg,page)) return true;
 if (i.isButton()) {
  if (action === 'cleanup' || action === 'cleanup-confirm') await handleOrderCleanup(i,action,arg);
  else if (action === 'home') await i.reply({...adminHome(s.reviewOrders().length,s.pauseNotice()!==null),...ephemeral});
  else if (action==='pause') {
   await i.showModal(modal('shop-admin:pause-save','พักรับออเดอร์','ข้อความบนหน้าร้าน (เว้นว่างได้)',120,false));
  }
  else if (action==='resume') {
   s.setPauseNotice(null,i.user.id);
   await i.reply({content:'**เปิดรับออเดอร์แล้ว**',components:[new Row().addComponents(button('shop-admin:home','กลับแผงจัดการ'))],...ephemeral});
   await refreshPanels();
  }
  else if (action==='find-order') {
   await i.showModal(modal('shop-admin:order-search','ค้นหาออเดอร์','เลขออเดอร์ หรือ Discord ID',21));
  }
  else if (action==='activity') {
   const lines = s.recentActivity().map(entry=>`<t:${Math.floor(entry.created/1000)}:f> · <@${entry.actor}> · ${entry.detail}`);
   await i.reply({
    embeds:[new EmbedBuilder().setColor(0xc32d36).setTitle('ประวัติการจัดการร้าน').setDescription(lines.join('\n') || 'ยังไม่มีรายการ')],
    components:[new Row().addComponents(button('shop-admin:home','กลับแผงจัดการ'))],...ephemeral
   });
  }
  else if (action === 'sales') {
   const {received,refunded} = s.salesToday();
   const low = s.products().filter(product=>product.remaining<=(c.stockThreshold || 2)).length;
   await i.reply({
    embeds:[new EmbedBuilder().setColor(0xc32d36).setTitle('📊 ภาพรวมร้านวันนี้')
     .setDescription('นับตามเวลาไทย')
     .addFields(
      {name:'ยอดรับที่ยืนยันแล้ว',value:`**${money(received.amount)}** · ${received.orders} ออเดอร์`,inline:true},
      {name:'คืนเงินเสร็จแล้ว',value:`${money(refunded.amount)} · ${refunded.orders} ออเดอร์`,inline:true},
      {name:'รอตรวจยอด',value:`${s.reviewOrders().length} ออเดอร์`,inline:true},
      {name:'ของหมดหรือเหลือน้อย',value:`${low} รายการ`,inline:true}
     )],
    components:[new Row().addComponents(button('shop-admin:home','กลับแผงจัดการ'))],...ephemeral
   });
  }
  else if (action === 'add') await i.showModal(productForm());
  else if (action==='pick' || action==='pick-page') {
   const picker = productPicker(s.all('SELECT id,name FROM products ORDER BY id'),arg,Number(page)||0);
   if (action==='pick-page' && i.message.flags.has(MessageFlags.Ephemeral)) await i.update(picker);
   else await i.reply({...picker,...ephemeral});
  }
  else if (action === 'queue') await i.reply({...queuePayload(),...ephemeral});
  else if (action === 'refunds' || action === 'messages') await i.reply({...adminFollowUpPayload(action),...ephemeral});
  else if (action === 'stock') await i.reply({...stockPayload(),...ephemeral});
  else if (action === 'publish') await i.reply({...publishPicker(),...ephemeral});
  else if (action === 'alerts') await i.showModal(modal('shop-admin:alert-save','ตั้งเตือนสต็อก','เตือนเมื่อเหลือกี่ชิ้น · 0 คือปิดแจ้งเตือน'));
  else if (action === 'settings') await i.reply({...settingsPanel(s.settings()),...ephemeral});
  else throw Error('เปิดแผงจัดการร้านใหม่');
  return true;
 }
 if (action==='pause-save' && i.isModalSubmit()) {
  const notice = i.fields.getTextInputValue('value')?.trim() || 'ขออภัย ร้านพักรับออเดอร์ชั่วคราว';
  s.setPauseNotice(notice,i.user.id);
  await i.reply({content:'**พักรับออเดอร์ใหม่แล้ว** ลูกค้าที่สั่งไว้ยังส่งสลิปได้',components:[new Row().addComponents(button('shop-admin:resume','เปิดรับออเดอร์',BS.Success))],...ephemeral});
  await refreshPanels();
  return true;
 }
 if (action==='order-search' && i.isModalSubmit()) {
  const ids = s.findOrders(i.fields.getTextInputValue('value').trim());
  if (!ids.length) await i.reply({content:'ไม่พบออเดอร์',...ephemeral});
  else if (ids.length===1) await i.reply({...orderLookup(s.order(ids[0])),...ephemeral});
  else {
   const options = ids.map(id=>{
    const order = s.order(id);
    return {label:`ออเดอร์ #${id} · ${orderStatusLabel(order.status)}`.slice(0,100),value:String(id)};
   });
   await i.reply({content:`**พบ ${ids.length} ออเดอร์ล่าสุด** เลือกรายการที่ต้องการดู`,components:[
    new Row().addComponents(new StringSelectMenuBuilder().setCustomId('shop-admin:order-result')
     .setPlaceholder('เลือกออเดอร์').addOptions(options))
   ],...ephemeral});
  }
  return true;
 }
 if (action==='order-result' && i.isStringSelectMenu()) {
  const order = s.order(Number(i.values[0]));
  if (!order) throw Error('ไม่พบออเดอร์');
  await i.reply({...orderLookup(order),...ephemeral});
  return true;
 }
 if (action === 'selected' && i.isStringSelectMenu()) {
  const id = Number(i.values[0]);
  const product = s.get('SELECT * FROM products WHERE id=?',id);
  if (!product) throw Error('ไม่พบสินค้า');
  if (arg === 'edit') await i.showModal(productForm(product));
  else if (arg === 'sale') await i.showModal(saleForm(product,s.now()));
  else if (arg === 'stock') await i.showModal(stockLinesForm(id));
  else if (arg === 'import') await i.showModal(importForm(id));
  else if (arg === 'remove') await i.reply({...stockRemovalPage(id),...ephemeral});
  else throw Error('เปิดแผงจัดการร้านใหม่');
  return true;
 }
 if (action === 'publish-room' && i.isChannelSelectMenu()) {
  await i.deferReply(ephemeral);
  const room = await channel(i.values[0]);
  if (room.guildId!==c.guild || room.type!==ChannelType.GuildText) throw Error('เลือกห้องข้อความในเซิร์ฟเวอร์ร้าน');
  requireAdmin(i);
  await i.editReply(`**${await publishShop(room)}** ${room}`);
  return true;
 }
 if (i.isModalSubmit() && action === 'save') {
  const name = i.fields.getTextInputValue('name').trim();
  if (!name) throw Error('กรอกชื่อสินค้าก่อนบันทึก');
  const price = parseBaht(i.fields.getTextInputValue('price'));
  const description = i.fields.fields.has('description') ? (i.fields.getTextInputValue('description') || '').trim() : '';
  const image = i.fields.fields.has('image') ? i.fields.getUploadedFiles('image')?.first() : null;
  const id = arg==='new' ? null : Number(arg);
  const active = id===null ? null : Number(i.fields.getStringSelectValues('active')[0]==='yes');
  await i.deferReply(ephemeral);
  await saveProduct(i,id,{name,price,description,image,active});
  return true;
 }
 if (i.isModalSubmit() && action === 'sale-save') {
  const value = i.fields.fields.has('sale') ? (i.fields.getTextInputValue('sale') ?? '').trim() : '';
  const price = value ? parseBaht(value) : null;
  const end = i.fields.fields.has('ends') ? (i.fields.getTextInputValue('ends') ?? '').trim() : '';
  const endsAt = price!==null && end ? parseSaleEnd(end) : null;
  s.setSalePrice(Number(arg),price,endsAt,i.user.id);
  await i.reply({
   content:price===null ? '**ปิดโปรแล้ว** · กลับไปใช้ราคาปกติ' : `**เปิดโปรแล้ว** · ราคาใหม่ **${money(price)}**${endsAt===null ? '' : `\nจบโปร <t:${Math.floor(endsAt/1000)}:F>`}`,
   components:[new Row().addComponents(button('shop-admin:home','กลับแผงจัดการ',BS.Primary))],...ephemeral
  });
  await refreshPanels();
  return true;
 }
 if (i.isModalSubmit() && action === 'alert-save') {
  const value = i.fields.getTextInputValue('value').trim();
  if (!/^\d{1,2}$/.test(value)) throw Error('ใส่ตัวเลข 0–99');
  const current = s.settings();
  const next = {...current,stockThreshold:Number(value)};
  s.saveSettings(current,next);
  Object.assign(c,next);
  s.resetStockAlerts(next.stockThreshold);
  await i.reply({content:next.stockThreshold ? `**ตั้งเตือนเมื่อสต็อกเหลือไม่เกิน ${next.stockThreshold} ชิ้น**`:'**ปิดแจ้งเตือนสต็อกแล้ว**',...ephemeral});
  return true;
 }
 if (i.isModalSubmit() && action === 'lines') {
  const lines = parseStockFile(Buffer.from(i.fields.getTextInputValue('lines'),'utf8'));
  await i.deferReply(ephemeral);
  await prepareStockPreview(i,Number(arg),lines);
  return true;
 }
 if (i.isModalSubmit() && action === 'import') {
  await i.deferReply(ephemeral);
  await prepareStockImport(i,Number(arg),i.fields.getUploadedFiles('file',true).first());
  return true;
 }
 throw Error('เปิดแผงจัดการร้านใหม่');
}
client.on('interactionCreate',async i=>{try{
 if (!i.inGuild() || !i.isRepliable()) return;
 watchPrivateReplies(i);
 if (await handleSettings(i,s,(next)=>Object.assign(c,next),registerGuild)) {
  await ensureAdminPanel();
  return;
 }
 if (!c.guild || i.guildId!==c.guild) return;
 if (!shopReady(c)) throw Error('ให้แอดมินตั้งค่า /settings ให้ครบก่อนใช้งานร้าน');
 if (await handleSupport(i)) return;
 if (await handleAdminControl(i)) return;
 if (i.isButton() && i.customId === 'catalog:orders') {
  const payload = myOrdersPayload(i.user.id);
  if (i.message.flags.has(MessageFlags.Ephemeral) && !i.message.flags.has(MessageFlags.IsComponentsV2)) {
   return await i.update(payload);
  }
  return await i.reply({...payload,...ephemeral});
 }
 if (i.isButton() && i.customId==='catalog:find-order') {
  return await i.showModal(modal('catalog:find-order-submit','ค้นหาออเดอร์ของฉัน','เลขออเดอร์ เช่น 123',20));
 }
 if (i.isModalSubmit() && i.customId==='catalog:find-order-submit') {
  const value = i.fields.getTextInputValue('value').normalize('NFKC').trim().replace(/^#\s*/,'');
  if (!/^\d+$/.test(value) || !Number.isSafeInteger(Number(value))) throw Error('กรอกเลขออเดอร์ เช่น 123');
  const order = s.buyerOrder(Number(value),i.user.id);
  if (!order) throw Error('ไม่พบออเดอร์นี้ในบัญชีของคุณ');
  const actions = [button('catalog:orders','กลับออเดอร์ของฉัน')];
  if (order.status==='delivered') {
   actions.unshift(button(`catalog:found-receipt:${order.id}`,'รับสินค้าและดูบิล',BS.Success));
  } else if (order.status==='expired' && s.canSubmitProof(order,i.user.id)) {
   actions.unshift(button(`catalog:found-slip:${order.id}`,'แนบสลิปย้อนหลัง',BS.Primary));
  } else if (order.channel_id && !order.room_close_at) {
   actions.unshift(new Button().setStyle(BS.Link).setLabel('เปิดห้องออเดอร์').setURL(channelLink(c.guild,order.channel_id)));
  }
  const ahead = reviewStatuses.includes(order.status) ? s.ahead(order) : undefined;
  return await i.reply({embeds:[orderCard(order,ahead)],components:[new Row().addComponents(...actions)],...ephemeral});
 }
 const receiptMenu = i.isStringSelectMenu() && i.customId==='catalog:download';
 if (receiptMenu || (i.isButton() && i.customId.startsWith('catalog:found-receipt:'))) {
  const id = Number(receiptMenu ? i.values[0] : i.customId.split(':')[2]);
  const stock = s.deliveredStock(id,i.user.id);
  if (!stock) throw Error('ไม่พบสินค้าที่คุณรับได้');
  return await i.reply({...receiptDelivery(s.order(id),stock.content,s.appearance()),...ephemeral});
 }
 const oldSlipMenu = i.isStringSelectMenu() && i.customId==='catalog:late-slip';
 if (oldSlipMenu || (i.isButton() && i.customId.startsWith('catalog:found-slip:'))) {
  const id = Number(oldSlipMenu ? i.values[0] : i.customId.split(':')[2]);
  const order = s.buyerOrder(id,i.user.id);
  if (order?.status!=='expired' || !s.canSubmitProof(order,i.user.id)) throw Error('ออเดอร์นี้ส่งสลิปย้อนหลังไม่ได้');
  return await i.showModal(slipModal(order.id,true));
 }
 if (i.isButton() && i.customId === 'catalog:help') {
  return await i.reply({
   embeds:[new EmbedBuilder().setColor(0xc32d36).setTitle('วิธีซื้อ 3 ขั้นตอน')
    .setDescription('**1. เลือกสินค้า** · แตะเมนูเลือกสินค้า แล้วกดซื้อ\n**2. โอนเงิน** · เปิดห้องออเดอร์แล้วเลือกวิธีจ่าย\n**3. แนบสลิป** · กดแนบสลิปในห้องออเดอร์ แล้วรอตรวจยอด\n\nกด **ออเดอร์ของฉัน** ที่หน้าร้านเพื่อกลับมาดูสถานะได้ทุกเมื่อ')],
   ...ephemeral
  });
 }
 if (i.isButton() && i.customId==='catalog:search') {
  return await i.showModal(modal('catalog:search-submit','ค้นหาสินค้า','พิมพ์ชื่อสินค้าบางส่วน',60));
 }
 if (i.isModalSubmit() && i.customId==='catalog:search-submit') {
  const query = i.fields.getTextInputValue('value').trim();
  if (!query) throw Error('พิมพ์ชื่อสินค้าก่อนค้นหา');
  const filter = `search-${randomUUID()}`;
  catalogSearches.set(i.user.id,{filter,query,expires:Date.now()+5*60*1000});
  return await i.reply({...catalogPayload(s,0,true,filter,query),flags:MessageFlags.IsComponentsV2|MessageFlags.Ephemeral});
 }
 if (i.isButton() && (i.customId==='catalog:open' || /^catalog:(filter|page):/.test(i.customId))) {
  const [,,value,pageFilter] = i.customId.split(':');
  const paging = i.customId.startsWith('catalog:page:');
  const filter = paging ? pageFilter : value;
  const search = catalogSearches.get(i.user.id);
  if (filter?.startsWith('search-') && (search?.filter!==filter || search.expires<=Date.now())) {
   throw Error('ผลค้นหาหมดอายุ กดค้นหาสินค้าใหม่');
  }
  const query = search?.filter===filter ? search?.query : '';
  const payload = catalogPayload(s,paging ? Number(value)||0 : 0,true,filter,query);
  if (i.message.flags.has(MessageFlags.Ephemeral) && i.message.flags.has(MessageFlags.IsComponentsV2)) {
   return await i.update({...payload,attachments:[]});
  }
  return await i.reply({...payload,flags:MessageFlags.IsComponentsV2|MessageFlags.Ephemeral});
 }
 if (i.isButton() && i.customId.startsWith('catalog:restock:')) {
  const [,,id,page,state,filter] = i.customId.split(':');
  if (!i.message.flags.has(MessageFlags.Ephemeral)) throw Error('เปิดรายละเอียดสินค้าก่อนตั้งแจ้งเตือน');
  await i.deferUpdate();
  const product = s.products().find(product=>product.id===Number(id));
  if (!product) throw Error('สินค้านี้ปิดขายแล้ว');
  s.setRestockFollow(product.id,i.user.id,state==='on');
  const following = s.followsRestock(product.id,i.user.id);
  return await i.editReply({...productPayload(s,product,Number(page)||0,following,filter),attachments:[]});
 }
 const productSelect = i.isStringSelectMenu() && /^(catalog:select:|buy:)/.test(i.customId);
 if (productSelect || (i.isButton() && i.customId.startsWith('catalog:product:'))) {
  const parts = i.customId.split(':');
  const isNewSelect = productSelect && parts[0]==='catalog';
  const id = Number(productSelect ? i.values[0] : parts[2]);
  const page = isNewSelect ? parts[2] : parts[3];
  const filter = isNewSelect ? parts[3] : parts[4];
  const product = s.products().find(product=>product.id===id);
  if (!product) throw Error('สินค้านี้ปิดขายแล้ว');
  const payload = productPayload(s,product,Number(page)||0,s.followsRestock(product.id,i.user.id),filter);
  if (i.message.flags.has(MessageFlags.Ephemeral) && i.message.flags.has(MessageFlags.IsComponentsV2)) {
   await i.deferUpdate();
   return await i.editReply({...payload,attachments:[]});
  }
  await i.deferReply({flags:MessageFlags.Ephemeral});
  return await i.editReply(payload);
 }
 if (i.isButton() && i.customId.startsWith('coupon:')) {
  const [,id,price] = i.customId.split(':');
  return await i.showModal(modal(`coupon-quote:${id}:${price}`,'ใช้คูปอง','กรอกรหัสคูปอง',20));
 }
 if (i.isModalSubmit() && i.customId.startsWith('coupon-quote:')) {
  const [,id,shownPrice] = i.customId.split(':');
  const product = s.products().find(row=>row.id===Number(id));
  if (!product?.remaining || s.pauseNotice()!==null) throw Error('สินค้านี้ยังไม่พร้อมขาย');
  const price = effectivePrice(product,s.now());
  if (price!==Number(shownPrice)) throw Error('ราคาสินค้าเปลี่ยนแล้ว เปิดดูสินค้าใหม่');
  const code = i.fields.getTextInputValue('value').trim().toUpperCase();
  const discount = s.couponDiscount(code,product.id,price);
  const total = price-discount;
  return await i.reply({content:`คูปอง **${code}** ลด **${money(discount)}**\nยอดชำระ **${money(total)}**`,
   components:[new Row().addComponents(button(`buycoupon:${id}:${price}:${code}:${total}`,'ยืนยันสั่งซื้อ',BS.Success))],...ephemeral});
 }
 const buyButton = i.isButton() && /^(buyconfirm|buycoupon):/.test(i.customId);
 const oldBuyForm = i.isModalSubmit() && i.customId.startsWith('buyform:');
 if (buyButton || oldBuyForm) {
  const [,productId,shownPrice,code,total] = i.customId.split(':');
  await i.deferReply(ephemeral);
  let order;
  try {
   order = s.reserve(i.user.id,Number(productId),'',s.appearance().minutes ?? c.minutes,Number(shownPrice),code ? {code,total:Number(total)} : null);
  } catch (error) {
   if (error.openOrder) {
    const existing = error.openOrder;
    const next = existing.channel_id
     ? new Button().setStyle(BS.Link).setLabel('เปิดออเดอร์เดิม').setURL(channelLink(c.guild,existing.channel_id))
     : button('catalog:orders','ออเดอร์ของฉัน',BS.Primary);
    return await i.editReply({content:`**คุณมีออเดอร์ #${existing.id} ค้างอยู่** ทำรายการต่อจากออเดอร์เดิมได้เลย`,components:[new Row().addComponents(next)]});
   }
   if (error.priceChanged) {
    return await i.editReply({content:'**ราคาสินค้าเปลี่ยนแล้ว** เปิดดูราคาล่าสุดก่อนสั่งซื้ออีกครั้ง',
     components:[new Row().addComponents(button(`catalog:product:${Number(productId)}:0`,'ดูราคาล่าสุด',BS.Primary))]});
   }
   throw error;
  }
  let room;
  try { room = await roomJobs.run(order.id,()=>ensureOrderRoom(order,i.guild)); }
  catch (error) {
   if (s.order(order.id)?.status==='pending') s.release(order.id,'cancelled','สร้างห้องไม่สำเร็จ');
   await refreshPanels();
   throw error;
  }
  await i.editReply({
   content:`**ออเดอร์ #${order.id} · ยอดชำระ ${money(order.price)}**\n**③ เปิดห้องชำระเงิน** เลือกวิธีจ่าย แล้วกลับมาแนบสลิปในห้องนั้น`,
   components:[new Row().addComponents(new Button().setStyle(BS.Link).setLabel('เปิดห้องชำระเงิน').setURL(room.url))]
  });
  await refreshPanels();
  return;
 }
 if (i.isButton() && i.customId.startsWith('stock-import:')) {
  requireAdmin(i);
  const [, action, token] = i.customId.split(':');
  const pending = stockImports.get(i.user.id);
  if (!pending || pending.token !== token || pending.expires <= Date.now()) {
   throw Error('รายการนำเข้าหมดอายุแล้ว ใช้ /stock-import ใหม่');
  }
  if (action === 'cancel') {
   stockImports.delete(i.user.id);
   return await i.update({content:'ยกเลิกการเติมสต็อก', components:[]});
  }
  const result = s.importStock(pending.productId,pending.lines,i.user.id);
  s.resetStockAlerts(c.stockThreshold ?? 2);
  stockImports.delete(i.user.id);
  await i.update({content:`เพิ่มสต็อก ${result.added} ชิ้น · ข้ามรายการซ้ำ ${result.skipped} บรรทัด`, components:[]});
  await refreshPanels();
  return;
 }
 if (i.isModalSubmit() && /^(?:late-)?slip:/.test(i.customId)) {
  const [kind,id] = i.customId.split(':');
  const proof = i.fields.getUploadedFiles('proof',true).first();
  await i.deferReply(ephemeral);
  return await submitProof(i,Number(id),proof,kind==='late-slip');
 }
 if(i.isModalSubmit()){
 const [action,arg]=i.customId.split(':'),value=i.fields.getTextInputValue('value').trim();if(!value)throw Error('กรุณากรอกข้อมูล');await i.deferReply(ephemeral);
 requireAdmin(i);
 if(action==='stock'){s.tx(()=>{s.addStock(Number(arg),value);s.recordActivity(i.user.id,`เติมสินค้า #${Number(arg)} จำนวน 1 ชิ้น`)});s.resetStockAlerts(c.stockThreshold ?? 2);await i.editReply({content:'**เติมสต็อก 1 ชิ้นแล้ว**',components:[new Row().addComponents(button('shop-admin:home','กลับแผงจัดการ',BS.Primary))]});await refreshPanels();return}
 if(action==='reject'){s.release(Number(arg),'rejected',value.slice(0,500),i.user.id);await refreshOrder(Number(arg));await refreshQueue();await refreshPanels();return await i.editReply('ปฏิเสธรายการแล้ว')}
 if(action==='info'){s.requestInfo(Number(arg),value.slice(0,500));await refreshOrder(Number(arg));return await i.editReply('แจ้งขอหลักฐานเพิ่มแล้ว ให้ลูกค้าใช้ /pay ส่งใหม่')}
 if (action === 'refund') {
  const id = Number(arg);
  s.beginRefund(id,i.user.id,value);
  await i.editReply('**บันทึกว่ารอคืนเงินแล้ว** โอนคืนจริงก่อนกดปุ่มคืนเงินแล้ว');
  await refreshOrder(id);
  await refreshQueue();
  await refreshPanels();
  return;
 }
 if (action === 'approve') {
  const id = Number(arg);
  s.approve(id,i.user.id,value);
  await i.editReply('ยืนยันเงินแล้ว กำลังส่งสินค้า');
  try { if (s.order(id)?.status === 'approved') await deliver(id); }
  catch (error) {
   safeError(error);
   await i.editReply('ยืนยันเงินแล้ว แต่ยังยืนยันผลการส่งไม่ได้ ตรวจ DM ของลูกค้าก่อนใช้ /resend ห้ามคืนสต็อกชิ้นนี้');
  }
  await refreshQueue();
  await refreshPanels();
  return;
 }
 }
 if(i.isButton()){
 const [action,arg,method]=i.customId.split(':'),id=Number(arg),o=s.order(id);if(!o)throw Error('ไม่พบคำสั่งซื้อ');
 if (['approve','reject','info','refund'].includes(action)) {
  requireAdmin(i);
  if (!reviewStatuses.includes(o.status)) throw Error('รายการนี้ไม่อยู่ระหว่างตรวจ');
  if (action === 'refund') return await i.showModal(modal(`refund:${id}`,'บันทึกว่ารอคืนเงิน','เลขอ้างอิงจากยอดที่รับเข้าจริง'));
  if (action === 'approve') {
   return await i.showModal(modal(`approve:${id}`,'ยืนยันยอดเข้าจริง','เลขอ้างอิงจากรายการเงินจริง'));
  }
  return await i.showModal(modal(`${action}:${id}`,action==='reject'?'เหตุผลที่ปฏิเสธ':'ขอหลักฐานเพิ่ม','รายละเอียดสำหรับลูกค้า'));
 }
 if (action === 'refund-done') {
  requireAdmin(i);
  s.completeRefund(id,i.user.id);
  await i.reply({content:'**บันทึกสถานะคืนเงินแล้ว**',...ephemeral});
  await refreshOrder(id);
  return;
 }
 else if(o.user_id!==i.user.id)throw Error('รายการนี้เป็นของลูกค้าคนอื่น');
 if (action === 'status') {
  requireBuyerRoom(i,o);
  return await i.reply({embeds:orderPayload(o).embeds,...ephemeral});
 }
 if (action==='receipt') {
  requireBuyerRoom(i,o);
  const stock = s.deliveredStock(id,i.user.id);
  if (!stock) throw Error('ไม่พบสินค้าที่คุณรับได้');
  return await i.reply({...receiptDelivery(o,stock.content,s.appearance()),...ephemeral});
 }
 if (action === 'paid') {
  requireBuyerRoom(i,o);
  if (!s.canSubmitProof(o,i.user.id)) throw Error(o.method ? 'ออเดอร์นี้ยังส่งสลิปเพิ่มไม่ได้' : 'เลือกวิธีชำระก่อนแนบสลิป');
  return await i.showModal(slipModal(id));
 }
 await i.deferReply({flags:MessageFlags.Ephemeral});
 if (action === 'method') {
  requireBuyerRoom(i,o);
  if (!['promptpay','truemoney'].includes(method)) throw Error('วิธีจ่ายไม่ถูกต้อง');
  await roomJobs.run(id,async()=>{
   s.tx(()=>{
    s.expire();
    if(s.order(id).status!=='pending') throw Error('หมดเวลาชำระเงินหรือส่งสลิปแล้ว');
    s.run('UPDATE orders SET method=? WHERE id=?',method,id);
   });
   await refreshBuyerOrder(id);
  });
  await i.editReply('**อัปเดตวิธีชำระแล้ว** ดูยอดและแนบสลิปจากการ์ดออเดอร์ด้านบน');
  return;
 }
 if(action==='cancel'){if(o.status!=='pending')throw Error('ส่งหลักฐานแล้ว ให้แอดมินจัดการ');s.release(id,'cancelled');await refreshOrder(id);await refreshPanels();return await i.editReply('ยกเลิกแล้ว หากโอนเงินแล้วให้ติดต่อแอดมิน')}

 }
 if(i.isChatInputCommand()){
 const n=i.commandName,opt=i.options;if(n!=='pay')requireAdmin(i);
 if(n==='stock-add')return await i.showModal(modal(`stock:${opt.getInteger('product')}`,'เติมสต็อกหนึ่งชิ้น','ข้อความสินค้าที่จะส่งให้ผู้ซื้อ'));
 await i.deferReply({flags:MessageFlags.Ephemeral});
 if (n === 'product-add' || n === 'product-edit') {
  const adding = n === 'product-add';
  const active = adding ? null : opt.getBoolean('active');
  return await saveProduct(i,adding?null:opt.getInteger('id'),{
   name:opt.getString('name'),price:opt.getInteger('satang'),
   description:opt.getString('description')?.trim(),image:opt.getAttachment('image'),
   active:active===null?null:Number(active)
  });
 }
 if (n === 'stock-import') return await prepareStockImport(i,opt.getInteger('product'),opt.getAttachment('file',true));
 if (n === 'stock-list') return await i.editReply(stockPayload());
 if (n === 'shop') return await i.editReply(`**${await publishShop(i.channel)}**`);
 if (n === 'queue') return await i.editReply(queuePayload());
 if(n==='order'){const o=s.order(opt.getInteger('id'));if(!o)throw Error('ไม่พบคำสั่งซื้อ');await i.editReply({...orderPayload(o,true),components:[]})}
 if (n === 'pay') {
  const order = s.get('SELECT * FROM orders WHERE channel_id=? AND user_id=?',i.channelId,i.user.id);
  requireBuyerRoom(i,order);
  return await submitProof(i,order.id,opt.getAttachment('proof',true));
 }
 if (n === 'delivery-confirm') {
  const id = opt.getInteger('order');
  await confirmDelivery(id,opt.getString('message'),i.user.id);
  return await i.editReply('บันทึกว่าส่งสินค้าแล้ว โดยไม่ได้ส่งข้อความซ้ำ');
 }
 if(n==='resend'){if(!opt.getBoolean('accept-duplicate-risk'))throw Error('ตรวจ DM และยอมรับความเสี่ยงส่งซ้ำก่อน');await deliver(opt.getInteger('order'),true);await i.editReply('จัดส่งแล้ว ลูกค้าตรวจ DM หรือรับสินค้าจากออเดอร์ของฉันได้')}
 return;
 }
 }catch(e){safeError(e);const msg=e.code===50035?'Discord ปฏิเสธรูปแบบข้อความ (50035) กรุณาแจ้งแอดมิน':e.code?'ทำรายการไม่สำเร็จ กรุณาตรวจสิทธิ์บอทหรือแจ้งแอดมิน':e.message;try{if(i.deferred&&i.isMessageComponent()&&i.message.flags.has(MessageFlags.IsComponentsV2))await i.followUp({content:msg,flags:MessageFlags.Ephemeral});else if(i.deferred||i.replied)await i.editReply({content:msg,components:[]});else await i.reply({content:msg,flags:MessageFlags.Ephemeral})}catch{}}});
async function sendPaymentNotices() {
 for (const notice of s.pendingNotices()) {
  try {
   const room = await channel(notice.channel_id);
   const order = s.order(notice.id);
   if (order?.status !== 'pending') continue;
   await room.send({
    content:`<@${notice.user_id}> ใกล้หมดเวลาชำระเงิน ถ้าโอนแล้วกด **แนบสลิป** ตอนนี้ หากห้องถูกลบแล้วให้ส่งจาก **ออเดอร์ของฉัน** ที่หน้าร้าน`,
    allowedMentions:{users:[notice.user_id]},
    nonce:`r${notice.id}`,enforceNonce:true
   });
   s.run('INSERT OR IGNORE INTO payment_notices(order_id,kind) VALUES(?,?)',notice.id,notice.kind);
  } catch (error) {
   safeError(error);
  }
 }
}

async function sendOverdueReviewNotices() {
 const notices = s.overdueReviewNotices();
 if (!notices.length) return;
 const room = await privateAdminRoom();
 for (const {id,admin_message_id} of notices) {
  if (!['review','late_review'].includes(s.order(id)?.status)) continue;
  try {
   const link = admin_message_id ? ` · [เปิดรายการตรวจยอด](${channelLink(c.guild,room.id)}/${admin_message_id})` : '';
   await room.send({content:`⏰ **ออเดอร์ #${id}** รอตรวจยอดเกิน 15 นาที${link}`,nonce:`rv${id}`,enforceNonce:true});
   s.run("INSERT OR IGNORE INTO payment_notices(order_id,kind) VALUES(?,'review_overdue')",id);
  } catch (error) { safeError(error); }
 }
}

let ticking=false;
let saleRefreshPending=false;
async function tick() {
 if (ticking) return;
 ticking=true;
 try {
  for (const [userId, pending] of stockImports) {
   if (pending.expires <= Date.now()) stockImports.delete(userId);
  }
  for (const [userId, preview] of cleanupPreviews) {
   if (preview.expires<=Date.now()) cleanupPreviews.delete(userId);
  }
  for (const [userId, search] of catalogSearches) {
   if (search.expires<=Date.now()) catalogSearches.delete(userId);
  }
  for (const [userId,test] of testOrders) {
   if (test.expires<=Date.now()) testOrders.delete(userId);
  }
  for (const [userId,pending] of stockRemovals) {
   if (pending.expires<=Date.now()) stockRemovals.delete(userId);
  }
  const now = Date.now();
  for (const [key,draft] of appearanceDrafts) if (draft.expires<=now) appearanceDrafts.delete(key);
  for (const cache of [reviewStamps,buyerStamps]) {
   for (const [key,entry] of cache) if (entry.expires+refreshWindow<=now) cache.delete(key);
  }
  if (s.expireSales()) saleRefreshPending=true;
  if (saleRefreshPending) saleRefreshPending=!(await refreshPanels());
  const expired=s.tx(()=>s.expire());
  for (const order of expired) await refreshOrder(order.id);
  for (const {id} of s.finishedRooms()) {
   if (roomJobs.isBusy(id)) continue;
   try {
    const closed = await roomJobs.run(id,()=>removeFinishedOrderRoom(s,id,c.guild,
     channelId=>client.channels.fetch(channelId,{force:true})));
    if (closed && s.order(id)?.proof) await refreshOrder(id);
   } catch (error) { safeError(error); }
  }
  await sendPaymentNotices();
  try { await sendOverdueReviewNotices(); } catch (error) { safeError(error); }
  for (const {id} of s.all('SELECT id FROM order_support WHERE admin_message_id IS NULL AND answer IS NULL ORDER BY id LIMIT 10')) {
   try { await sendSupportNotice(id); } catch (error) { safeError(error); }
  }
  await sendRestockNotices();
  try { await sendStockAlerts(); } catch (error) { safeError(error); }
  for(const order of s.all("SELECT id FROM orders WHERE status='approved'")) {
   try { await deliver(order.id); } catch (error) { safeError(error); }
  }
  await refreshQueue();
  for (const {id} of s.all("SELECT id FROM orders WHERE status='refund_pending' AND proof IS NOT NULL")) {
   try { await refreshReview(id); } catch (error) { safeError(error); }
  }
  if(expired.length) await refreshPanels();
 } catch (error) {
  safeError(error);
 } finally {
  ticking=false;
 }
}
client.once('clientReady',async()=>{
 console.log('Shop bot online');
 const guilds = [...client.guilds.cache.values()].filter(guild=>!c.guild || guild.id===c.guild);
 await Promise.all(guilds.map(registerGuild));
 if (shopReady(c)) {
  await ensureAdminPanel();
  await refreshPanels();
  await tick();
 }
 setInterval(()=>{if(shopReady(c))void tick()},30000).unref();
});
client.on('guildCreate',guild=>{if(!c.guild||guild.id===c.guild)void registerGuild(guild)});
client.on('error',safeError);process.on('SIGTERM',()=>{client.destroy();s.close();process.exit(0)});await client.login(c.token);
