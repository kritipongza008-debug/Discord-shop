import {randomUUID} from 'node:crypto';
import {Client,GatewayIntentBits,ChannelType,PermissionFlagsBits as P,ActionRowBuilder as Row,ButtonBuilder as Button,ButtonStyle as BS,ModalBuilder as Modal,TextInputBuilder as Input,TextInputStyle as IS,AttachmentBuilder,MessageFlags} from 'discord.js';
import {deliverOrder} from './delivery.js';
import qr from 'qrcode';import generatePayload from 'promptpay-qr';import {config} from './config.js';
import {catalogPayload,downloadProductImage} from './catalog.js';
import {commands,settingsCommand} from './commands.js';
import {handleSettings,hasShopRole,shopReady} from './settings.js';import {Store,reviewStatuses} from './store.js';
import {downloadStockFile} from './stock-import.js';
process.umask(0o077);
const c=config(),s=new Store(c.db),client=new Client({intents:[GatewayIntentBits.Guilds],allowedMentions:{parse:[]}});
if (!s.settings() && c.legacy) s.saveSettings(null,c.legacy);
Object.assign(c,s.settings());
const stockImports = new Map();

async function registerGuild(guild) {
 try {
  const guildCommands = c.guild === guild.id ? commands : [settingsCommand];
  await guild.commands.set(guildCommands);
 } catch (error) {
  console.error('Slash command registration failed for guild',guild.id,error.code || error.name);
 }
}

const money=n=>(n/100).toFixed(2)+' บาท';
const button=(id,label,style=BS.Secondary)=>new Button().setCustomId(id).setLabel(label).setStyle(style);
const isAdmin=i=>hasShopRole(i,c.role);
function requireAdmin(i){if(!isAdmin(i))throw Error('เฉพาะแอดมินร้านเท่านั้น')}
function modal(id,title,label){return new Modal().setCustomId(id).setTitle(title).addComponents(new Row().addComponents(new Input().setCustomId('value').setLabel(label).setStyle(IS.Paragraph).setRequired(true).setMaxLength(3500)))}
const safeError=e=>{console.error('Operation failed',e.code||e.name||'Error')};
async function channel(id){const ch=await client.channels.fetch(id);if(!ch?.isTextBased())throw Error('ไม่พบห้อง กรุณาตรวจการตั้งค่าและสิทธิ์');return ch}
function orderText(o){let state={pending:'รอชำระเงิน',review:'รอตรวจสอบการชำระเงิน',info:'รอหลักฐานเพิ่ม (ยังเก็บตำแหน่งคิว)',late_review:'รอตรวจสลิปย้อนหลัง ยังไม่ได้จองสต็อก',late_info:'รอหลักฐานย้อนหลังเพิ่มเติม',approved:'ยืนยันเงินแล้ว รอส่งสินค้า',sending:'กำลังส่ง/ต้องตรวจผลการส่ง',delivered:'ส่งสินค้าแล้ว',rejected:'ปฏิเสธ',expired:'หมดเวลาจอง',cancelled:'ยกเลิก'}[o.status];return `🧾 คำสั่งซื้อ #${o.id}\nสินค้า: ${o.name}\nรายละเอียด: ${(o.description||'').slice(0,300)}\nยอด: ${money(o.price)}\nชื่อผู้โอน: ${o.payer}\nวิธีจ่าย: ${o.method||'ยังไม่เลือก'}\nสถานะ: ${state}${reviewStatuses.includes(o.status)?`\nมีอีก ${s.ahead(o)} คิวก่อนคุณ`:''}${o.status==='pending'?`\nหมดเวลาจอง <t:${Math.floor(o.expires/1000)}:R>`:''}${o.status==='expired'&&o.method?'\nถ้าโอนแล้ว ใช้ /pay แนบสลิปย้อนหลังในห้องนี้':''}${o.reason?`\nหมายเหตุ: ${o.reason}`:''}`}
function orderButtons(o){return o.status==='pending'?[new Row().addComponents(button(`method:${o.id}:promptpay`,'QR พร้อมเพย์'),button(`method:${o.id}:truemoney`,'TrueMoney'),button(`paid:${o.id}`,'ชำระแล้ว',BS.Primary),button(`cancel:${o.id}`,'ยกเลิก',BS.Danger))]:[]}
function adminButtons(o){return reviewStatuses.includes(o.status)?[new Row().addComponents(button(`approve:${o.id}`,'ตรวจเงินเข้าแล้ว / ยืนยัน',BS.Success),button(`info:${o.id}`,'ขอหลักฐานเพิ่ม'),button(`reject:${o.id}`,'ปฏิเสธ',BS.Danger))]:[]}
async function refreshPanels(){
 const payload = catalogPayload(s);
 for (const panel of s.all('SELECT * FROM panels')) {
  try { await (await channel(panel.channel_id)).messages.edit(panel.message_id, {...payload, attachments: []}); }
  catch (error) { safeError(error); }
 }
}
async function refreshOrder(id){const o=s.order(id);if(!o)return;if(o.channel_id&&o.message_id)try{await (await channel(o.channel_id)).messages.edit(o.message_id,{content:orderText(o),components:orderButtons(o)})}catch(e){safeError(e)}
 if(o.proof)try{const ch=await channel(c.admin),payload={content:orderText(o)+`\nลูกค้า: <@${o.user_id}>\nห้อง: <#${o.channel_id}>\nหลักฐาน: ${o.proof}\nตรวจยอดเข้าจริงก่อนยืนยัน หากลิงก์หมดอายุ เปิดข้อความหลักฐานในห้องลูกค้า`,components:adminButtons(o)};if(o.admin_message_id)await ch.messages.edit(o.admin_message_id,payload);else{const m=await ch.send({...payload,nonce:`a${o.id}`,enforceNonce:true});s.run('UPDATE orders SET admin_message_id=? WHERE id=?',m.id,id)}}catch(e){safeError(e)}}
async function refreshQueue(){for(const o of s.reviewOrders())await refreshOrder(o.id)}
async function deliver(id,force=false){await deliverOrder(s,id,async(o,content)=>{await refreshOrder(id);const m=await (await channel(o.channel_id)).send({content:`✅ สินค้าสำหรับคำสั่งซื้อ #${id} — เก็บไฟล์นี้เป็นความลับ`,files:[new AttachmentBuilder(Buffer.from(content,'utf8'),{name:`order-${id}.txt`})],nonce:String(id),enforceNonce:true});return m.id},force);await refreshOrder(id)}
async function ensureOrderRoom(o,guild){const category=await guild.channels.fetch(c.category);if(category?.type!==ChannelType.GuildCategory)throw Error('ORDER_CATEGORY_ID ต้องเป็นหมวดหมู่');
 const ch=await guild.channels.create({name:`order-${o.id}`,type:ChannelType.GuildText,parent:c.category,permissionOverwrites:[{id:guild.id,deny:[P.ViewChannel]},{id:o.user_id,allow:[P.ViewChannel,P.ReadMessageHistory,P.SendMessages,P.AttachFiles],deny:[P.MentionEveryone,P.CreatePublicThreads,P.CreatePrivateThreads]},{id:c.role,allow:[P.ViewChannel,P.ReadMessageHistory,P.SendMessages]},{id:client.user.id,allow:[P.ViewChannel,P.ReadMessageHistory,P.SendMessages,P.AttachFiles,P.EmbedLinks]}]});s.run('UPDATE orders SET channel_id=? WHERE id=?',ch.id,o.id);const m=await ch.send({content:orderText(o),components:orderButtons(o)});s.run('UPDATE orders SET message_id=? WHERE id=?',m.id,o.id);return ch}
client.on('interactionCreate',async i=>{try{
 if (!i.inGuild()) return;
 if (await handleSettings(i,s,(next)=>Object.assign(c,next),registerGuild)) return;
 if (!c.guild || i.guildId!==c.guild) return;
 if (!shopReady(c)) throw Error('ให้แอดมินตั้งค่า /settings ให้ครบก่อนใช้งานร้าน');
 if (i.isButton() && i.customId === 'catalog:open') {
  await i.deferReply({flags: MessageFlags.Ephemeral});
  return await i.editReply(catalogPayload(s, 0, true));
 }
 if (i.isButton() && i.customId.startsWith('catalog:page:')) {
  await i.deferUpdate();
  const page = Number(i.customId.split(':')[2]);
  return await i.editReply({...catalogPayload(s, page, true), attachments: []});
 }
 if (i.isStringSelectMenu() && i.customId.startsWith('buy:')) {
  const product = s.products().find(product => product.id === Number(i.values[0]));
  if (!product) throw Error('สินค้านี้ปิดขายแล้ว');
  const available = product.remaining > 0;
  const purchase = button(`buyconfirm:${product.id}:${product.price}`, available ? 'ซื้อสินค้า' : 'สินค้าหมด', BS.Primary)
   .setDisabled(!available);
  return await i.reply({
   content: [
    `**${product.name}**`, `ราคา ${money(product.price)}`, `เหลือ ${product.remaining} ชิ้น`,
    '', product.description || 'ร้านยังไม่ได้ใส่คำอธิบาย'
   ].join('\n'),
   components: [new Row().addComponents(purchase)],
   flags: MessageFlags.Ephemeral
  });
 }
 if (i.isButton() && i.customId.startsWith('buyconfirm:')) {
  const [, productId, shownPrice] = i.customId.split(':');
  const product = s.products().find(product => product.id === Number(productId));
  if (!product?.remaining) throw Error('สินค้าหมดหรือปิดขายแล้ว');
  if (String(product.price) !== shownPrice) throw Error('ราคาสินค้าเปลี่ยนแล้ว กรุณาเลือกสินค้าใหม่');
  return await i.showModal(modal(`buyform:${product.id}:${product.price}`,
   'สั่งซื้อ ' + product.name.slice(0,30),'ชื่อเจ้าของบัญชีที่ใช้โอน'));
 }
 if (i.isButton() && i.customId.startsWith('stock-import:')) {
  requireAdmin(i);
  const [, action, token] = i.customId.split(':');
  const pending = stockImports.get(i.user.id);
  if (!pending || pending.token !== token || pending.expires <= Date.now()) {
   throw Error('รายการนำเข้าหมดอายุแล้ว ใช้ /stock-import ใหม่');
  }
  if (action === 'cancel') {
   stockImports.delete(i.user.id);
   return await i.update({content:'ยกเลิกการเติมสต็อก', components:[]});
  }
  const result = s.importStock(pending.productId, pending.lines);
  stockImports.delete(i.user.id);
  await i.update({content:`เพิ่มสต็อก ${result.added} ชิ้น · ข้ามรายการซ้ำ ${result.skipped} บรรทัด`, components:[]});
  await refreshPanels();
  return;
 }
 if(i.isModalSubmit()){
 const [action,arg,shownPrice]=i.customId.split(':'),value=i.fields.getTextInputValue('value').trim();if(!value)throw Error('กรุณากรอกข้อมูล');await i.deferReply({flags:MessageFlags.Ephemeral});
 if(action==='buyform'){if(value.length>100)throw Error('ชื่อยาวเกิน 100 ตัวอักษร');const o=s.reserve(i.user.id,Number(arg),value,c.minutes,Number(shownPrice));let ch;try{ch=await ensureOrderRoom(o,i.guild)}catch(e){s.release(o.id,'cancelled','สร้างห้องไม่สำเร็จ');throw e}await i.editReply(`สร้างคำสั่งซื้อแล้ว: ${ch}`);await refreshPanels();return}
 requireAdmin(i);
 if(action==='stock'){s.addStock(Number(arg),value);await i.editReply('เติมสต็อก 1 ชิ้นแล้ว');await refreshPanels();return}
 if(action==='reject'){s.release(Number(arg),'rejected',value.slice(0,500),i.user.id);await refreshOrder(Number(arg));await refreshQueue();await refreshPanels();return await i.editReply('ปฏิเสธรายการแล้ว')}
 if(action==='info'){s.requestInfo(Number(arg),value.slice(0,500));await refreshOrder(Number(arg));return await i.editReply('แจ้งขอหลักฐานเพิ่มแล้ว ให้ลูกค้าใช้ /pay ส่งใหม่')}
 if (action === 'approve') {
  const id = Number(arg);
  s.approve(id,i.user.id,value);
  await i.editReply('ยืนยันเงินแล้ว กำลังส่งสินค้า');
  try { await deliver(id); }
  catch (error) {
   safeError(error);
   await i.editReply('ยืนยันเงินแล้ว แต่ยังยืนยันผลการส่งไม่ได้ ตรวจห้องก่อนใช้ /resend ห้ามคืนสต็อกชิ้นนี้');
  }
  await refreshQueue();
  await refreshPanels();
  return;
 }
 }
 if(i.isButton()){
 const [action,arg,method]=i.customId.split(':'),id=Number(arg),o=s.order(id);if(!o)throw Error('ไม่พบคำสั่งซื้อ');
 if (['approve','reject','info'].includes(action)) {
  requireAdmin(i);
  if (!reviewStatuses.includes(o.status)) throw Error('รายการนี้ไม่อยู่ระหว่างตรวจ');
  if (action === 'approve') {
   return await i.showModal(modal(`approve:${id}`,'ยืนยันยอดเข้าจริง','เลขอ้างอิงจากรายการเงินจริง'));
  }
  return await i.showModal(modal(`${action}:${id}`,action==='reject'?'เหตุผลที่ปฏิเสธ':'ขอหลักฐานเพิ่ม','รายละเอียดสำหรับลูกค้า'));
 }
 else if(o.user_id!==i.user.id)throw Error('รายการนี้เป็นของลูกค้าคนอื่น');
 await i.deferReply({flags:MessageFlags.Ephemeral});
 if(action==='method'){s.tx(()=>{s.expire();if(s.order(id).status!=='pending')throw Error('หมดเวลาหรือส่งหลักฐานแล้ว');if(!['promptpay','truemoney'].includes(method))throw Error('วิธีจ่ายไม่ถูกต้อง');s.run('UPDATE orders SET method=? WHERE id=?',method,id)});if(method==='promptpay'){const png=await qr.toBuffer(generatePayload(c.pp,{amount:o.price/100}),{width:600,margin:3});await i.editReply({content:`ยอด ${money(o.price)}\nผู้รับ: ${c.payee}\nพร้อมเพย์: ${c.pp}\nตรวจชื่อผู้รับก่อนโอน แล้วใช้ /pay แนบหลักฐานในห้องนี้`,files:[new AttachmentBuilder(png,{name:`qr-${id}.png`})]})}else await i.editReply(`โอน TrueMoney เข้าเบอร์ ${c.wallet}\nชื่อผู้รับ: ${c.payee}\nยอด ${money(o.price)}\nแล้วใช้ /pay แนบหลักฐานในห้องนี้`);await refreshOrder(id);return}
 if(action==='paid')return await i.editReply('ใช้คำสั่ง /pay ในห้องคำสั่งซื้อ แล้วแนบรูปหลักฐาน บอทจึงจะออกคิวให้');
 if(action==='cancel'){if(o.status!=='pending')throw Error('ส่งหลักฐานแล้ว ให้แอดมินจัดการ');s.release(id,'cancelled');await refreshOrder(id);await refreshPanels();return await i.editReply('ยกเลิกแล้ว หากโอนเงินแล้วให้ติดต่อแอดมิน')}
 }
 if(i.isChatInputCommand()){
 const n=i.commandName,opt=i.options;if(n!=='pay')requireAdmin(i);
 if(n==='stock-add')return await i.showModal(modal(`stock:${opt.getInteger('product')}`,'เติมสต็อกหนึ่งชิ้น','ข้อความสินค้าที่จะส่งให้ผู้ซื้อ'));
 await i.deferReply({flags:MessageFlags.Ephemeral});
 if (n === 'product-add') {
  const image = await downloadProductImage(opt.getAttachment('image'));
  const id = s.tx(() => {
   if (s.get('SELECT count(*) n FROM products').n >= 100) throw Error('รุ่นนี้รองรับ 100 สินค้า');
   const id = s.addProduct(opt.getString('name'), opt.getString('description') || '', opt.getInteger('satang'));
   if (image) s.setProductImage(id, image);
   return id;
  });
  await i.editReply(`เพิ่มสินค้า #${id} แล้ว`);
 }
 if (n === 'product-edit') {
  const image = await downloadProductImage(opt.getAttachment('image'));
  const id = opt.getInteger('id');
  s.tx(() => {
   const product = s.get('SELECT * FROM products WHERE id=?', id);
   if (!product) throw Error('ไม่พบสินค้า');
   const active = opt.getBoolean('active');
   s.run('UPDATE products SET name=?,price=?,description=?,active=? WHERE id=?',
    opt.getString('name') ?? product.name,
    opt.getInteger('satang') ?? product.price,
    opt.getString('description')?.trim() ?? product.description,
    active === null ? product.active : Number(active), id);
   if (image) s.setProductImage(id, image);
  });
  await i.editReply('แก้ไขแล้ว');
 }
 if (n === 'stock-import') {
  const productId = opt.getInteger('product');
  const lines = await downloadStockFile(opt.getAttachment('file',true));
  requireAdmin(i);
  const plan = s.stockImportPlan(productId, lines);
  if (!plan.fresh.length) return await i.editReply(`ไม่มีสต็อกใหม่ · ข้ามรายการซ้ำ ${plan.skipped} บรรทัด`);
  const token = randomUUID();
  stockImports.set(i.user.id, {productId, lines, token, expires:Date.now()+300000});
  return await i.editReply({
   content:`สินค้า #${productId} · จะเพิ่ม ${plan.fresh.length} ชิ้น · ข้ามรายการซ้ำ ${plan.skipped} บรรทัด\nกดยืนยันภายใน 5 นาที`,
   components:[new Row().addComponents(
    button(`stock-import:confirm:${token}`,'ยืนยันเติมสต็อก',BS.Success),
    button(`stock-import:cancel:${token}`,'ยกเลิก')
   )]
  });
 }
 if(n==='stock-list'){const rows=s.all("SELECT p.id,p.name,s.status,count(s.id) n FROM products p LEFT JOIN stock s ON s.product_id=p.id GROUP BY p.id,s.status");await i.editReply({content:rows.length?'ดูไฟล์สรุป':'ยังไม่มีสินค้า',files:rows.length?[new AttachmentBuilder(Buffer.from(rows.map(r=>`#${r.id} ${r.name} | ${r.status||'ไม่มีสต็อก'}: ${r.n}`).join('\n')),{name:'stock.txt'})]:[]})}
 if(n==='shop'){const m=await i.channel.send(catalogPayload(s));s.run('INSERT INTO panels VALUES(?,?)',i.channelId,m.id);await i.editReply('เผยแพร่หน้าร้านแล้ว')}
 if(n==='queue'){const rows=s.reviewOrders();await i.editReply(rows.length?rows.slice(0,50).map((o,j)=>`${j+1}. #${o.id}`).join('\n'):'ไม่มีคิวรอตรวจ')}
 if(n==='order'){const o=s.order(opt.getInteger('id'));if(!o)throw Error('ไม่พบคำสั่งซื้อ');await i.editReply(orderText(o)+(o.channel_id?`\nห้อง: <#${o.channel_id}>`:''))}
 if (n === 'pay') {
  const order = s.get('SELECT * FROM orders WHERE channel_id=? AND user_id=?',i.channelId,i.user.id);
  if (!order) throw Error('ใช้ /pay ในห้องคำสั่งซื้อของคุณ');
  if (!order.method) throw Error('เลือกวิธีชำระก่อน หากโอนไปแล้วให้แจ้งแอดมิน');
  if (!s.canSubmitProof(order,i.user.id)) throw Error('ออเดอร์นี้ส่งหลักฐานเพิ่มไม่ได้ กรุณาติดต่อแอดมิน');
  const proof = opt.getAttachment('proof',true);
  if (!['image/png','image/jpeg','image/webp'].includes(proof.contentType) || proof.size>8*1024*1024) {
   throw Error('ใช้ PNG JPG WEBP ขนาดไม่เกิน 8MB');
  }
  const extension = proof.contentType === 'image/png' ? 'png' : proof.contentType === 'image/webp' ? 'webp' : 'jpg';
  const message = await i.channel.send({
   content:`หลักฐานคำสั่งซื้อ #${order.id} จากลูกค้า (ยังไม่ยืนยันเงิน)`,
   files:[new AttachmentBuilder(proof.url,{name:`proof-${order.id}.${extension}`})]
  });
  const status = s.submit(order.id,i.user.id,message.attachments.first().url);
  await i.editReply(status === 'late_review'
   ? 'รับสลิปย้อนหลังแล้ว แอดมินจะตรวจยอดและเช็กสต็อก กรุณาอย่าโอนซ้ำ'
   : 'รับหลักฐานแล้ว กำลังรอตรวจเงิน ดูคิวในข้อความคำสั่งซื้อ');
  await refreshQueue();
  if (status === 'late_review') await refreshPanels();
 }
 if(n==='delivery-confirm'){const id=opt.getInteger('order'),o=s.order(id);if(!o||o.status!=='sending')throw Error('ใช้เฉพาะรายการสถานะ sending');const m=await (await channel(o.channel_id)).messages.fetch(opt.getString('message'));if(m.author.id!==client.user.id||!m.attachments.some(a=>a.name===`order-${id}.txt`))throw Error('ข้อความนี้ไม่ใช่สินค้าของคำสั่งซื้อจากบอท');s.run("UPDATE orders SET status='delivered',delivery_id=?,admin_id=? WHERE id=? AND status='sending'",m.id,i.user.id,id);await refreshOrder(id);await i.editReply('บันทึกว่าส่งสินค้าแล้ว โดยไม่ได้ส่งข้อความซ้ำ')}
 if(n==='resend'){if(!opt.getBoolean('accept-duplicate-risk'))throw Error('ตรวจห้องและยอมรับความเสี่ยงส่งซ้ำก่อน');await deliver(opt.getInteger('order'),true);await i.editReply('ส่งสินค้าแล้ว')}
 if (n === 'product-add' || n === 'product-edit') await refreshPanels();
 return;
 }
 }catch(e){safeError(e);const msg=e.code?'ทำรายการไม่สำเร็จ กรุณาตรวจสิทธิ์บอทหรือแจ้งแอดมิน':e.message;try{if(i.deferred||i.replied)await i.editReply({content:msg,components:[]});else await i.reply({content:msg,flags:MessageFlags.Ephemeral})}catch{}}});
async function sendPaymentNotices() {
 for (const notice of s.pendingNotices()) {
  try {
   const room = await channel(notice.channel_id);
   const order = s.order(notice.id);
   if (order?.status !== (notice.kind === 'expired' ? 'expired' : 'pending')) continue;
   if (notice.kind === 'expired') await refreshOrder(notice.id);
   await room.send({
    content: notice.kind === 'expired'
     ? `<@${notice.user_id}> เวลาจองหมดแล้ว ถ้าโอนแล้ว ใช้ /pay แนบสลิปย้อนหลังในห้องนี้ได้เลย กรุณาอย่าโอนซ้ำ`
     : `<@${notice.user_id}> เวลาจองใกล้หมด ถ้าโอนแล้วอย่าลืมใช้ /pay แนบสลิปในห้องนี้`,
    allowedMentions:{users:[notice.user_id]},
    nonce:`${notice.kind === 'expired' ? 'e' : 'r'}${notice.id}`, enforceNonce:true
   });
   s.run('INSERT OR IGNORE INTO payment_notices(order_id,kind) VALUES(?,?)',notice.id,notice.kind);
  } catch (error) {
   safeError(error);
  }
 }
}

let ticking=false;
async function tick() {
 if (ticking) return;
 ticking=true;
 try {
  for (const [userId, pending] of stockImports) {
   if (pending.expires <= Date.now()) stockImports.delete(userId);
  }
  const expired=s.tx(()=>s.expire());
  for (const order of expired) await refreshOrder(order.id);
  await sendPaymentNotices();
  for(const order of s.all("SELECT id FROM orders WHERE status='approved'")) {
   try { await deliver(order.id); } catch (error) { safeError(error); }
  }
  await refreshQueue();
  if(expired.length) await refreshPanels();
 } catch (error) {
  safeError(error);
 } finally {
  ticking=false;
 }
}
client.once('clientReady',async()=>{
 console.log('Shop bot online');
 const guilds = [...client.guilds.cache.values()].filter(guild=>!c.guild || guild.id===c.guild);
 await Promise.all(guilds.map(registerGuild));
 if (shopReady(c)) {
  await refreshPanels();
  await tick();
 }
 setInterval(()=>{if(shopReady(c))void tick()},30000).unref();
});
client.on('guildCreate',guild=>{if(!c.guild||guild.id===c.guild)void registerGuild(guild)});
client.on('error',safeError);process.on('SIGTERM',()=>{client.destroy();s.close();process.exit(0)});await client.login(c.token);
