import {AttachmentBuilder,ChannelType,EmbedBuilder,OverwriteType,PermissionFlagsBits as P,escapeMarkdown} from 'discord.js';

export function productDelivery(id, content) {
 const heading = `**สินค้า · ออเดอร์ #${id}**`;
 const match = /^(https:\/\/[^\s<>\\]+)([\s][\s\S]*)?$/i.exec(content.trim());
 if (match && URL.canParse(match[1])) {
  const [,url,notes=''] = match;
  const message = `${heading}\n<${url}>${notes.trim() ? `\n${notes.trim()}` : ''}`;
  if (message.length<=2000) return {content:message};
 }
 if (content.length<=500 && !content.includes('```')) {
  const inline = content===content.trim() && !/[`\r\n]/.test(content);
  const code = inline ? '`'+content+'`' : '```\n'+content+'\n```';
  return {content:heading+'\n'+code};
 }
 return {
  content:`${heading}\nดาวน์โหลดไฟล์ด้านล่างและเก็บไว้เป็นส่วนตัว`,
  files:[new AttachmentBuilder(Buffer.from(content,'utf8'),{name:`order-${id}.txt`})]
 };
}

const paymentNames = {promptpay:'QR พร้อมเพย์',truemoney:'TrueMoney'};
const baht = new Intl.NumberFormat('th-TH',{minimumFractionDigits:2,maximumFractionDigits:2});
const billDate = new Intl.DateTimeFormat('th-TH-u-ca-gregory',{
 timeZone:'Asia/Bangkok',dateStyle:'medium',timeStyle:'short'
});

export function receiptDelivery(order, content, appearance = {}) {
 const product = productDelivery(order.id,content);
 const amount = `${baht.format(order.price/100)} บาท`;
 const unit = `${baht.format((order.price+(order.coupon_discount ?? 0))/100)} บาท`;
 const embed = new EmbedBuilder().setColor(appearance.color ?? 0xc32d36)
  .setAuthor({name:appearance.title || 'ZBINGZING RACING'})
  .setTitle(`${order.test ? '🧪 บิลทดสอบ' : '🧾 บิลสั่งซื้อ'} #${order.id}`)
  .addFields(
   {name:'รายการสินค้า',value:escapeMarkdown(order.product_name ?? order.name)},
   {name:'จำนวน',value:'1 ชิ้น',inline:true},
   {name:'ราคาต่อชิ้น',value:unit,inline:true},
   {name:'ยอดชำระแล้ว',value:`**${amount}**`,inline:true},
   {name:'วิธีชำระ',value:paymentNames[order.method] ?? 'ไม่ระบุ',inline:true}
  );
 if (order.coupon_code) embed.addFields({name:`คูปอง ${order.coupon_code}`,value:`−${baht.format(order.coupon_discount/100)} บาท`});
 if (order.paid_at!=null) {
  embed.addFields({name:'ยืนยันยอด (เวลาไทย)',value:billDate.format(order.paid_at),inline:true});
 }
 embed.setFooter({text:appearance.footer || 'ขอบคุณที่อุดหนุน ZBINGZING Racing'});
 return {...product,embeds:[embed]};
}

export function isProductDelivery(message,id,stock,botId) {
 if (message.author.id!==botId) return false;
 if (message.attachments.some(file=>file.name===`order-${id}.txt`)) return true;
 const delivery = productDelivery(id,stock);
 return !delivery.files && message.content===delivery.content;
}

// A network timeout can mean the message was accepted. Keep 'sending' on any
// uncertain result. Only an admin who checked the delivery can explicitly resend.
export async function deliverOrder(store,id,send,force=false){
 const o=store.order(id);
 if(!o||!['approved',...(force?['sending']:[])].includes(o.status))throw Error('รายการนี้ส่งไม่ได้หรือส่งแล้ว');
 if (!store.run("UPDATE orders SET status='sending' WHERE id=? AND status=?",id,o.status).changes) {
  throw Error('สถานะการส่งสินค้าเปลี่ยนแล้ว');
 }
 const content=store.get('SELECT content FROM stock WHERE id=?',o.stock_id).content;
 const result=await send(o,content);
 if (result && typeof result==='object') store.completeDelivery(id,result.dm,null,result.room);
 else store.completeDelivery(id,result);
}

// A blocked DM is definite. A timeout is uncertain and must not finish the order.
export async function sendPrivateProduct(sendDM) {
 try {
  return (await sendDM()).id;
 } catch (error) {
  if ([50007,50278].includes(error.code)) return null;
  throw error;
 }
}

export function isPrivateDeliveryRoom(room,order,guildId,adminRoleId,botId) {
 if (room?.id!==order.channel_id || room?.guildId!==guildId ||
     room.type!==ChannelType.GuildText || room.name!==`order-${order.id}`) return false;
 const overwrites = room.permissionOverwrites.cache;
 const everyone = overwrites.get(guildId);
 const buyer = overwrites.get(order.user_id);
 if (everyone?.type!==OverwriteType.Role || !everyone.deny.has(P.ViewChannel) ||
     buyer?.type!==OverwriteType.Member || !buyer.allow.has(P.ViewChannel)) return false;
 return overwrites.every(entry=>!entry.allow.has(P.ViewChannel) || (
  entry.type===OverwriteType.Member ? [order.user_id,botId].includes(entry.id) : entry.id===adminRoleId
 ));
}

export async function sendOrderCopies(sendDM,sendRoom,onError) {
 const [dm,room] = await Promise.allSettled([
  Promise.resolve().then(sendDM),Promise.resolve().then(sendRoom)
 ]);
 for (const result of [dm,room]) if (result.status==='rejected') onError(result.reason);
 const ids = {dm:dm.value ?? null,room:room.value ?? null};
 if (!ids.dm && !ids.room) {
  const failed = [dm,room].find(result=>result.status==='rejected');
  if (failed) throw failed.reason;
 }
 return ids;
}
