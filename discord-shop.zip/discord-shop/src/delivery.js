// A network timeout can mean the message was accepted. Keep 'sending' on any
// uncertain result. Only an admin who inspected the room may explicitly resend.
export async function deliverOrder(store,id,send,force=false){
 const o=store.order(id);
 if(!o||!['approved',...(force?['sending']:[])].includes(o.status))throw Error('รายการนี้ส่งไม่ได้หรือส่งแล้ว');
 store.run("UPDATE orders SET status='sending' WHERE id=?",id);
 const content=store.get('SELECT content FROM stock WHERE id=?',o.stock_id).content;
 const messageId=await send(o,content);
 store.run("UPDATE orders SET status='delivered',delivery_id=? WHERE id=?",messageId,id);
}
