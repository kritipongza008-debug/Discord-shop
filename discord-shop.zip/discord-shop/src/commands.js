import { SlashCommandBuilder } from 'discord.js';
const imageOption = o => o.setName('image').setDescription('แนบรูปสินค้าได้ถึง 20 MB บอทย่อรูปให้เอง');
const admin=(name,description)=>new SlashCommandBuilder().setName(name).setDescription(description);
export const settingsCommand = new SlashCommandBuilder().setName('settings').setDescription('เปิดหน้าตั้งค่าร้านค้า').toJSON();
export const commands=[
 admin('product-add','เพิ่มสินค้า').addStringOption(o=>o.setName('name').setDescription('ชื่อ').setMaxLength(80).setRequired(true)).addIntegerOption(o=>o.setName('satang').setDescription('ราคาเป็นสตางค์ เช่น 9900 = 99 บาท').setMinValue(1).setMaxValue(100000000).setRequired(true)).addStringOption(o=>o.setName('description').setDescription('รายละเอียด').setMaxLength(500)).addAttachmentOption(imageOption),
 admin('product-edit','แก้ชื่อ ราคา คำอธิบาย หรือเปิดปิดสินค้า')
  .addIntegerOption(o=>o.setName('id').setDescription('รหัสสินค้า').setRequired(true))
  .addStringOption(o=>o.setName('name').setDescription('ชื่อใหม่').setMaxLength(80))
  .addIntegerOption(o=>o.setName('satang').setDescription('ราคาใหม่เป็นสตางค์').setMinValue(1).setMaxValue(100000000))
  .addStringOption(o=>o.setName('description').setDescription('คำอธิบายใหม่ที่ลูกค้าเห็นก่อนซื้อ').setMaxLength(500))
  .addAttachmentOption(imageOption)
  .addBooleanOption(o=>o.setName('active').setDescription('เปิดขายหรือไม่')),
 admin('stock-add','เติมข้อความ 1 ฟอร์มต่อ 1 ชิ้น').addIntegerOption(o=>o.setName('product').setDescription('รหัสสินค้า').setRequired(true)),
 admin('stock-import','เติมสต็อกหลายชิ้นจากไฟล์ข้อความ')
  .addIntegerOption(o=>o.setName('product').setDescription('รหัสสินค้า').setRequired(true))
  .addAttachmentOption(o=>o.setName('file').setDescription('ไฟล์ .txt UTF-8 หนึ่งบรรทัดต่อหนึ่งชิ้น').setRequired(true)),
 admin('stock-list','ดูจำนวนสต็อก'),admin('shop','เผยแพร่หน้าร้านในห้องนี้'),admin('queue','ดูคิวรอตรวจ'),
 admin('order','ดูสถานะคำสั่งซื้อ').addIntegerOption(o=>o.setName('id').setDescription('เลขคำสั่งซื้อ').setRequired(true)),
 new SlashCommandBuilder().setName('pay').setDescription('ส่งหลักฐานชำระเงินในห้องคำสั่งซื้อ').addAttachmentOption(o=>o.setName('proof').setDescription('รูปหลักฐาน PNG JPG WEBP ไม่เกิน 8MB').setRequired(true)),
 admin('delivery-confirm','ปิดรายการส่งค้างจากข้อความสินค้าที่ตรวจแล้ว').addIntegerOption(o=>o.setName('order').setDescription('เลขคำสั่งซื้อ').setRequired(true)).addStringOption(o=>o.setName('message').setDescription('Message ID ของข้อความสินค้าจากบอทในห้องคำสั่งซื้อ').setRequired(true)),
 admin('resend','ส่งสินค้าอีกครั้ง กรณีส่งติดขัด อาจซ้ำได้').addIntegerOption(o=>o.setName('order').setDescription('เลขคำสั่งซื้อ').setRequired(true)).addBooleanOption(o=>o.setName('accept-duplicate-risk').setDescription('ตรวจห้องแล้ว และยอมรับว่าอาจส่งข้อความซ้ำ').setRequired(true))
].map(c=>c.toJSON());
commands.unshift(settingsCommand);
