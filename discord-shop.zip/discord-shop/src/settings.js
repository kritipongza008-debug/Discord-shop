import {
 ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder,
 ChannelType, EmbedBuilder, MessageFlags, ModalBuilder, PermissionFlagsBits,
 RoleSelectMenuBuilder, TextInputBuilder, TextInputStyle
} from 'discord.js';

const P = PermissionFlagsBits;
const prefix = 'shop-settings:';
const row = (...components) => new ActionRowBuilder().addComponents(...components);
const privateReply = (payload) => ({...payload, flags: MessageFlags.Ephemeral});

export function hasShopRole(interaction, role) {
 const roles = interaction.member?.roles;
 return Boolean(role && (roles?.cache?.has(role) || (Array.isArray(roles) && roles.includes(role))));
}

export function canConfigure(interaction, settings, writing = false) {
 if (!interaction.guildId) return false;
 if (settings?.guild && settings.guild !== interaction.guildId) return false;
 if (settings?.role) return hasShopRole(interaction, settings.role);
 return !writing || Boolean(interaction.memberPermissions?.has(P.ManageGuild));
}

export function shopReady(settings) {
 return Boolean(settings.guild && settings.role && settings.admin && settings.category &&
  settings.pp && settings.payee && settings.wallet);
}

function channelPicker(id, placeholder, type, selected) {
 const picker = new ChannelSelectMenuBuilder()
  .setCustomId(prefix + id).setPlaceholder(placeholder).addChannelTypes(type);
 if (selected) picker.setDefaultChannels(selected);
 return row(picker);
}

export function settingsPanel(settings) {
 const rolePicker = new RoleSelectMenuBuilder()
  .setCustomId(prefix + 'role').setPlaceholder('เลือกยศแอดมินร้าน');
 if (settings?.role) rolePicker.setDefaultRoles(settings.role);
 const components = [row(rolePicker)];
 if (!settings?.role) {
  return {
   embeds:[new EmbedBuilder().setTitle('ตั้งค่าร้านครั้งแรก').setColor(0xc32d36)
    .setDescription('**เริ่มจากเลือกยศแอดมินร้าน**\nผู้มีสิทธิ์จัดการเซิร์ฟเวอร์จะบันทึกยศครั้งแรกได้')],
   components
  };
 }
 components.push(
  channelPicker('admin', 'เลือกห้องตรวจเงินส่วนตัว', ChannelType.GuildText, settings.admin),
  channelPicker('category', 'เลือกหมวดสำหรับห้องออเดอร์', ChannelType.GuildCategory, settings.category),
  row(new ButtonBuilder().setCustomId(prefix + 'payment').setLabel('ตั้งค่ารับเงิน').setStyle(ButtonStyle.Primary))
 );
 const payment = Boolean(settings.pp && settings.wallet && settings.payee);
 const ready = shopReady(settings);
 if (ready) components.push(row(
  new ButtonBuilder().setCustomId('shop-admin:home').setLabel('เปิดแผงจัดการร้าน').setStyle(ButtonStyle.Success),
  new ButtonBuilder().setCustomId('shop-admin:banner-menu').setLabel('แบนเนอร์และตัวอย่าง').setStyle(ButtonStyle.Secondary)
 ));
 const completed = [settings.role, settings.admin, settings.category, payment].filter(Boolean).length;
 return {
  embeds:[new EmbedBuilder()
   .setAuthor({name:'ZBINGZING RACING / จัดการร้าน'})
   .setTitle(ready ? 'พร้อมเปิดร้าน' : `ตั้งค่าร้าน · ${completed}/4`)
   .setColor(ready ? 0x27835f : 0xc32d36)
   .setDescription(ready ? 'กด **เปิดแผงจัดการร้าน** เพื่อเพิ่มสินค้า เติมสต็อก และเลือกห้องลงหน้าร้าน' : 'เลือกช่องที่ยังไม่ครบจากเมนูด้านล่าง')
   .addFields(
    {name:'1. ยศแอดมิน',value:`<@&${settings.role}>`},
    {name:'2. ห้องตรวจเงิน',value:settings.admin ? `<#${settings.admin}>` : 'ยังไม่ได้เลือก'},
    {name:'3. หมวดออเดอร์',value:settings.category ? `<#${settings.category}>` : 'ยังไม่ได้เลือก'},
    {name:'4. ข้อมูลรับเงิน',value:payment ? 'ตั้งค่าแล้ว' : 'กดตั้งค่ารับเงิน'}
   )
   .setFooter({text:'บันทึกทันทีเมื่อเลือกแต่ละรายการ'})],
  components
 };
}

function paymentModal(settings) {
 const modal = new ModalBuilder().setCustomId(prefix + 'payment-save').setTitle('ข้อมูลรับเงิน');
 for (const [key, label, limit] of [
  ['pp', 'พร้อมเพย์ (เบอร์โทร 10 หรือเลขบัตร 13 หลัก)', 13],
  ['wallet', 'เบอร์ TrueMoney Wallet', 10],
  ['payee', 'ชื่อผู้รับเงินที่จะแสดงให้ลูกค้า', 100]
 ]) {
  const field = new TextInputBuilder()
   .setCustomId(key).setLabel(label).setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(limit);
  if (settings[key]) field.setValue(settings[key].slice(0, limit));
  modal.addComponents(row(field));
 }
 return modal;
}

function paymentFields(interaction) {
 const fields = interaction.fields;
 const pp = fields.getTextInputValue('pp').trim();
 const wallet = fields.getTextInputValue('wallet').trim();
 const payee = fields.getTextInputValue('payee').trim();
 if (!/^(0\d{9}|\d{13})$/.test(pp)) throw Error('กรอกพร้อมเพย์เป็นเบอร์ 10 หลักหรือเลขบัตร 13 หลัก');
 if (!/^0\d{9}$/.test(wallet)) throw Error('กรอกเบอร์ TrueMoney 10 หลัก');
 if (!payee || payee.length > 100) throw Error('กรอกชื่อผู้รับเงิน 1–100 ตัวอักษร');
 return {pp, wallet, payee};
}

function validateReviewChannel(guild, channel, role) {
 if (channel?.type !== ChannelType.GuildText) throw Error('เลือกห้องข้อความสำหรับตรวจเงิน');
 if (channel.permissionsFor(guild.roles.everyone)?.has(P.ViewChannel)) {
  throw Error('ตั้งห้องตรวจเงินให้เป็นส่วนตัวก่อน สมาชิกทั่วไปต้องมองไม่เห็น');
 }
 const botPermissions = channel.permissionsFor(guild.members.me);
 if (!botPermissions?.has([P.ViewChannel, P.SendMessages, P.ReadMessageHistory])) {
  throw Error('ให้บอทดูห้อง ส่งข้อความ และอ่านประวัติในห้องตรวจเงินก่อน');
 }
 if (!channel.permissionsFor(role)?.has(P.ViewChannel)) {
  throw Error('ให้ยศแอดมินร้านเข้าถึงห้องตรวจเงินก่อน');
 }
}

export async function handleSettings(interaction, store, updateConfig, registerGuild) {
 const openCommand = interaction.isChatInputCommand() && interaction.commandName === 'settings';
 if (!openCommand && !interaction.customId?.startsWith(prefix)) return false;
 const settings = store.settings();
 if (!canConfigure(interaction, settings)) throw Error('หน้านี้เปิดได้เฉพาะยศแอดมินร้าน');
 if (openCommand) {
  await interaction.reply(privateReply(settingsPanel(settings)));
  return true;
 }
 const action = interaction.customId.slice(prefix.length);
 if (action === 'open' && interaction.isButton()) {
  await interaction.update({content:null,...settingsPanel(settings)});
  return true;
 }
 if (!canConfigure(interaction, settings, true)) {
  throw Error('ให้คนที่มีสิทธิ์จัดการเซิร์ฟเวอร์เลือกยศครั้งแรก');
 }
 if (action === 'payment' && interaction.isButton() && settings?.role) {
  await interaction.showModal(paymentModal(settings));
  return true;
 }

 const next = {...settings, guild: interaction.guildId};
 if (action === 'role' && interaction.isRoleSelectMenu()) {
  const role = interaction.roles.get(interaction.values[0]);
  if (!role || role.id === interaction.guildId || role.managed) {
   throw Error('เลือกยศปกติสำหรับแอดมินร้าน');
  }
  if (settings?.admin && role.id !== settings.role) {
   const review = interaction.guild.channels.cache.get(settings.admin);
   if (review) validateReviewChannel(interaction.guild, review, role.id);
  }
  next.role = role.id;
 } else if (action === 'admin' && interaction.isChannelSelectMenu() && settings?.role) {
  const channel = interaction.guild.channels.cache.get(interaction.values[0]);
  validateReviewChannel(interaction.guild, channel, settings.role);
  next.admin = channel.id;
 } else if (action === 'category' && interaction.isChannelSelectMenu() && settings?.role) {
  const channel = interaction.guild.channels.cache.get(interaction.values[0]);
  if (channel?.type !== ChannelType.GuildCategory) throw Error('เลือกหมวดหมู่สำหรับออเดอร์');
  if (!channel.permissionsFor(interaction.guild.members.me)?.has([P.ViewChannel, P.ManageChannels])) {
   throw Error('ให้บอทดูและจัดการห้องในหมวดออเดอร์ก่อน');
  }
  next.category = channel.id;
 } else if (action === 'payment-save' && interaction.isModalSubmit() && settings?.role) {
  Object.assign(next, paymentFields(interaction));
 } else {
  throw Error('เปิด /settings ใหม่แล้วลองอีกครั้ง');
 }
 if (JSON.stringify(next) !== JSON.stringify(settings)) {
  if (store.hasOpenOrders()) throw Error('ปิดออเดอร์ที่ค้างก่อนเปลี่ยนการตั้งค่าร้าน');
  store.saveSettings(settings, next);
  updateConfig(next);
 }
 if (!settings?.guild) void registerGuild(interaction.guild);
 if (!canConfigure(interaction, next)) {
  await interaction.update({content: 'บันทึกยศแล้ว หน้าตั้งค่าเปิดได้เฉพาะสมาชิกที่มียศที่เลือก', embeds:[], components: []});
 } else if (action === 'payment-save') {
  await interaction.reply(privateReply(settingsPanel(next)));
 } else {
  await interaction.update(settingsPanel(next));
 }
 return true;
}
