export const shopEmojiDefaults = {
 readyEmoji:'🟢',
 lowEmoji:'🟠',
 soldOutEmoji:'⚪',
 featuredEmoji:'⭐',
 saleEmoji:'🏷️'
};

const customEmoji = /^<a?:[a-zA-Z0-9_]{2,32}:\d{17,20}>$/;
const unicodeEmoji = /^\p{RGI_Emoji}$/v;
const singlePictograph = /^\p{Extended_Pictographic}\uFE0F?$/u;

export function parseShopEmoji(value) {
 const emoji = value?.trim();
 if (!emoji) return null;
 if (customEmoji.test(emoji) || unicodeEmoji.test(emoji) || singlePictograph.test(emoji)) return emoji;
 throw Error('ใส่อีโมจิ 1 ตัว หรือโค้ด Discord เช่น <:emoji:123456789012345678>');
}

export function shopEmoji(appearance,key) {
 return appearance[key] ?? shopEmojiDefaults[key];
}

export function emojiInPlainLabel(emoji) {
 return customEmoji.test(emoji) ? '' : emoji+' ';
}
