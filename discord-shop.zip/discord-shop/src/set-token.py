"""Set the Discord bot token from a terminal without echoing it."""
import os
import re
import tempfile
import warnings
from getpass import GetPassWarning, getpass
from pathlib import Path


path = Path("/opt/discord-shop/.env")
if os.geteuid() != 0 or not path.is_file():
    raise SystemExit("Install the bot first, then run this command with sudo.")

warnings.simplefilter("error", GetPassWarning)
try:
    token = getpass("New Discord bot token: ").strip()
except GetPassWarning:
    raise SystemExit("This terminal cannot hide input. No token was saved.")
if not re.fullmatch(r"[A-Za-z0-9_.-]{20,}", token):
    raise SystemExit("Invalid token format. No settings were changed.")

lines = path.read_text(encoding="utf-8").splitlines()
lines = [line for line in lines if not re.match(r"^\s*(?:export\s+)?DISCORD_TOKEN\s*=", line)]
owner = path.stat()
with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as tmp:
    temp_path = Path(tmp.name)
    try:
        os.fchown(tmp.fileno(), owner.st_uid, owner.st_gid)
        tmp.write("\n".join([f"DISCORD_TOKEN={token}", *lines]) + "\n")
        tmp.flush()
        temp_path.replace(path)
    finally:
        temp_path.unlink(missing_ok=True)
print("Token saved.")
