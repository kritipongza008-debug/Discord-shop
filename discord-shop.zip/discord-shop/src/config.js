const discordId = (value) => /^\d{17,20}$/.test(value || '') ? value : '';

export function config() {
 const token = process.env.DISCORD_TOKEN?.trim();
 if (!token || token === 'REPLACE_WITH_NEW_TOKEN') {
  throw Error('กรุณาตั้งค่า DISCORD_TOKEN ใน .env');
 }
 const minutes = Number(process.env.RESERVATION_MINUTES || 15);
 if (!Number.isInteger(minutes) || minutes < 1 || minutes > 120) {
  throw Error('RESERVATION_MINUTES ต้องเป็น 1-120');
 }
 const guild = discordId(process.env.GUILD_ID);
 const role = discordId(process.env.ADMIN_ROLE_ID);
 const legacy = guild && role ? {
  guild, role,
  admin: discordId(process.env.ADMIN_CHANNEL_ID),
  category: discordId(process.env.ORDER_CATEGORY_ID),
  pp: process.env.PROMPTPAY_ID || '',
  payee: process.env.PAYEE_NAME || '',
  wallet: process.env.TRUEMONEY_PHONE || ''
 } : null;
 return {
  token, minutes, legacy,
  slipKey: process.env.EASYSLIP_API_KEY?.trim(),
  slipAutoSend: process.env.EASYSLIP_AUTO_SEND==='true',
  slipBankCode: process.env.EASYSLIP_BANK_CODE?.trim(),
  slipBankAccount: process.env.EASYSLIP_BANK_ACCOUNT?.trim(),
  client: discordId(process.env.CLIENT_ID),
  db: process.env.DB_PATH || './data/shop.sqlite',
  guild: '', role: '', admin: '', category: '', pp: '', payee: '', wallet: ''
 };
}
