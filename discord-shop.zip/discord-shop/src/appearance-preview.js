import {ActionRowBuilder,ButtonBuilder,ButtonStyle,ContainerBuilder,MessageFlags,TextDisplayBuilder} from 'discord.js';
import {catalogPayload,productPayload} from './catalog.js';
import {receiptDelivery} from './delivery.js';
import {shopEmojiDefaults} from './shop-emoji.js';

const sampleProducts = Array.from({length:5},(_,index)=>({
 id:index+1,name:`สินค้าตัวอย่าง ${index+1}`,price:9900,remaining:[6,2,0,0,0][index],
 sale_price:index===0 ? 7900 : null,
 description:'ตัวอย่างคำอธิบายสินค้า'
}));
const views = {shop:'หน้าร้าน',categories:'หมวดสินค้า',product:'หน้าซื้อ',bill:'บิล'};
const text = content => new TextDisplayBuilder().setContent(content);
const row = (...buttons) => new ActionRowBuilder().addComponents(...buttons);
const button = (id,label,style=ButtonStyle.Secondary) =>
 new ButtonBuilder().setCustomId('shop-admin:'+id).setLabel(label).setStyle(style);

function disableActions(component) {
 if (component.components) component.components.forEach(disableActions);
 if (component.custom_id) component.disabled = true;
 return component;
}

export function appearancePreview(store,draft,view,minutes) {
 const appearance = {...store.appearance(),...draft?.patch};
 const now = store.now();
 const featured = store.featuredProduct?.()?.active ||
  Object.keys(shopEmojiDefaults).some(key=>Object.hasOwn(draft?.patch ?? {},key));
 const sampleStore = {
  appearance:()=>appearance,now:()=>now,pauseNotice:()=>null,
  products:()=>featured ? [{...sampleProducts[0],featured:true},...sampleProducts.slice(1)] : sampleProducts,productImage:()=>null,
  shopBanner:()=>appearance.bannerMode==='custom' ? draft?.banner ?? store.shopBanner() : null
 };
 const selector = row(...Object.entries(views).map(([key,label])=>
  button(`preview-view:${key}:${draft?.token ?? ''}`,label,key===view ? ButtonStyle.Primary : ButtonStyle.Secondary)
   .setDisabled(key===view)));
 const controls = draft
  ? row(button('preview-apply:'+draft.token,'บันทึกการเปลี่ยนแปลง',ButtonStyle.Success),
   button('preview-discard:'+draft.token,'ทิ้งฉบับร่าง'))
  : row(button('extras','กลับตั้งค่าหน้าร้าน'));
 const heading = text(`**ตัวอย่าง${views[view]} · ${draft ? 'ยังไม่บันทึก' : 'ค่าที่ใช้อยู่'}**\n-# ใช้สินค้าจำลอง · เวลาชำระ ${appearance.minutes ?? minutes} นาที`);
 const intro = new ContainerBuilder().addTextDisplayComponents(heading).addActionRowComponents(selector,controls);
 if (view==='bill') {
  const order = {id:1,name:sampleProducts[0].name,price:9900,method:'promptpay',paid_at:now,test:true};
  const bill = receiptDelivery(order,'ตัวอย่าง',appearance).embeds[0].toJSON();
  const body = new ContainerBuilder().setAccentColor(bill.color)
   .addTextDisplayComponents(text(`-# ${bill.author.name}\n## ${bill.title}\n`+
    bill.fields.map(({name,value})=>`**${name}** · ${value}`).join('\n')+`\n-# ${bill.footer.text}`));
  return {flags:MessageFlags.IsComponentsV2,components:[intro,body],files:[]};
 }
 const payload = view==='product' ? productPayload(sampleStore,sampleProducts[0])
  : catalogPayload(sampleStore,view==='categories' ? 1 : 0,view==='categories');
 return {...payload,components:[intro,...payload.components.map(component=>disableActions(component.toJSON()))]};
}
