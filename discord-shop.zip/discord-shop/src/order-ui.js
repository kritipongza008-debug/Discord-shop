import {EmbedBuilder, FileUploadBuilder, LabelBuilder, ModalBuilder} from 'discord.js';

const states = {
 pending:['รอชำระเงิน',0xc32d36],
 review:['รอตรวจยอด',0xe3a32f],
 info:['ขอหลักฐานเพิ่ม',0xe3a32f],
 late_review:['รอตรวจสลิปย้อนหลัง',0xe3a32f],
 late_info:['ขอหลักฐานย้อนหลังเพิ่ม',0xe3a32f],
 approved:['รับเงินแล้ว · รอส่งสินค้า',0x27835f],
 sending:['กำลังส่งสินค้า',0x27835f],
 delivered:['ส่งสินค้าแล้ว',0x27835f],
 refund_pending:['รอคืนเงิน',0xe3a32f],
 refunded:['คืนเงินแล้ว',0x27835f],
 expired:['หมดเวลาจอง',0x737985],
 rejected:['รายการถูกปฏิเสธ',0xc32d36],
 cancelled:['ยกเลิกแล้ว',0x737985]
};

export const orderStatusLabel = (status) => states[status]?.[0] ?? status;

const methods = {promptpay:'พร้อมเพย์',truemoney:'TrueMoney'};

function nextStep(order) {
 switch (order.status) {
  case 'pending': return order.method ? '**ขั้นที่ 2 · ชำระเงิน**\nโอนตามยอด แล้วกด **แนบสลิป** ในห้องนี้' : '**ขั้นที่ 1 · เลือกวิธีจ่าย**\nกด **QR พร้อมเพย์** หรือ **TrueMoney** ด้านล่าง';
  case 'info':
  case 'late_info': return 'กด **แนบสลิป** เพื่อส่งหลักฐานเพิ่มเติม';
  case 'expired': return order.method ? 'ห้องนี้จะถูกปิด ถ้าโอนแล้วไปที่ **ออเดอร์ของฉัน** ที่หน้าร้านเพื่อส่งสลิปย้อนหลัง' : 'กลับหน้าร้านเพื่อสั่งซื้อใหม่';
  case 'late_review': return 'แอดมินจะตรวจยอดและเช็กสต็อก กรุณาอย่าโอนซ้ำ';
  case 'review': return '**ขั้นที่ 3 · รอตรวจยอด**\nดูคิวด้านล่าง แล้วรอรับสินค้าในห้องนี้';
  case 'refund_pending': return 'ร้านกำลังจัดการคืนเงิน ติดตามได้จาก **ออเดอร์ของฉัน**';
  case 'refunded': return 'ร้านบันทึกว่าคืนเงินแล้ว ถ้ายังไม่เห็นยอด กด **ติดต่อร้าน**';
  case 'delivered': return 'เปิดไฟล์สินค้าที่บอทส่งไว้ด้านล่าง';
  default: return '';
 }
}

export function orderCard(order, ahead, admin = false) {
 const [status,color] = states[order.status] ?? [order.status,0x737985];
 const embed = new EmbedBuilder()
  .setTitle(`ออเดอร์ #${order.id} · ${status}`)
  .setColor(color)
  .addFields(
   {name:'สินค้า',value:order.name,inline:true},
   {name:'ยอดชำระ',value:`**${(order.price/100).toFixed(2)} บาท**`,inline:true},
   {name:'วิธีชำระ',value:methods[order.method] || 'ยังไม่ได้เลือก',inline:true}
  );
 if (order.status === 'pending') {
  embed.addFields({name:'เวลาจอง',value:`หมดเวลา <t:${Math.floor(order.expires/1000)}:R>`});
 }
 if (ahead !== undefined) {
  embed.addFields({name:'คิวตรวจยอด',value:ahead ? `มีอีก ${ahead} คิวก่อนหน้า` : 'ถึงคิวตรวจแล้ว'});
 }
 if (order.payer) embed.addFields({name:'ชื่อผู้โอน',value:order.payer,inline:true});
 if (admin) {
  embed.setAuthor({name:'ZBINGZING RACING / ตรวจเงิน'});
  if (order.channel_id) embed.addFields({name:'ห้องออเดอร์',value:`<#${order.channel_id}>`});
  if (order.proof) embed.addFields({name:'หลักฐาน',value:`[เปิดรูปสลิป](${order.proof}) · ถ้าลิงก์หมดอายุให้เปิดจากห้องออเดอร์`});
  if (order.status === 'refund_pending') embed.setDescription('โอนคืนจริงก่อนกดบันทึกว่าคืนเงินแล้ว');
  if (ahead !== undefined) embed.setDescription('ตรวจยอดเข้าจริงก่อนกดยืนยันและกรอกเลขอ้างอิง');
 } else {
  const next = nextStep(order);
  if (next) embed.setDescription(next);
  if (order.description) embed.addFields({name:'รายละเอียดสินค้า',value:order.description.slice(0,300)});
  embed.setFooter({text:'ZBINGZING RACING • ห้องออเดอร์ส่วนตัว'});
 }
 if (order.reason) embed.addFields({name:'ข้อความจากร้าน',value:order.reason.slice(0,500)});
 return embed;
}

export function slipModal(orderId, late = false) {
 return new ModalBuilder().setCustomId(`${late ? 'late-slip' : 'slip'}:${orderId}`).setTitle(`แนบสลิปออเดอร์ #${orderId}`)
  .addLabelComponents(
   new LabelBuilder().setLabel('อัปโหลดรูปสลิป 1 รูป').setDescription('ใช้ JPG, PNG หรือ WebP ไม่เกิน 8 MB')
    .setFileUploadComponent(new FileUploadBuilder().setCustomId('proof').setRequired(true).setMinValues(1).setMaxValues(1))
  );
}
