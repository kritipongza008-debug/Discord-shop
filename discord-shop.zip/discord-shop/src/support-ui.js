import {ActionRowBuilder,ButtonBuilder,ButtonStyle,EmbedBuilder,StringSelectMenuBuilder} from 'discord.js';
import {orderStatusLabel} from './order-ui.js';

const row = (component) => new ActionRowBuilder().addComponents(component);
const button = (id,label) => new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(ButtonStyle.Primary);

export function supportPicker(orders) {
 if (!orders.length) return {content:'ยังไม่มีออเดอร์ให้ติดต่อร้าน'};
 return {
  content:'**ติดต่อร้าน** · เลือกออเดอร์ที่มีปัญหา',
  components:[row(new StringSelectMenuBuilder().setCustomId('support:pick').setPlaceholder('เลือกออเดอร์')
   .addOptions(orders.map(order=>({label:`#${order.id} · ${order.name}`,value:String(order.id)}))))]
 };
}

export function customerSupport(order,ticket) {
 const embed = new EmbedBuilder().setColor(0xc32d36).setTitle(`ติดต่อร้าน · ออเดอร์ #${order.id}`)
  .setDescription(`**${order.name}** · ${orderStatusLabel(order.status)}`);
 if (ticket) {
  embed.addFields({name:'ข้อความของคุณ',value:ticket.question},{name:'คำตอบจากร้าน',value:ticket.answer ?? 'รอแอดมินตอบ'});
 } else {
  embed.addFields({name:'แจ้งปัญหา',value:'เล่าว่าติดตรงไหน เช่น โอนแล้วแต่ยังไม่ได้สินค้า'});
 }
 return {
  embeds:[embed],
  components:[row(button(`support:write:${order.id}`,ticket?'ส่งข้อความใหม่':'ส่งข้อความถึงร้าน')
   .setDisabled(ticket?.answer===null))]
 };
}

export function adminSupport(order,ticket) {
 const embed = new EmbedBuilder().setColor(0xc32d36).setTitle(`ลูกค้าติดต่อร้าน · ออเดอร์ #${order.id}`)
  .setDescription(`ลูกค้า <@${order.user_id}> · **${order.name}** · ${orderStatusLabel(order.status)}`)
  .addFields({name:'ข้อความจากลูกค้า',value:ticket.question});
 if (order.channel_id) embed.addFields({name:'ห้องออเดอร์',value:`<#${order.channel_id}>`});
 if (ticket.answer) embed.addFields({name:'คำตอบที่บันทึกแล้ว',value:ticket.answer});
 return {embeds:[embed],components:ticket.answer?[]:[row(button(`support:reply:${ticket.id}`,'ตอบลูกค้า'))]};
}
