const maxBytes = 4_000_000;
const hosts = new Set(['cdn.discordapp.com','media.discordapp.net']);
const exactDigits = value => typeof value==='string' && /^[\d -]+$/.test(value) ? value.replace(/[ -]/g,'') : '';
const isoTimestamp = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/;

function receiverMatches(raw, order, config) {
 if (order.method==='truemoney') {
  const phone = exactDigits(config.wallet);
  return Boolean(phone && exactDigits(raw.receiver?.phone)===phone);
 }
 const account = raw.receiver?.account;
 const proxy = account?.proxy;
 const promptpay = exactDigits(config.pp);
 const bankAccount = exactDigits(config.slipBankAccount);
 return Boolean(
  (promptpay && ['NATID','MSISDN'].includes(proxy?.type) && exactDigits(proxy.account)===promptpay) ||
  (bankAccount && config.slipBankCode && raw.receiver?.bank?.id===config.slipBankCode &&
   account?.bank?.type==='BANKAC' && exactDigits(account.bank.account)===bankAccount)
 );
}

export function evaluateSlip(response,order,config,now=Date.now()) {
 if (response?.success!==true || !response.data?.rawSlip) return {note:'API ยังยืนยันสลิปไม่ได้'};
 const data = response.data;
 const raw = data.rawSlip;
 const wallet = order.method==='truemoney';
 const reference = wallet ? raw.transactionId : raw.transRef;
 const amount = wallet ? raw.amount : raw.amount?.amount;
 const timestamp = isoTimestamp.test(raw.date) ? Date.parse(raw.date) : NaN;
 if (data.isDuplicate===true) return {note:'API พบสลิปที่เคยตรวจแล้ว · ตรวจการใช้เลขอ้างอิงก่อนยืนยัน'};
 if (data.isAmountMatched!==true || !Number.isFinite(amount) || Math.abs(amount*100-order.price)>1e-6 ||
     (raw.countryCode && raw.countryCode!=='TH')) {
  return {note:'ยอดเงินหรือสกุลเงินจากสลิปไม่ตรงออเดอร์'};
 }
 if (!Number.isFinite(timestamp) || timestamp<order.created || timestamp>order.expires || timestamp>now) {
  return {note:'เวลาบนสลิปอยู่นอกช่วงชำระของออเดอร์ หรืออ่านเวลาไม่ได้'};
 }
 if (typeof reference!=='string' || !/^[a-z0-9._:/-]{4,120}$/i.test(reference)) {
  return {note:'API ไม่ได้คืนเลขอ้างอิงที่ใช้ยืนยันได้'};
 }
 if (data.isDuplicate!==false || !receiverMatches(raw,order,config)) {
  return {note:wallet && data.matchedAccount
   ? 'ยอดและเวลาตรง · Wallet จับคู่ได้บางส่วน ให้ตรวจผู้รับจากยอดเข้าจริง'
   : 'ยอดและเวลาตรง · ยังยืนยันผู้รับแบบเต็มไม่ได้'};
 }
 return {reference,timestamp,note:'API ตรวจยอด เวลา และผู้รับตรง'};
}

export async function verifyUploadedSlip(proof,order,config,request=fetch) {
 if (proof.size>maxBytes) return {note:'รูปเกิน 4 MB · ส่งให้แอดมินตรวจ'};
 const url = new URL(proof.url);
 if (url.protocol!=='https:' || !hosts.has(url.hostname) || url.username || url.password || url.port) {
  return {note:'เปิดไฟล์สลิปจาก Discord ไม่ได้'};
 }
 const download = await request(url,{redirect:'error',signal:AbortSignal.timeout(8000)});
 if (!download.ok || !download.body || Number(download.headers.get('content-length'))>maxBytes) {
  return {note:'เปิดไฟล์สลิปจาก Discord ไม่ได้'};
 }
 const chunks=[];
 let total=0;
 for await (const chunk of download.body) {
  total+=chunk.byteLength;
  if (total>maxBytes) return {note:'รูปเกิน 4 MB · ส่งให้แอดมินตรวจ'};
  chunks.push(chunk);
 }
 const form = new FormData();
 form.set('image',new Blob(chunks,{type:proof.contentType}),proof.name || 'slip.jpg');
 form.set('matchAccount','true');
 form.set('matchAmount',String(order.price/100));
 form.set('checkDuplicate','true');
 const endpoint = order.method==='truemoney' ? 'truewallet' : 'bank';
 const result = await request(`https://api.easyslip.com/v2/verify/${endpoint}`,{
  method:'POST',body:form,headers:{Authorization:`Bearer ${config.slipKey}`},
  redirect:'error',signal:AbortSignal.timeout(10000)
 });
 if (!result.ok) {
  const code = (await result.json().catch(()=>null))?.error?.code;
  const reasons = {
   QUOTA_EXCEEDED:'โควตา EasySlip หมด',SLIP_PENDING:'ธนาคารยังประมวลผลสลิปอยู่',
   SLIP_NOT_FOUND:'API ไม่พบรายการโอน',INVALID_IMAGE:'API อ่านรูปสลิปไม่ได้'
  };
  return {note:Object.hasOwn(reasons,code) ? reasons[code] : 'EasySlip ยังตรวจสลิปนี้ไม่ได้'};
 }
 return evaluateSlip(await result.json(),order,config);
}
