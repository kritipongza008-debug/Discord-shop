import sharp from 'sharp';

const maxUploadBytes = 20 * 1024 * 1024;
const maxImagePixels = 50_000_000;
const maxHeicPixels = 25_000_000;
const imageHosts = new Set(['cdn.discordapp.com','media.discordapp.net']);
const heicBrands = new Set(['mif1','msf1','heic','heix','hevc','hevx']);
const imageTypes = new Set(['jpeg','png','webp','gif','heif']);

async function readImage(response) {
 const chunks = [];
 let size = 0;
 for await (const chunk of response.body) {
  size += chunk.byteLength;
  if (size > maxUploadBytes) throw Error('ไฟล์ใหญ่เกิน 20 MB');
  chunks.push(chunk);
 }
 return Buffer.concat(chunks,size);
}

export async function compressProductImage(bytes) {
 const image = Buffer.from(bytes);
 if (!image.length || image.length > maxUploadBytes) throw Error('ใช้ไฟล์รูปไม่เกิน 20 MB');
 let input;
 const brand = image.toString('ascii',8,12);
 if (image.toString('ascii',4,8) === 'ftyp' && heicBrands.has(brand)) {
  const {default:decodeHeic} = await import('heic-decode');
  const frames = await decodeHeic.all({buffer:image});
  try {
   const frame = frames[0];
   if (!frame || frame.width * frame.height > maxHeicPixels) {
    throw Error('รูป HEIC มีความละเอียดสูงเกินไป ลองเลือก JPG หรือ HEIC ที่ไม่เกิน 25 ล้านพิกเซล');
   }
   const {data,width,height} = await frame.decode();
   input = sharp(Buffer.from(data.buffer,data.byteOffset,data.byteLength),{raw:{width,height,channels:4},limitInputPixels:maxImagePixels});
  } finally {
   frames.dispose();
  }
 } else {
  input = sharp(image,{limitInputPixels:maxImagePixels,pages:1});
  const metadata = await input.metadata();
  if (!imageTypes.has(metadata.format)) throw Error('รองรับ JPG, PNG, WebP, GIF, AVIF และ HEIC');
 }
 for (const [size, quality] of [[1200,78],[900,70],[640,60],[480,55]]) {
  const output = await input.clone().autoOrient()
   .resize({width:size,height:size,fit:'inside',withoutEnlargement:true})
   .webp({quality}).toBuffer();
  if (output.length <= 350 * 1024 || size === 480) return {extension:'webp',bytes:output};
 }
}

export async function downloadProductImage(attachment) {
 if (!attachment) return null;
 if (attachment.size < 1 || attachment.size > maxUploadBytes) {
  throw Error('เลือกรูปขนาดไม่เกิน 20 MB');
 }
 const url = new URL(attachment.url);
 if (url.protocol !== 'https:' || !imageHosts.has(url.hostname)) throw Error('กรุณาแนบรูปใน Discord โดยตรง');
 let bytes;
 try {
  const response = await fetch(url,{redirect:'error',signal:AbortSignal.timeout(20000)});
  if (!response.ok || !response.body || Number(response.headers.get('content-length')) > maxUploadBytes) {
   throw Error('Image download failed');
  }
  bytes = await readImage(response);
 } catch {
  throw Error('โหลดรูปไม่สำเร็จ ลองแนบรูปเดิมอีกครั้ง');
 }
 try {
  return await compressProductImage(bytes);
 } catch (error) {
  if (/^(รูป HEIC|รองรับ |ใช้ไฟล์)/.test(error.message)) throw error;
  throw Error('เปิดรูปนี้ไม่ได้ ลองเลือกรูป JPG, PNG, WebP หรือ HEIC รูปอื่น');
 }
}
