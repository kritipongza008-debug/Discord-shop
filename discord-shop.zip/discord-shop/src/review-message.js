export async function syncReviewMessage(room, messageId, payload, orderId, unchanged=false) {
 if (messageId) {
  try {
   if (unchanged) await room.messages.fetch({message:messageId,force:true,cache:false});
   else await room.messages.edit(messageId,{content:null,...payload});
   return messageId;
  } catch (error) {
   if (error.code!==10008) throw error;
  }
 }
 const message = await room.send({...payload,nonce:messageId ? `r${messageId}` : `a${orderId}`,enforceNonce:true});
 return message.id;
}
