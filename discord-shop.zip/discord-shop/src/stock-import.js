const maxBytes = 256 * 1024;
const discordHosts = new Set(['cdn.discordapp.com', 'media.discordapp.net']);

export function parseStockFile(bytes) {
 if (bytes.byteLength > maxBytes) throw Error('ไฟล์สต็อกต้องไม่เกิน 256 KB');
 let text;
 try {
  text = new TextDecoder('utf-8', {fatal:true}).decode(bytes);
 } catch {
  throw Error('บันทึกไฟล์ .txt เป็น UTF-8 แล้วลองใหม่');
 }
 if (text.includes('\0')) throw Error('ใช้ไฟล์ข้อความ .txt แบบ UTF-8');
 const lines = text.split(/\r\n|\r|\n/).map(line => line.trim()).filter(Boolean);
 if (!lines.length || lines.length > 500) throw Error('ไฟล์ต้องมีสต็อก 1–500 บรรทัด');
 if (lines.some(line => Buffer.byteLength(line) > 12000)) throw Error('ข้อความสต็อกบางบรรทัดยาวเกินกำหนด');
 return lines;
}

export async function downloadStockFile(attachment) {
 if (!/\.txt$/i.test(attachment.name) || attachment.size < 1 || attachment.size > maxBytes) {
  throw Error('แนบไฟล์ .txt ขนาดไม่เกิน 256 KB');
 }
 const url = new URL(attachment.url);
 if (url.protocol !== 'https:' || !discordHosts.has(url.hostname)) throw Error('แนบไฟล์ใน Discord โดยตรง');
 let response;
 try {
  response = await fetch(url, {redirect:'error', signal:AbortSignal.timeout(8000)});
  if (!response.ok || Number(response.headers.get('content-length')) > maxBytes) throw Error('Invalid file response');
 } catch {
  throw Error('ดาวน์โหลดไฟล์สต็อกไม่ได้ กรุณาแนบใหม่');
 }
 return parseStockFile(await response.arrayBuffer());
}
