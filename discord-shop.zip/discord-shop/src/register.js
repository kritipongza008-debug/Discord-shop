import { REST,Routes } from 'discord.js';import { config } from './config.js';import { commands } from './commands.js';
const c=config();await new REST({version:'10'}).setToken(c.token).put(Routes.applicationGuildCommands(c.client,c.guild),{body:commands});console.log('ลงทะเบียนคำสั่งเรียบร้อย');
