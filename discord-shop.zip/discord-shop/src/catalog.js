import {readFileSync} from 'node:fs';
import {
 ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle,
 ContainerBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder, MessageFlags,
 SectionBuilder, SeparatorBuilder, TextDisplayBuilder, ThumbnailBuilder
} from 'discord.js';
import {activeSalePrice,effectivePrice} from './store.js';

const productsPerPage = 4;
const banner = readFileSync(new URL('./racing-banner.webp',import.meta.url));
const filters = {all:'ทั้งหมด',sale:'โปรวันนี้',ready:'พร้อมส่ง'};
const filterButtons = (filter) => Object.entries(filters).map(([key,label]) =>
 button(key==='all' ? 'catalog:open' : `catalog:filter:${key}`,label,
  key===filter ? ButtonStyle.Primary : ButtonStyle.Secondary));
const availability = count => count===0 ? '⚪ ของหมด' : count<=2 ? `🟠 เหลือน้อย · ${count} ชิ้น` : `🟢 พร้อมส่ง · ${count} ชิ้น`;
const money = (satang) => (satang / 100).toFixed(2) + ' บาท';

function priceLabel(product,now) {
 const price = activeSalePrice(product,now);
 if (price===null) return `**${money(product.price)}**`;
 const deadline = product.sale_ends_at == null ? '' : ` · จบโปร <t:${Math.floor(product.sale_ends_at/1000)}:R>`;
 return `🏷️ **${money(price)}** · ~~${money(product.price)}~~${deadline}`;
}

const red = 0xc32d36;
const text = (content) => new TextDisplayBuilder().setContent(content);
const row = (...components) => new ActionRowBuilder().addComponents(...components);
const button = (id, label, style = ButtonStyle.Secondary) =>
 new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
const safeName = (name) => name.replace(/[\\*_~`|>#]/g, '\\$&').replace(/[\r\n]/g, ' ');

function addImage(store, product, files) {
 const image = store.productImage(product.id);
 if (!image) return null;
 const name = `product-${product.id}.${image.extension}`;
 files.push(new AttachmentBuilder(Buffer.from(image.bytes), {name}));
 return `attachment://${name}`;
}

function message(container, files) {
 return {flags: MessageFlags.IsComponentsV2, components:[container], files};
}

function customerActions() {
 return row(button('catalog:orders','ออเดอร์ของฉัน'),button('catalog:help','วิธีซื้อ'));
}

export function catalogPayload(store, requestedPage = 0, privateView = false, filter = 'all') {
 const now = store.now();
 if (!Object.hasOwn(filters,filter)) filter='all';
 const products = store.products().filter(product =>
  filter==='all' || (filter==='ready' ? product.remaining>0 : activeSalePrice(product,now)!==null)).sort((a,b) => Number(b.remaining > 0) - Number(a.remaining > 0) || a.id - b.id);
 const pageCount = Math.max(1, Math.ceil(products.length / productsPerPage));
 const page = Math.min(Math.max(0, requestedPage), pageCount - 1);
 const visible = products.slice(page * productsPerPage, (page + 1) * productsPerPage);
 const files = [];
 const available = products.filter(product => product.remaining > 0).length;
 const container = new ContainerBuilder().setAccentColor(red)
  .addTextDisplayComponents(text(privateView
   ? `## 🏁 ${filters[filter]}\n-# ZBINGZING RACING`
   : '## 🏁 ZBINGZING RACING\n-# ร้านโค้ดดิจิทัล · เลือกสินค้าแล้วสั่งซื้อได้เลย'));
 if (!privateView) {
  const name = 'racing-banner.webp';
  files.push(new AttachmentBuilder(banner,{name}));
  container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(
   new MediaGalleryItemBuilder().setURL(`attachment://${name}`).setDescription('Honda Wave สีแดงดำในโรงจูน ZBINGZING Racing')
  ));
 }
 container.addActionRowComponents(row(...filterButtons(privateView ? filter : null)));
 if (!visible.length) {
  container.addSeparatorComponents(new SeparatorBuilder())
   .addTextDisplayComponents(text(filter==='all' ? '**ยังไม่มีสินค้าในร้าน**' : `**ยังไม่มีสินค้าในหมวด ${filters[filter]}**\nลองเลือกหมวดอื่นจากปุ่มด้านบน`))
   .addActionRowComponents(customerActions());
  return message(container, files);
 }
 const guide = available
  ? `**วิธีซื้อ** ① เลือกสินค้า → ② โอนเงิน → ③ แนบสลิป\n-# พร้อมขาย ${available} จาก ${products.length} รายการ`
  : 'สินค้าหมดทุกรายการในตอนนี้ · ยังเปิดดูรายละเอียดได้';
 const pageLabel = pageCount>1 ? `\n-# หน้า ${page+1} / ${pageCount}` : '';
 container.addTextDisplayComponents(text(guide+pageLabel));
 if (pageCount>1) {
  const suffix = filter==='all' ? '' : `:${filter}`;
  container.addActionRowComponents(row(
   button(`catalog:page:${page-1}${suffix}`,'ก่อนหน้า').setDisabled(page===0),
   button(`catalog:page:${page+1}${suffix}`,'ถัดไป').setDisabled(page===pageCount-1)
  ));
 }
 for (const product of visible) {
  container.addSeparatorComponents(new SeparatorBuilder());
  const summary = product.description.replace(/\s+/g, ' ').trim();
  const description = summary.length > 85 ? summary.slice(0, 84) + '…' : summary;
  const details = text([
   `**${safeName(product.name)}**`,
   `${priceLabel(product,now)} · ${availability(product.remaining)}`,
   description ? `-# ${description}` : ''
  ].filter(Boolean).join('\n'));
  const view = button(`catalog:product:${product.id}:${page}${filter==='all'?'':':'+filter}`,'ดูสินค้า');
  const image = privateView ? null : addImage(store,product,files);
  const section = new SectionBuilder().addTextDisplayComponents(details);
  if (image) {
   container.addSectionComponents(section.setThumbnailAccessory(new ThumbnailBuilder().setURL(image).setDescription(product.name)))
    .addActionRowComponents(row(view));
  } else {
   container.addSectionComponents(section.setButtonAccessory(view));
  }
 }
 container.addSeparatorComponents(new SeparatorBuilder()).addActionRowComponents(customerActions());
 return message(container, files);
}

export function productPayload(store, product, page = 0, following = false, filter = 'all') {
 const now = store.now();
 const files = [];
 const container = new ContainerBuilder().setAccentColor(product.remaining ? red : 0x737985)
  .addTextDisplayComponents(text(`-# ZBINGZING RACING / สินค้า #${product.id}\n## ${safeName(product.name)}\n${priceLabel(product,now)} · ${availability(product.remaining)}`));
 const image = addImage(store, product, files);
 if (image) {
  container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(
   new MediaGalleryItemBuilder().setURL(image).setDescription(product.name)
  ));
 }
 container.addSeparatorComponents(new SeparatorBuilder())
  .addTextDisplayComponents(text(`__**รายละเอียดสินค้า**__\n${product.description || 'ยังไม่มีคำอธิบายเพิ่มเติม'}`));
 if (product.remaining) {
  container.addTextDisplayComponents(text('**ถ้าต้องการชิ้นนี้** กด **สั่งซื้อ** เพื่อเปิดห้องจ่ายเงิน'));
 }
 const suffix = filter==='all' ? '' : `:${filter}`;
 const actions = [
  button(`buyconfirm:${product.id}:${effectivePrice(product,now)}`,product.remaining ? 'สั่งซื้อ' : 'สินค้าหมด',
   product.remaining ? ButtonStyle.Success : ButtonStyle.Secondary).setDisabled(!product.remaining),
  button(`catalog:page:${page}${suffix}`,'กลับหน้าร้าน')
 ];
 if (!product.remaining || following) {
  actions.push(button(`catalog:restock:${product.id}:${page}:${following?'off':'on'}${suffix}`,
   following ? 'ยกเลิกแจ้งเตือน' : 'แจ้งเตือนเมื่อของเข้า').setEmoji('🔔'));
  container.addTextDisplayComponents(text(following
   ? '-# ติดตามแล้ว · บอทจะแจ้งใน DM หนึ่งครั้งเมื่อสินค้าพร้อมขาย'
   : '-# กดรับแจ้งเตือนใน DM เมื่อสินค้ากลับมาพร้อมขาย'));
 }
 container.addActionRowComponents(row(...actions));
 return message(container, files);
}
