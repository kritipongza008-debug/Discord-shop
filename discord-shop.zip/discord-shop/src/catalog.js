import {
 ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle,
 EmbedBuilder, StringSelectMenuBuilder
} from 'discord.js';

const productsPerPage = 4;
const maxImageBytes = 2 * 1024 * 1024;
const extensions = new Map([
 ['image/png', 'png'],
 ['image/jpeg', 'jpg'],
 ['image/webp', 'webp']
]);
const imageHosts = new Set(['cdn.discordapp.com', 'media.discordapp.net']);
const money = (satang) => (satang / 100).toFixed(2) + ' บาท';

function matchesImage(bytes, extension) {
 if (extension === 'png') return bytes.subarray(0, 8).equals(Buffer.from('89504e470d0a1a0a', 'hex'));
 if (extension === 'jpg') return bytes.subarray(0, 3).equals(Buffer.from('ffd8ff', 'hex'));
 return bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP';
}

export async function downloadProductImage(attachment) {
 if (!attachment) return null;
 const extension = extensions.get(attachment.contentType);
 if (!extension || attachment.size < 1 || attachment.size > maxImageBytes) {
  throw Error('ใช้รูป PNG, JPG หรือ WebP ขนาดไม่เกิน 2 MB');
 }
 const url = new URL(attachment.url);
 if (url.protocol !== 'https:' || !imageHosts.has(url.hostname)) {
  throw Error('กรุณาแนบรูปจาก Discord โดยตรง');
 }
 try {
  const response = await fetch(url, {redirect: 'error', signal: AbortSignal.timeout(8000)});
  if (!response.ok) throw Error('Download failed');
  if (Number(response.headers.get('content-length')) > maxImageBytes) throw Error('File too large');
  const bytes = Buffer.from(await response.arrayBuffer());
  if (bytes.length > maxImageBytes || !matchesImage(bytes, extension)) throw Error('Invalid image');
  return {extension, bytes};
 } catch {
  throw Error('อ่านไฟล์รูปไม่ได้ กรุณาแนบรูป PNG, JPG หรือ WebP ใหม่');
 }
}

export function catalogPayload(store, requestedPage = 0, privateView = false) {
 const products = store.products();
 const pageCount = Math.max(1, Math.ceil(products.length / productsPerPage));
 const page = Math.min(Math.max(0, requestedPage), pageCount - 1);
 const visible = products.slice(page * productsPerPage, (page + 1) * productsPerPage);
 const components = [];
 const files = [];
 const embeds = visible.map((product) => {
  const stock = product.remaining ? `เหลือ ${product.remaining} ชิ้น` : 'สินค้าหมด';
  const summary = product.description.length > 140 ? product.description.slice(0, 139) + '…' : product.description;
  const embed = new EmbedBuilder()
   .setTitle(product.name)
   .setDescription([`**${money(product.price)}** · ${stock}`, summary].filter(Boolean).join('\n'))
   .setColor(0x5865f2);
  const image = store.productImage(product.id);
  if (image) {
   const name = `product-${product.id}.${image.extension}`;
   files.push(new AttachmentBuilder(Buffer.from(image.bytes), {name}));
   embed.setThumbnail(`attachment://${name}`);
  }
  return embed;
 });

 if (visible.length) {
  const select = new StringSelectMenuBuilder()
   .setCustomId(`buy:${page}`).setPlaceholder('เลือกสินค้าเพื่อดูรายละเอียด')
   .addOptions(visible.map((product) => ({
    label: product.name,
    description: `#${product.id} | ${money(product.price)} | เหลือ ${product.remaining} ชิ้น`,
    value: String(product.id)
   })));
  components.push(new ActionRowBuilder().addComponents(select));
 }

 if (pageCount > 1 && privateView) {
  components.push(new ActionRowBuilder().addComponents(
   new ButtonBuilder().setCustomId(`catalog:page:${page - 1}`).setLabel('ก่อนหน้า')
    .setStyle(ButtonStyle.Secondary).setDisabled(page === 0),
   new ButtonBuilder().setCustomId(`catalog:page:${page + 1}`).setLabel('ถัดไป')
    .setStyle(ButtonStyle.Secondary).setDisabled(page === pageCount - 1)
  ));
 } else if (pageCount > 1) {
  components.push(new ActionRowBuilder().addComponents(
   new ButtonBuilder().setCustomId('catalog:open').setLabel('ดูสินค้าทั้งหมด').setStyle(ButtonStyle.Primary)
  ));
 }
 const pageLabel = privateView && pageCount > 1 ? ` · หน้า ${page + 1}/${pageCount}` : '';
 return {
  content: visible.length ? `🛒 **ร้านค้า**${pageLabel}\nเลือกสินค้าจากรายการด้านล่างเพื่อดูรายละเอียดก่อนซื้อ` : '🛒 **ร้านค้า**\nยังไม่มีสินค้า',
  embeds, components, files
 };
}
