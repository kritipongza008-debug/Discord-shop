import {
 ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle,
 ContainerBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder, MessageFlags,
 SectionBuilder, SeparatorBuilder, TextDisplayBuilder, ThumbnailBuilder
} from 'discord.js';

const productsPerPage = 4;
const money = (satang) => (satang / 100).toFixed(2) + ' บาท';

const red = 0xc32d36;
const text = (content) => new TextDisplayBuilder().setContent(content);
const row = (...components) => new ActionRowBuilder().addComponents(...components);
const button = (id, label, style = ButtonStyle.Secondary) =>
 new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
const safeName = (name) => name.replace(/[\\*_~`|>#]/g, '\\$&').replace(/[\r\n]/g, ' ');

function addImage(store, product, files) {
 const image = store.productImage(product.id);
 if (!image) return null;
 const name = `product-${product.id}.${image.extension}`;
 files.push(new AttachmentBuilder(Buffer.from(image.bytes), {name}));
 return `attachment://${name}`;
}

function message(container, files) {
 return {flags: MessageFlags.IsComponentsV2, components:[container], files};
}

function customerActions() {
 return row(button('catalog:orders','ออเดอร์ของฉัน'),button('catalog:help','วิธีซื้อ'));
}

export function catalogPayload(store, requestedPage = 0, privateView = false) {
 const products = store.products().sort((a,b) => Number(b.remaining > 0) - Number(a.remaining > 0) || a.id - b.id);
 const pageCount = Math.max(1, Math.ceil(products.length / productsPerPage));
 const page = Math.min(Math.max(0, requestedPage), pageCount - 1);
 const visible = products.slice(page * productsPerPage, (page + 1) * productsPerPage);
 const files = [];
 const available = products.filter(product => product.remaining > 0).length;
 const container = new ContainerBuilder().setAccentColor(red)
  .addTextDisplayComponents(text('## 🏁 ZBINGZING RACING\n-# ร้านขายโค้ด · กดเลือกสินค้าด้านล่าง'));
 if (!visible.length) {
  container.addSeparatorComponents(new SeparatorBuilder())
   .addTextDisplayComponents(text('**ยังไม่มีสินค้าในร้าน**\nแวะกลับมาดูใหม่ได้'))
   .addActionRowComponents(customerActions());
  return message(container, files);
 }
 container.addTextDisplayComponents(text(
  available ? `**วิธีซื้อ** ① เลือกสินค้า → ② โอนเงิน → ③ แนบสลิป\n-# พร้อมขาย ${available} จาก ${products.length} รายการ`
   : 'สินค้าหมดทุกรายการในตอนนี้ · ยังเปิดดูรายละเอียดได้'
 ));
 for (const product of visible) {
  container.addSeparatorComponents(new SeparatorBuilder());
  const summary = product.description.replace(/\s+/g, ' ').trim();
  const description = summary.length > 85 ? summary.slice(0, 84) + '…' : summary;
  const details = text([
   `**${safeName(product.name)}**`,
   `**${money(product.price)}** · ${product.remaining ? `🟢 เหลือ ${product.remaining} ชิ้น` : '⚪ หมดชั่วคราว'}`,
   description ? `-# ${description}` : ''
  ].filter(Boolean).join('\n'));
  const view = button(`catalog:product:${product.id}:${page}`,'ดูสินค้า');
  const image = addImage(store, product, files);
  const section = new SectionBuilder().addTextDisplayComponents(details);
  if (image) {
   container.addSectionComponents(section.setThumbnailAccessory(new ThumbnailBuilder().setURL(image).setDescription(product.name)))
    .addActionRowComponents(row(view));
  } else {
   container.addSectionComponents(section.setButtonAccessory(view));
  }
 }
 if (pageCount > 1) {
  container.addSeparatorComponents(new SeparatorBuilder());
  if (privateView) {
   container.addTextDisplayComponents(text(`-# หน้า ${page + 1} / ${pageCount}`))
    .addActionRowComponents(row(
     button(`catalog:page:${page - 1}`,'ก่อนหน้า').setDisabled(page === 0),
     button(`catalog:page:${page + 1}`,'ถัดไป').setDisabled(page === pageCount - 1)
    ));
  } else {
   container.addActionRowComponents(row(button('catalog:open',`ดูสินค้าทั้งหมด ${products.length} รายการ`,ButtonStyle.Primary)));
  }
 }
 container.addSeparatorComponents(new SeparatorBuilder()).addActionRowComponents(customerActions());
 return message(container, files);
}

export function productPayload(store, product, page = 0) {
 const files = [];
 const container = new ContainerBuilder().setAccentColor(product.remaining ? red : 0x737985)
  .addTextDisplayComponents(text(`-# ZBINGZING RACING / สินค้า #${product.id}\n## ${safeName(product.name)}\n**${money(product.price)}** · ${product.remaining ? `พร้อมขาย ${product.remaining} ชิ้น` : 'หมดชั่วคราว'}`));
 const image = addImage(store, product, files);
 if (image) {
  container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(
   new MediaGalleryItemBuilder().setURL(image).setDescription(product.name)
  ));
 }
 container.addSeparatorComponents(new SeparatorBuilder())
  .addTextDisplayComponents(text(`__**รายละเอียดสินค้า**__\n${product.description || 'ยังไม่มีคำอธิบายเพิ่มเติม'}`));
 if (product.remaining) {
  container.addTextDisplayComponents(text('**ถ้าต้องการชิ้นนี้** กด **สั่งซื้อ** เพื่อเปิดห้องจ่ายเงิน'));
 }
 container.addActionRowComponents(row(
  button(`buyconfirm:${product.id}:${product.price}`,product.remaining ? 'สั่งซื้อ' : 'สินค้าหมด',
   product.remaining ? ButtonStyle.Success : ButtonStyle.Secondary).setDisabled(!product.remaining),
  button(`catalog:page:${page}`,'กลับหน้าร้าน')
 ));
 return message(container, files);
}
