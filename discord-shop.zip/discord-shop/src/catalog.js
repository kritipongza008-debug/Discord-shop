import {readFileSync} from 'node:fs';
import {
 ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle,
 ContainerBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder, MessageFlags,
 SectionBuilder, SeparatorBuilder, StringSelectMenuBuilder, TextDisplayBuilder, ThumbnailBuilder
} from 'discord.js';
import {activeSalePrice,effectivePrice} from './store.js';

const productsPerPage = 4;
const banner = readFileSync(new URL('./racing-banner.webp',import.meta.url));
const filters = {all:'ทั้งหมด',sale:'โปรวันนี้',ready:'พร้อมส่ง'};
const filterButtons = (filter,appearance) => Object.entries(filters).map(([key,label]) =>
 button(key==='all' ? 'catalog:open' : `catalog:filter:${key}`,appearance[key] || label,
  key===filter ? ButtonStyle.Primary : ButtonStyle.Secondary));
const availability = count => count===0 ? '⚪ ของหมด' : count<=2 ? `🟠 เหลือน้อย · ${count} ชิ้น` : `🟢 พร้อมส่ง · ${count} ชิ้น`;
const money = (satang) => (satang / 100).toFixed(2) + ' บาท';

function priceLabel(product,now) {
 const price = activeSalePrice(product,now);
 if (price===null) return `**${money(product.price)}**`;
 const deadline = product.sale_ends_at == null ? '' : ` · จบโปร <t:${Math.floor(product.sale_ends_at/1000)}:R>`;
 return `🏷️ **${money(price)}** · ~~${money(product.price)}~~${deadline}`;
}

const red = 0xc32d36;
const text = (content) => new TextDisplayBuilder().setContent(content);
const row = (...components) => new ActionRowBuilder().addComponents(...components);
const button = (id, label, style = ButtonStyle.Secondary) =>
 new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
const safeName = (name) => name.replace(/[\\*_~`|>#]/g, '\\$&').replace(/[\r\n]/g, ' ');

function addImage(store, product, files) {
 const image = store.productImage(product.id);
 if (!image) return null;
 const name = `product-${product.id}.${image.extension}`;
 files.push(new AttachmentBuilder(Buffer.from(image.bytes), {name}));
 return `attachment://${name}`;
}

function message(container, files) {
 return {flags: MessageFlags.IsComponentsV2, components:[container], files};
}

function customerActions(appearance) {
 return row(button('catalog:orders',appearance.orders || 'ออเดอร์ของฉัน'),button('catalog:help',appearance.help || 'วิธีซื้อ'));
}

export function catalogPayload(store, requestedPage = 0, privateView = false, filter = 'all', search = '') {
 const now = store.now();
 const appearance = store.appearance();
 if (!search && !Object.hasOwn(filters,filter)) filter='all';
 const category = search ? 'ผลค้นหาสินค้า' : appearance[filter] || filters[filter];
 const query = search.normalize('NFC').toLowerCase();
 const notice = store.pauseNotice();
 const products = store.products().filter(product =>
  search ? product.name.normalize('NFC').toLowerCase().includes(query) :
  filter==='all' || (filter==='ready' ? product.remaining>0 : activeSalePrice(product,now)!==null)).sort((a,b) => (!search && filter==='all' ? Number(Boolean(b.featured))-Number(Boolean(a.featured)) : 0)
   || Number(b.remaining > 0) - Number(a.remaining > 0) || a.id - b.id);
 const pageCount = Math.max(1, Math.ceil(products.length / productsPerPage));
 const page = Math.min(Math.max(0, requestedPage), pageCount - 1);
 const visible = products.slice(page * productsPerPage, (page + 1) * productsPerPage);
 const files = [];
 const available = products.filter(product => product.remaining > 0).length;
 const shopTitle = safeName(appearance.title || 'ZBINGZING RACING');
 const title = privateView ? `## 🏁 ${safeName(category)}\n-# ${shopTitle}` : `## 🏁 ${shopTitle}`;
 const subtitle = notice!==null ? `\n**พักรับออเดอร์** · ${safeName(notice)}`
  : privateView ? '' : `\n-# ${appearance.subtitle || 'เลือกสินค้า แล้วกดซื้อได้เลย'}`;
 const container = new ContainerBuilder().setAccentColor(appearance.color ?? red)
  .addTextDisplayComponents(text(title+subtitle));
 if (!privateView && appearance.bannerMode!=='none') {
  const name = 'racing-banner.webp';
  files.push(new AttachmentBuilder(Buffer.from(store.shopBanner() ?? banner),{name}));
  container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(
   new MediaGalleryItemBuilder().setURL(`attachment://${name}`).setDescription('แบนเนอร์ '+shopTitle)
  ));
 }
 const featured = !privateView && page===0 ? visible.find(product=>product.featured) : null;
 if (featured) {
  const details = text(`### ⭐ สินค้าเด่น
**${safeName(featured.name)}**
${priceLabel(featured,now)} · ${availability(featured.remaining)}`);
  const image = addImage(store,featured,files);
  if (image) {
   container.addSectionComponents(new SectionBuilder().addTextDisplayComponents(details)
    .setThumbnailAccessory(new ThumbnailBuilder().setURL(image).setDescription(featured.name)));
  } else {
   container.addTextDisplayComponents(details);
  }
  container.addActionRowComponents(row(button(`catalog:product:${featured.id}:0`,'ดูสินค้าเด่น',ButtonStyle.Primary)));
  container.addSeparatorComponents(new SeparatorBuilder());
 }
 const suffix = filter==='all' ? '' : `:${filter}`;
 const searchButton = button('catalog:search',appearance.search || 'ค้นหาสินค้า');
 const nextButton = button(`catalog:page:${page+1}${suffix}`,
  appearance.next || 'ถัดไป',ButtonStyle.Primary).setDisabled(page===pageCount-1);
 if (privateView) {
  container.addActionRowComponents(row(...filterButtons(filter,appearance),searchButton));
 } else {
  const actions = [searchButton];
  if (pageCount>1) actions.push(nextButton);
  actions.push(button('catalog:orders',appearance.orders || 'ออเดอร์ของฉัน'));
  container.addActionRowComponents(row(...actions));
 }
 if (!visible.length) {
  container.addTextDisplayComponents(text(search ? '**ไม่พบสินค้าที่ตรงกับคำค้น** ลองใช้ชื่อบางส่วน'
   : filter==='all' ? '**ยังไม่มีสินค้าในร้าน**' : `**ยังไม่มีสินค้าในหมวด ${safeName(category)}**`));
 } else {
  const summary = `-# พร้อมขาย ${available}/${products.length} รายการ${pageCount>1 ? ` · หน้า ${page+1}/${pageCount}` : ''}`;
  const guide = notice===null ? appearance.guide || '① เลือกสินค้า → ② กดซื้อ → ③ โอนและแนบสลิป' : '';
  container.addTextDisplayComponents(text(guide && !privateView ? `${guide}\n${summary}` : summary));
  if (privateView && pageCount>1) {
   container.addActionRowComponents(row(
    button(`catalog:page:${page-1}${suffix}`,appearance.previous || 'ก่อนหน้า').setDisabled(page===0),nextButton
   ));
  }
  container.addActionRowComponents(row(new StringSelectMenuBuilder()
   .setCustomId(`catalog:select:${page}${suffix}`)
   .setPlaceholder(appearance.view || '① แตะตรงนี้เพื่อเลือกสินค้า')
   .addOptions(visible.map(product=>({
    label:((product.featured ? '⭐ ' : '')+product.name).slice(0,100),
    value:String(product.id),
    description:`${money(effectivePrice(product,now))} · ${product.remaining ? 'เหลือ '+product.remaining+' ชิ้น' : 'ของหมด'}`
   })))));
  container.addSeparatorComponents(new SeparatorBuilder());
  for (const product of visible) {
   if (product===featured) continue;
   const details = text(`**${safeName(product.name)}**\n${priceLabel(product,now)} · ${availability(product.remaining)}`);
   const image = privateView ? null : addImage(store,product,files);
   if (image) {
    container.addSectionComponents(new SectionBuilder().addTextDisplayComponents(details)
     .setThumbnailAccessory(new ThumbnailBuilder().setURL(image).setDescription(product.name)));
   } else {
    container.addTextDisplayComponents(details);
   }
  }
 }
 container.addActionRowComponents(privateView ? customerActions(appearance) : row(
  button('catalog:open',appearance.all || 'ดูหมวดสินค้า'),button('catalog:help',appearance.help || 'วิธีซื้อ')
 ));
 return message(container, files);
}

export function productPayload(store, product, page = 0, following = false, filter = 'all') {
 const now = store.now();
 const appearance = store.appearance();
 const notice = store.pauseNotice();
 const files = [];
 const container = new ContainerBuilder().setAccentColor(product.remaining ? appearance.color ?? red : 0x737985)
  .addTextDisplayComponents(text(`-# ${safeName(appearance.title || 'ZBINGZING RACING')} / สินค้า #${product.id}\n## ${safeName(product.name)}\n${priceLabel(product,now)} · ${availability(product.remaining)}`));
 if (notice!==null) {
  container.addTextDisplayComponents(text(`**พักรับออเดอร์** · ${safeName(notice)}`));
 } else if (product.remaining) {
  container.addTextDisplayComponents(text(appearance.checkout || '**② กดซื้อ** แล้วบอทจะเปิดห้องให้เลือกวิธีจ่ายและแนบสลิป'));
 }
 const suffix = filter==='all' ? '' : `:${filter}`;
 const actions = [
  button(`buyconfirm:${product.id}:${effectivePrice(product,now)}`,notice!==null ? 'พักรับออเดอร์' : product.remaining ? `${appearance.buy || 'ซื้อเลย'} · ${money(effectivePrice(product,now))}` : 'สินค้าหมด',
   notice===null && product.remaining ? ButtonStyle.Success : ButtonStyle.Secondary).setDisabled(notice!==null || !product.remaining),
  button(`catalog:page:${page}${suffix}`,filter.startsWith('search-') ? 'กลับผลค้นหา' : appearance.back || 'กลับรายการสินค้า')
 ];
 if (!product.remaining || following) {
  actions.push(button(`catalog:restock:${product.id}:${page}:${following?'off':'on'}${suffix}`,
   following ? 'ยกเลิกแจ้งเตือน' : 'แจ้งเตือนเมื่อของเข้า').setEmoji('🔔'));
  container.addTextDisplayComponents(text(following
   ? '-# ติดตามแล้ว · บอทจะแจ้งใน DM หนึ่งครั้งเมื่อสินค้าพร้อมขาย'
   : '-# กดรับแจ้งเตือนใน DM เมื่อสินค้ากลับมาพร้อมขาย'));
 }
 if (notice===null && product.remaining) actions.push(button(`coupon:${product.id}:${effectivePrice(product,now)}`,appearance.coupon || 'ใช้คูปอง'));
 container.addActionRowComponents(row(...actions));
 const image = addImage(store, product, files);
 if (image) {
  container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(
   new MediaGalleryItemBuilder().setURL(image).setDescription(product.name)
  ));
 }
 container.addSeparatorComponents(new SeparatorBuilder())
  .addTextDisplayComponents(text(`__**รายละเอียดสินค้า**__\n${product.description || 'ยังไม่มีคำอธิบายเพิ่มเติม'}`));
 return message(container, files);
}
