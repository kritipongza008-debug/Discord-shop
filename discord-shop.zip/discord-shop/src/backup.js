import { DatabaseSync,backup } from 'node:sqlite';import {mkdirSync,chmodSync} from 'node:fs';
mkdirSync('backups',{recursive:true,mode:0o700});const db=new DatabaseSync(process.env.DB_PATH||'./data/shop.sqlite');const file=`backups/shop-${new Date().toISOString().replaceAll(':','-')}.sqlite`;await backup(db,file);chmodSync(file,0o600);db.close();console.log(file);
