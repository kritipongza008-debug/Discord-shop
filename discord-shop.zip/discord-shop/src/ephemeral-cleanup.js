import {MessageFlags, MessageFlagsBitField} from 'discord.js';

const isPrivate = message => message?.flags?.has(MessageFlags.Ephemeral);

export function ephemeralCleanup(onError, delay=30_000) {
 const timers = new Map();
 return interaction => {
  function schedule(id, target='@original') {
   clearTimeout(timers.get(id));
   const timer = setTimeout(async () => {
    timers.delete(id);
    try { await interaction.deleteReply(target); }
    catch (error) {
     if (![10008,10015,10062,50027].includes(error.code)) onError(error);
    }
   }, delay);
   timers.set(id,timer);
   timer.unref();
  }

  const reply = interaction.reply.bind(interaction);
  interaction.reply = async options => {
   const hidden = options?.ephemeral || new MessageFlagsBitField(options?.flags).has(MessageFlags.Ephemeral);
   if (!hidden) return reply(options);
   const response = await reply({...options,withResponse:true});
   schedule(response.resource?.message?.id ?? response.interaction.responseMessageId ?? interaction.id);
   return response;
  };

  for (const method of ['editReply','followUp']) {
   const respond = interaction[method].bind(interaction);
   interaction[method] = async options => {
    const message = await respond(options);
    if (isPrivate(message)) schedule(message.id,method==='followUp' ? message.id : options?.message);
    return message;
   };
  }
  for (const method of ['update','deferUpdate']) {
   if (!interaction[method]) continue;
   const respond = interaction[method].bind(interaction);
   interaction[method] = async options => {
    const response = await respond(options);
    if (isPrivate(interaction.message)) schedule(interaction.message.id);
    return response;
   };
  }
 };
}
