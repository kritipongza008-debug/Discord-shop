import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
export class Store {
 constructor(path, now=()=>Date.now()) {
  mkdirSync(dirname(path),{recursive:true}); this.db=new DatabaseSync(path); this.now=now;
  this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
  CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL, price INTEGER NOT NULL CHECK(price>0), active INTEGER NOT NULL DEFAULT 1);
  CREATE TABLE IF NOT EXISTS stock(id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id), content TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'available');
  CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, user_id TEXT NOT NULL, product_id INTEGER NOT NULL REFERENCES products(id), stock_id INTEGER NOT NULL REFERENCES stock(id), price INTEGER NOT NULL, payer TEXT NOT NULL, method TEXT, status TEXT NOT NULL DEFAULT 'pending', created INTEGER NOT NULL, expires INTEGER NOT NULL, queued INTEGER, channel_id TEXT, message_id TEXT, admin_message_id TEXT, proof TEXT, admin_id TEXT, reason TEXT, delivery_id TEXT);
  CREATE UNIQUE INDEX IF NOT EXISTS one_open_order ON orders(user_id) WHERE status IN ('pending','review','info','approved','sending');
  CREATE UNIQUE INDEX IF NOT EXISTS one_stock_order ON orders(stock_id) WHERE status NOT IN ('expired','rejected','cancelled');
  CREATE TABLE IF NOT EXISTS panels(channel_id TEXT NOT NULL,message_id TEXT PRIMARY KEY);`);
 }
 run(q,...a){return this.db.prepare(q).run(...a)} get(q,...a){return this.db.prepare(q).get(...a)} all(q,...a){return this.db.prepare(q).all(...a)}
 tx(fn){this.db.exec('BEGIN IMMEDIATE');try{const r=fn();this.db.exec('COMMIT');return r}catch(e){this.db.exec('ROLLBACK');throw e}}
 products(){return this.all(`SELECT p.*, (SELECT count(*) FROM stock s WHERE s.product_id=p.id AND s.status='available') remaining FROM products p WHERE active=1 ORDER BY p.id`)}
 addProduct(name,description,price){if(!Number.isSafeInteger(price)||price<=0)throw Error('ราคาไม่ถูกต้อง');return Number(this.run('INSERT INTO products(name,description,price) VALUES(?,?,?)',name,description,price).lastInsertRowid)}
 addStock(id,content){if(!this.get('SELECT id FROM products WHERE id=?',id))throw Error('ไม่พบสินค้า');if(!content.trim()||Buffer.byteLength(content)>12000)throw Error('ข้อความต้องมีข้อมูลและไม่เกิน 12000 bytes');this.run('INSERT INTO stock(product_id,content) VALUES(?,?)',id,content)}
 order(id){return this.get('SELECT o.*,p.name,p.description FROM orders o JOIN products p ON p.id=o.product_id WHERE o.id=?',id)}
 reserve(uid,pid,payer,minutes=15){return this.tx(()=>{
  this.expire();if(this.get("SELECT id FROM orders WHERE user_id=? AND status IN ('pending','review','info','approved','sending')",uid))throw Error('คุณมีคำสั่งซื้อที่ยังไม่เสร็จ กรุณาตรวจห้องเดิม');
  const p=this.get('SELECT * FROM products WHERE id=? AND active=1',pid);if(!p)throw Error('สินค้านี้ปิดขายแล้ว');
  const s=this.get("SELECT id FROM stock WHERE product_id=? AND status='available' ORDER BY id LIMIT 1",pid);if(!s)throw Error('สินค้าหมดแล้ว');
  this.run("UPDATE stock SET status='reserved' WHERE id=?",s.id);
  const id=Number(this.run('INSERT INTO orders(user_id,product_id,stock_id,price,payer,created,expires) VALUES(?,?,?,?,?,?,?)',uid,pid,s.id,p.price,payer,this.now(),this.now()+minutes*60000).lastInsertRowid);return this.order(id);
 })}
 expire(){const rows=this.all("SELECT id,stock_id FROM orders WHERE status='pending' AND expires<=?",this.now());for(const o of rows){this.run("UPDATE orders SET status='expired' WHERE id=?",o.id);this.run("UPDATE stock SET status='available' WHERE id=?",o.stock_id)}return rows}
 release(id,status,reason='',admin=''){return this.tx(()=>{const o=this.order(id);if(!o||!['pending','review','info'].includes(o.status))throw Error('รายการนี้ปิดแล้วหรืออนุมัติแล้ว');this.run('UPDATE orders SET status=?,reason=?,admin_id=? WHERE id=?',status,reason,admin,id);this.run("UPDATE stock SET status='available' WHERE id=?",o.stock_id)})}
 submit(id,uid,url){return this.tx(()=>{this.expire();const o=this.order(id);if(!o||o.user_id!==uid||!['pending','info'].includes(o.status))throw Error('รายการนี้ส่งหลักฐานไม่ได้ หรือหมดเวลาจองแล้ว ติดต่อแอดมินหากโอนแล้ว');if(!o.method)throw Error('เลือกวิธีชำระก่อน');this.run("UPDATE orders SET status='review',proof=?,queued=COALESCE(queued,?) WHERE id=?",url,this.now(),id)})}
 approve(id,admin){return this.tx(()=>{const o=this.order(id);if(!o||!['review','info'].includes(o.status))throw Error('รายการนี้ไม่อยู่ระหว่างตรวจ หรือยืนยันแล้ว');this.run("UPDATE orders SET status='approved',admin_id=? WHERE id=?",admin,id);this.run("UPDATE stock SET status='sold' WHERE id=?",o.stock_id)})}
 ahead(o){return this.get("SELECT count(*) n FROM orders WHERE status IN ('review','info') AND (queued<? OR (queued=? AND id<?))",o.queued,o.queued,o.id).n}
 close(){this.db.close()}
}
