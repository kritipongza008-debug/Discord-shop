import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
export const roomCloseDelay = 120000;
export const finishedOrderStatuses = ['delivered','rejected','cancelled','expired','refunded'];
const finishedSql = finishedOrderStatuses.map(status => "'"+status+"'").join(',');
export const reviewStatuses = ['review','info','late_review','late_info'];
const reviewSql = "('review','info','late_review','late_info')";
const late = (status) => status === 'late_review' || status === 'late_info';

export function activeSalePrice({sale_price,sale_ends_at}, now) {
 return sale_ends_at != null && sale_ends_at<=now ? null : sale_price ?? null;
}
export function effectivePrice(product, now) { return activeSalePrice(product,now) ?? product.price; }

function normalizePaymentReference(value) {
 const reference = String(value ?? '').normalize('NFKC').toUpperCase().replace(/[\s-]/g, '');
 if (!/^[A-Z0-9._:/]{4,120}$/.test(reference) || !/[A-Z0-9]/.test(reference)) {
  throw Error('กรอกเลขอ้างอิงจากรายการเงินจริง (4–120 ตัวอักษร)');
 }
 return reference;
}

export class Store {
 constructor(path, now=()=>Date.now()) {
  mkdirSync(dirname(path),{recursive:true}); this.db=new DatabaseSync(path); this.now=now;
  this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
  CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL, price INTEGER NOT NULL CHECK(price>0), active INTEGER NOT NULL DEFAULT 1);
  CREATE TABLE IF NOT EXISTS product_images(product_id INTEGER PRIMARY KEY REFERENCES products(id), extension TEXT NOT NULL, bytes BLOB NOT NULL);
  CREATE TABLE IF NOT EXISTS stock(id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id), content TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'available');
  CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, user_id TEXT NOT NULL, product_id INTEGER NOT NULL REFERENCES products(id), stock_id INTEGER NOT NULL REFERENCES stock(id), price INTEGER NOT NULL, payer TEXT NOT NULL, method TEXT, status TEXT NOT NULL DEFAULT 'pending', created INTEGER NOT NULL, expires INTEGER NOT NULL, queued INTEGER, channel_id TEXT, message_id TEXT, admin_message_id TEXT, proof TEXT, admin_id TEXT, reason TEXT, delivery_id TEXT);
  CREATE UNIQUE INDEX IF NOT EXISTS one_open_order ON orders(user_id) WHERE status IN ('pending','review','info','approved','sending');
  CREATE UNIQUE INDEX IF NOT EXISTS one_stock_order_v3 ON orders(stock_id) WHERE status NOT IN ('expired','rejected','cancelled','late_review','late_info','refund_pending','refunded');
  DROP INDEX IF EXISTS one_stock_order_v2;
  DROP INDEX IF EXISTS one_stock_order;
  CREATE TABLE IF NOT EXISTS payment_references(reference TEXT PRIMARY KEY, order_id INTEGER UNIQUE NOT NULL REFERENCES orders(id), recorded INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS order_support(id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id), question TEXT NOT NULL, answer TEXT, answered_by TEXT, created INTEGER NOT NULL, admin_message_id TEXT);
  CREATE UNIQUE INDEX IF NOT EXISTS one_open_support ON order_support(order_id) WHERE answer IS NULL;
  CREATE TABLE IF NOT EXISTS restock_follows(product_id INTEGER NOT NULL REFERENCES products(id), user_id TEXT NOT NULL, PRIMARY KEY(product_id,user_id));
  CREATE TABLE IF NOT EXISTS stock_alerts(product_id INTEGER PRIMARY KEY REFERENCES products(id));
  CREATE TABLE IF NOT EXISTS payment_notices(order_id INTEGER NOT NULL REFERENCES orders(id), kind TEXT NOT NULL, PRIMARY KEY(order_id,kind));
  CREATE TABLE IF NOT EXISTS shop_admin_panel(id INTEGER PRIMARY KEY CHECK(id=1), channel_id TEXT NOT NULL, message_id TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS panels(channel_id TEXT NOT NULL,message_id TEXT PRIMARY KEY);
  CREATE TABLE IF NOT EXISTS shop_activity(id INTEGER PRIMARY KEY, actor TEXT NOT NULL, detail TEXT NOT NULL, created INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS shop_availability(id INTEGER PRIMARY KEY CHECK(id=1), notice TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS shop_settings(id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL);`);
  this.tx(() => {
   if (!this.all('PRAGMA table_info(orders)').some(column=>column.name==='room_close_at')) {
    this.run('ALTER TABLE orders ADD COLUMN room_close_at INTEGER');
   }
   if (!this.all('PRAGMA table_info(orders)').some(column=>column.name==='product_name')) {
    this.run('ALTER TABLE orders ADD COLUMN product_name TEXT');
   }
   if (!this.all('PRAGMA table_info(products)').some(column=>column.name==='sale_price')) {
    this.run('ALTER TABLE products ADD COLUMN sale_price INTEGER CHECK(sale_price IS NULL OR (sale_price>0 AND sale_price<price))');
   }
   if (!this.all('PRAGMA table_info(products)').some(column=>column.name==='sale_ends_at')) {
    this.run('ALTER TABLE products ADD COLUMN sale_ends_at INTEGER');
   }
  });
 }
 run(q,...a){return this.db.prepare(q).run(...a)} get(q,...a){return this.db.prepare(q).get(...a)} all(q,...a){return this.db.prepare(q).all(...a)}
 tx(fn){this.db.exec('BEGIN IMMEDIATE');try{const r=fn();this.db.exec('COMMIT');return r}catch(e){this.db.exec('ROLLBACK');throw e}}
 recordActivity(actor,detail) {
  this.run('INSERT INTO shop_activity(actor,detail,created) VALUES(?,?,?)',actor,detail,this.now());
 }
 recentActivity() {
  return this.all('SELECT actor,detail,created FROM shop_activity ORDER BY id DESC LIMIT 12');
 }
 pauseNotice() {
  return this.get('SELECT notice FROM shop_availability WHERE id=1')?.notice ?? null;
 }
 setPauseNotice(notice,actor) {
  return this.tx(() => {
   if (this.pauseNotice()===notice) return;
   if (notice===null) this.run('DELETE FROM shop_availability WHERE id=1');
   else this.run('INSERT INTO shop_availability VALUES(1,?) ON CONFLICT(id) DO UPDATE SET notice=excluded.notice',notice);
   this.recordActivity(actor,notice===null?'เปิดรับออเดอร์':'พักรับออเดอร์');
  });
 }
 findOrders(query) {
  if (/^\d{17,20}$/.test(query)) {
   return this.all('SELECT id FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 25',query).map(row=>row.id);
  }
  if (!/^#?\d{1,15}$/.test(query)) throw Error('กรอกเลขออเดอร์ เช่น #123 หรือ Discord ID ของลูกค้า');
  const order = this.order(Number(query.replace(/^#/,'')));
  return order ? [order.id] : [];
 }
 overdueReviewNotices() {
  return this.all(`SELECT o.id,o.admin_message_id FROM orders o
   WHERE o.status IN ('review','late_review') AND o.queued<=?
   AND NOT EXISTS (SELECT 1 FROM payment_notices n WHERE n.order_id=o.id AND n.kind='review_overdue')
   ORDER BY o.queued,o.id LIMIT 10`,this.now()-15*60*1000);
 }
 products(){return this.all(`SELECT p.*, (SELECT count(*) FROM stock s WHERE s.product_id=p.id AND s.status='available') remaining FROM products p WHERE active=1 ORDER BY p.id`)}
 addProduct(name,description,price){if(!Number.isSafeInteger(price)||price<=0)throw Error('ราคาไม่ถูกต้อง');return Number(this.run('INSERT INTO products(name,description,price) VALUES(?,?,?)',name,description,price).lastInsertRowid)}
 setSalePrice(id, price, endsAt=null, actor=null) {
  return this.tx(() => {
   const product = this.get('SELECT price FROM products WHERE id=?',id);
   if (!product) throw Error('ไม่พบสินค้า');
   if (price!==null && (!Number.isSafeInteger(price) || price<=0 || price>=product.price)) {
    throw Error('ราคาโปรต้องมากกว่า 0 และต่ำกว่าราคาปกติ');
   }
   if (price!==null && endsAt!==null && (!Number.isSafeInteger(endsAt) || endsAt<=this.now())) {
    throw Error('เลือกเวลาจบโปรที่ยังมาไม่ถึง');
   }
   this.run('UPDATE products SET sale_price=?,sale_ends_at=? WHERE id=?',price,price===null?null:endsAt,id);
   if (actor) this.recordActivity(actor,price===null ? `ปิดโปรสินค้า #${id}` : `ตั้งราคาโปรสินค้า #${id} เป็น ${(price/100).toFixed(2)} บาท`);
  });
 }
 expireSales() {
  return this.run('UPDATE products SET sale_price=NULL,sale_ends_at=NULL WHERE sale_ends_at<=?',this.now()).changes;
 }
 followsRestock(productId,userId) {
  return Boolean(this.get('SELECT 1 FROM restock_follows WHERE product_id=? AND user_id=?',productId,userId));
 }
 setRestockFollow(productId,userId,following) {
  if (!following) {
   this.run('DELETE FROM restock_follows WHERE product_id=? AND user_id=?',productId,userId);
   return;
  }
  const result = this.run(`INSERT INTO restock_follows(product_id,user_id)
   SELECT id,? FROM products WHERE id=? AND active=1
   AND NOT EXISTS (SELECT 1 FROM stock WHERE product_id=products.id AND status='available')
   ON CONFLICT(product_id,user_id) DO NOTHING`,userId,productId);
  if (!result.changes && !this.followsRestock(productId,userId)) {
   throw Error('สินค้ามีพร้อมขายแล้วหรือปิดขายอยู่ ลองเปิดรายละเอียดสินค้าใหม่');
  }
 }
 restockNotices() {
  return this.all(`SELECT p.id,p.name,f.user_id FROM restock_follows f JOIN products p ON p.id=f.product_id
   WHERE p.active=1 AND EXISTS (SELECT 1 FROM stock WHERE product_id=p.id AND status='available')
   ORDER BY f.rowid LIMIT 20`);
 }
 claimRestockNotice(productId,userId) {
  return this.run(`DELETE FROM restock_follows WHERE product_id=? AND user_id=?
   AND EXISTS (SELECT 1 FROM products WHERE id=? AND active=1)
   AND EXISTS (SELECT 1 FROM stock WHERE product_id=? AND status='available')`,
   productId,userId,productId,productId).changes===1;
 }
 productImage(id) {
  return this.get('SELECT extension,bytes FROM product_images WHERE product_id=?', id);
 }
 setProductImage(id, image) {
  this.run('INSERT INTO product_images(product_id,extension,bytes) VALUES(?,?,?) ON CONFLICT(product_id) DO UPDATE SET extension=excluded.extension,bytes=excluded.bytes',
   id, image.extension, image.bytes);
 }
 addStock(id,content){if(!this.get('SELECT id FROM products WHERE id=?',id))throw Error('ไม่พบสินค้า');if(!content.trim()||Buffer.byteLength(content)>12000)throw Error('ข้อความต้องมีข้อมูลและไม่เกิน 12000 bytes');this.run('INSERT INTO stock(product_id,content) VALUES(?,?)',id,content)}
 stockImportPlan(productId, lines) {
  if (!this.get('SELECT id FROM products WHERE id=?', productId)) throw Error('ไม่พบสินค้า');
  const existing = this.db.prepare('SELECT 1 FROM stock WHERE product_id=? AND content=? LIMIT 1');
  const unique = [...new Set(lines)];
  const fresh = unique.filter(line => !existing.get(productId, line));
  return {fresh, skipped: lines.length - fresh.length};
 }
 importStock(productId, lines, actor=null) {
  return this.tx(() => {
   const {fresh, skipped} = this.stockImportPlan(productId, lines);
   const insert = this.db.prepare('INSERT INTO stock(product_id,content) VALUES(?,?)');
   for (const line of fresh) insert.run(productId, line);
   if (actor && fresh.length) this.recordActivity(actor,`เติมสินค้า #${productId} จำนวน ${fresh.length} ชิ้น`);
   return {added: fresh.length, skipped};
  });
 }
 order(id) {
  return this.get(`SELECT o.*,p.name,p.description,r.recorded AS paid_at FROM orders o
   JOIN products p ON p.id=o.product_id LEFT JOIN payment_references r ON r.order_id=o.id WHERE o.id=?`,id);
 }
 salesToday() {
  const thaiOffset = 7*60*60*1000;
  const day = 24*60*60*1000;
  const start = Math.floor((this.now()+thaiOffset)/day)*day-thaiOffset;
  const end = start+day;
  const received = this.get(`SELECT count(*) AS orders,coalesce(sum(o.price),0) AS amount
   FROM payment_references r JOIN orders o ON o.id=r.order_id WHERE r.recorded>=? AND r.recorded<?`,start,end);
  const refunded = this.get(`SELECT count(*) AS orders,coalesce(sum(price),0) AS amount FROM orders
   WHERE status='refunded' AND room_close_at>=? AND room_close_at<?`,start+roomCloseDelay,end+roomCloseDelay);
  return {received,refunded};
 }
 reserve(uid,pid,payer,minutes=15,expectedPrice=undefined){return this.tx(()=>{
  const notice = this.pauseNotice();
  if (notice!==null) throw Error(`ร้านพักรับออเดอร์ · ${notice}`);
  this.expire();if(this.get("SELECT id FROM orders WHERE user_id=? AND status IN ('pending','review','info','approved','sending')",uid))throw Error('คุณมีคำสั่งซื้อที่ยังไม่เสร็จ กรุณาตรวจห้องเดิม');
  const p=this.get('SELECT * FROM products WHERE id=? AND active=1',pid);if(!p)throw Error('สินค้านี้ปิดขายแล้ว');
  const price=effectivePrice(p,this.now());
  if(expectedPrice!==undefined&&price!==expectedPrice)throw Error('ราคาสินค้าเปลี่ยนแล้ว กรุณาเลือกสินค้าใหม่');
  const s=this.get("SELECT id FROM stock WHERE product_id=? AND status='available' ORDER BY id LIMIT 1",pid);if(!s)throw Error('สินค้าหมดแล้ว');
  this.run("UPDATE stock SET status='reserved' WHERE id=?",s.id);
  const id=Number(this.run('INSERT INTO orders(user_id,product_id,stock_id,price,payer,created,expires,product_name) VALUES(?,?,?,?,?,?,?,?)',uid,pid,s.id,price,payer,this.now(),this.now()+minutes*60000,p.name).lastInsertRowid);return this.order(id);
 })}
 expire(){const rows=this.all("SELECT id,stock_id,expires FROM orders WHERE status='pending' AND expires<=?",this.now());for(const o of rows){this.run("UPDATE orders SET status='expired',room_close_at=? WHERE id=?",o.expires+roomCloseDelay,o.id);this.run("UPDATE stock SET status='available' WHERE id=?",o.stock_id)}return rows}
 release(id, status, reason='', admin='') {
  return this.tx(() => {
   const order = this.order(id);
   if (!order || !(order.status === 'pending' || reviewStatuses.includes(order.status))) {
    throw Error('รายการนี้ปิดแล้วหรืออนุมัติแล้ว');
   }
   this.run('UPDATE orders SET status=?,reason=?,admin_id=?,room_close_at=? WHERE id=?', status, reason, admin, this.now()+roomCloseDelay, id);
   if (!late(order.status)) this.run("UPDATE stock SET status='available' WHERE id=?", order.stock_id);
  });
 }
 canSubmitProof(order, userId) {
  return Boolean(order?.user_id === userId && order.method &&
   ['pending','info','expired','late_info'].includes(order.status));
 }
 submit(id, uid, url) {
  return this.tx(() => {
   this.expire();
   const order = this.order(id);
   if (!order?.method) throw Error('เลือกวิธีชำระก่อน');
   if (!this.canSubmitProof(order, uid)) throw Error('รายการนี้ส่งหลักฐานไม่ได้ กรุณาติดต่อแอดมิน');
   const status = order.status === 'expired' || late(order.status) ? 'late_review' : 'review';
   this.run('UPDATE orders SET status=?,proof=?,queued=COALESCE(queued,?),reason=NULL,room_close_at=NULL WHERE id=?',
    status, url, this.now(), id);
   return status;
  });
 }
 requestInfo(id, reason) {
  const order = this.order(id);
  if (!order || !reviewStatuses.includes(order.status)) throw Error('สถานะรายการเปลี่ยนแล้ว');
  this.run('UPDATE orders SET status=?,reason=? WHERE id=?', late(order.status) ? 'late_info' : 'info', reason, id);
 }
 approve(id, admin, rawReference) {
  return this.tx(() => {
   const order = this.order(id);
   if (!order || !reviewStatuses.includes(order.status)) throw Error('รายการนี้ไม่อยู่ระหว่างตรวจ หรือยืนยันแล้ว');
   let stockId = order.stock_id;
   if (late(order.status)) {
    this.expire();
    const stock = this.get("SELECT id FROM stock WHERE product_id=? AND status='available' ORDER BY id LIMIT 1", order.product_id);
    if (!stock) throw Error('ออเดอร์นี้หมดเวลาชำระเงินและสินค้าหมด ให้เติมสต็อกหรือติดต่อผู้ซื้อเพื่อคืนเงิน');
    stockId = stock.id;
   }
   this.recordPayment(id,rawReference);
   this.run("UPDATE orders SET status='approved',admin_id=?,stock_id=?,reason=NULL WHERE id=?", admin, stockId, id);
   this.run("UPDATE stock SET status='sold' WHERE id=?", stockId);
   this.recordActivity(admin,`ยืนยันยอดออเดอร์ #${id}`);
  });
 }
 recordPayment(id,rawReference) {
  const reference = normalizePaymentReference(rawReference);
  const previous = this.get('SELECT order_id FROM payment_references WHERE reference=?',reference);
  if (previous) throw Error(`เลขอ้างอิงนี้ใช้ยืนยันออเดอร์ #${previous.order_id} ไปแล้ว`);
  this.run('INSERT INTO payment_references(reference,order_id,recorded) VALUES(?,?,?)',reference,id,this.now());
 }
 beginRefund(id,admin,reference) {
  return this.tx(() => {
   const order = this.order(id);
   if (!order || !reviewStatuses.includes(order.status)) throw Error('ตั้งรอคืนเงินได้กับออเดอร์ที่รอตรวจยอดเท่านั้น');
   this.recordPayment(id,reference);
   this.run("UPDATE orders SET status='refund_pending',admin_id=?,reason=NULL WHERE id=?",admin,id);
   if (!late(order.status)) this.run("UPDATE stock SET status='available' WHERE id=?",order.stock_id);
  });
 }
 completeRefund(id,admin) {
  return this.tx(() => {
   if (!this.run("UPDATE orders SET status='refunded',admin_id=?,room_close_at=? WHERE id=? AND status='refund_pending'",admin,this.now()+roomCloseDelay,id).changes) {
    throw Error('ออเดอร์นี้ไม่ได้อยู่ในสถานะรอคืนเงิน');
   }
   this.recordActivity(admin,`คืนเงินออเดอร์ #${id}`);
  });
 }
 latestSupport(orderId,userId) {
  return this.get(`SELECT r.* FROM order_support r JOIN orders o ON o.id=r.order_id
   WHERE o.id=? AND o.user_id=? ORDER BY r.id DESC LIMIT 1`,orderId,userId);
 }
 createSupport(orderId,userId,question) {
  return this.tx(() => {
   if (this.order(orderId)?.user_id !== userId) throw Error('ไม่พบออเดอร์ของคุณ');
   if (this.latestSupport(orderId,userId)?.answer === null) throw Error('ร้านยังไม่ได้ตอบข้อความก่อนหน้า');
   return Number(this.run('INSERT INTO order_support(order_id,question,created) VALUES(?,?,?)',orderId,question,this.now()).lastInsertRowid);
  });
 }
 answerSupport(id,admin,answer) {
  if (!this.run('UPDATE order_support SET answer=?,answered_by=? WHERE id=? AND answer IS NULL',answer,admin,id).changes) {
   throw Error('ข้อความนี้มีคำตอบแล้วหรือไม่พบรายการ');
  }
 }
 resetStockAlerts(threshold) {
  this.run(`DELETE FROM stock_alerts WHERE ?=0 OR product_id IN
   (SELECT p.id FROM products p WHERE p.active=0 OR
    (SELECT count(*) FROM stock s WHERE s.product_id=p.id AND s.status='available')>?)`,threshold,threshold);
 }
 lowStock(threshold) {
  if (!threshold) return [];
  return this.products().filter(product=>product.remaining<=threshold &&
   this.get('SELECT 1 FROM stock WHERE product_id=? LIMIT 1',product.id) &&
   !this.get('SELECT 1 FROM stock_alerts WHERE product_id=?',product.id));
 }
 reviewOrders() {
  return this.all(`SELECT id FROM orders WHERE status IN ${reviewSql} ORDER BY queued,id`);
 }
 ahead(order) {
  return this.get(`SELECT count(*) n FROM orders WHERE status IN ${reviewSql} AND (queued<? OR (queued=? AND id<?))`,
   order.queued, order.queued, order.id).n;
 }
 pendingNotices() {
  const now = this.now();
  return this.all(`SELECT o.id,o.user_id,o.channel_id,'reminder' kind FROM orders o
   WHERE o.status='pending' AND o.channel_id IS NOT NULL AND o.method IS NOT NULL
   AND o.expires>? AND o.expires<=?
   AND NOT EXISTS (SELECT 1 FROM payment_notices n WHERE n.order_id=o.id AND n.kind='reminder')
   ORDER BY o.expires LIMIT 20`,now,now+120000);
 }
 completeDelivery(id,messageId,admin=null) {
  if (!this.run("UPDATE orders SET status='delivered',delivery_id=?,admin_id=COALESCE(?,admin_id),room_close_at=? WHERE id=? AND status='sending'",
   messageId,admin,this.now()+roomCloseDelay,id).changes) {
   throw Error('รายการนี้ไม่ได้อยู่ระหว่างส่งสินค้า');
  }
 }
 deliveredStock(id,userId) {
  return this.get(`SELECT stock.content FROM orders JOIN stock ON stock.id=orders.stock_id
   WHERE orders.id=? AND orders.user_id=? AND orders.status='delivered' AND stock.status='sold'`,id,userId);
 }
 roomsForAdminCleanup() {
  return this.all(`SELECT id,status,channel_id FROM orders WHERE channel_id IS NOT NULL
   AND (status IN (${finishedSql}) OR (status='pending' AND method IS NULL AND proof IS NULL))
   ORDER BY id LIMIT 25`);
 }
 cancelUnstartedOrder(id,channelId,adminId) {
  return this.tx(() => {
   const order = this.order(id);
   if (!order || order.status!=='pending' || order.method || order.proof || order.channel_id!==channelId) return false;
   this.run(`UPDATE orders SET status='cancelled',reason='แอดมินเคลียร์ห้องที่ยังไม่ได้เลือกวิธีจ่าย',
    admin_id=?,room_close_at=? WHERE id=?`,adminId,this.now()+roomCloseDelay,id);
   this.run("UPDATE stock SET status='available' WHERE id=? AND status='reserved'",order.stock_id);
   return true;
  });
 }
 finishedRooms() {
  return this.all(`SELECT id FROM orders WHERE channel_id IS NOT NULL AND status IN (${finishedSql})
   AND (room_close_at<=? OR (room_close_at IS NULL AND status='expired' AND proof IS NULL AND expires+?<=?))
   ORDER BY COALESCE(room_close_at,expires),id LIMIT 20`,this.now(),roomCloseDelay,this.now());
 }
 roomCanClose(order) {
  if (!order?.channel_id || !finishedOrderStatuses.includes(order.status)) return false;
  const deadline = order.room_close_at ?? (order.status==='expired' && !order.proof ? order.expires+roomCloseDelay : Infinity);
  return deadline <= this.now();
 }
 settings() {
  const row = this.get('SELECT value FROM shop_settings WHERE id=1');
  return row ? JSON.parse(row.value) : null;
 }
 saveSettings(expected, settings) {
  return this.tx(() => {
   const current = this.settings();
   if (JSON.stringify(current) !== JSON.stringify(expected)) {
    throw Error('การตั้งค่าเปลี่ยนแล้ว กรุณาเปิด /settings ใหม่');
   }
   if (current?.guild && current.guild !== settings.guild) {
    throw Error('ฐานข้อมูลร้านนี้ผูกกับเซิร์ฟเวอร์อื่นแล้ว');
   }
   this.run('INSERT INTO shop_settings(id,value) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value', JSON.stringify(settings));
  });
 }
 hasOpenOrders() {
  return Boolean(this.get("SELECT id FROM orders WHERE status IN ('pending','review','info','late_review','late_info','approved','sending','refund_pending') LIMIT 1"));
 }
 close(){this.db.close()}
}
