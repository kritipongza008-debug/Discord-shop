import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
export const reviewStatuses = ['review','info','late_review','late_info'];
const reviewSql = "('review','info','late_review','late_info')";
const late = (status) => status === 'late_review' || status === 'late_info';

function normalizePaymentReference(value) {
 const reference = String(value ?? '').normalize('NFKC').toUpperCase().replace(/[\s-]/g, '');
 if (!/^[A-Z0-9._:/]{4,120}$/.test(reference) || !/[A-Z0-9]/.test(reference)) {
  throw Error('กรอกเลขอ้างอิงจากรายการเงินจริง (4–120 ตัวอักษร)');
 }
 return reference;
}

export class Store {
 constructor(path, now=()=>Date.now()) {
  mkdirSync(dirname(path),{recursive:true}); this.db=new DatabaseSync(path); this.now=now;
  this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
  CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL, price INTEGER NOT NULL CHECK(price>0), active INTEGER NOT NULL DEFAULT 1);
  CREATE TABLE IF NOT EXISTS product_images(product_id INTEGER PRIMARY KEY REFERENCES products(id), extension TEXT NOT NULL, bytes BLOB NOT NULL);
  CREATE TABLE IF NOT EXISTS stock(id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id), content TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'available');
  CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, user_id TEXT NOT NULL, product_id INTEGER NOT NULL REFERENCES products(id), stock_id INTEGER NOT NULL REFERENCES stock(id), price INTEGER NOT NULL, payer TEXT NOT NULL, method TEXT, status TEXT NOT NULL DEFAULT 'pending', created INTEGER NOT NULL, expires INTEGER NOT NULL, queued INTEGER, channel_id TEXT, message_id TEXT, admin_message_id TEXT, proof TEXT, admin_id TEXT, reason TEXT, delivery_id TEXT);
  CREATE UNIQUE INDEX IF NOT EXISTS one_open_order ON orders(user_id) WHERE status IN ('pending','review','info','approved','sending');
  CREATE UNIQUE INDEX IF NOT EXISTS one_stock_order_v2 ON orders(stock_id) WHERE status NOT IN ('expired','rejected','cancelled','late_review','late_info');
  DROP INDEX IF EXISTS one_stock_order;
  CREATE TABLE IF NOT EXISTS payment_references(reference TEXT PRIMARY KEY, order_id INTEGER UNIQUE NOT NULL REFERENCES orders(id), recorded INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS payment_notices(order_id INTEGER NOT NULL REFERENCES orders(id), kind TEXT NOT NULL, PRIMARY KEY(order_id,kind));
  CREATE TABLE IF NOT EXISTS panels(channel_id TEXT NOT NULL,message_id TEXT PRIMARY KEY);
  CREATE TABLE IF NOT EXISTS shop_settings(id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL);`);
 }
 run(q,...a){return this.db.prepare(q).run(...a)} get(q,...a){return this.db.prepare(q).get(...a)} all(q,...a){return this.db.prepare(q).all(...a)}
 tx(fn){this.db.exec('BEGIN IMMEDIATE');try{const r=fn();this.db.exec('COMMIT');return r}catch(e){this.db.exec('ROLLBACK');throw e}}
 products(){return this.all(`SELECT p.*, (SELECT count(*) FROM stock s WHERE s.product_id=p.id AND s.status='available') remaining FROM products p WHERE active=1 ORDER BY p.id`)}
 addProduct(name,description,price){if(!Number.isSafeInteger(price)||price<=0)throw Error('ราคาไม่ถูกต้อง');return Number(this.run('INSERT INTO products(name,description,price) VALUES(?,?,?)',name,description,price).lastInsertRowid)}
 productImage(id) {
  return this.get('SELECT extension,bytes FROM product_images WHERE product_id=?', id);
 }
 setProductImage(id, image) {
  this.run('INSERT INTO product_images(product_id,extension,bytes) VALUES(?,?,?) ON CONFLICT(product_id) DO UPDATE SET extension=excluded.extension,bytes=excluded.bytes',
   id, image.extension, image.bytes);
 }
 addStock(id,content){if(!this.get('SELECT id FROM products WHERE id=?',id))throw Error('ไม่พบสินค้า');if(!content.trim()||Buffer.byteLength(content)>12000)throw Error('ข้อความต้องมีข้อมูลและไม่เกิน 12000 bytes');this.run('INSERT INTO stock(product_id,content) VALUES(?,?)',id,content)}
 stockImportPlan(productId, lines) {
  if (!this.get('SELECT id FROM products WHERE id=?', productId)) throw Error('ไม่พบสินค้า');
  const existing = this.db.prepare('SELECT 1 FROM stock WHERE product_id=? AND content=? LIMIT 1');
  const unique = [...new Set(lines)];
  const fresh = unique.filter(line => !existing.get(productId, line));
  return {fresh, skipped: lines.length - fresh.length};
 }
 importStock(productId, lines) {
  return this.tx(() => {
   const {fresh, skipped} = this.stockImportPlan(productId, lines);
   const insert = this.db.prepare('INSERT INTO stock(product_id,content) VALUES(?,?)');
   for (const line of fresh) insert.run(productId, line);
   return {added: fresh.length, skipped};
  });
 }
 order(id){return this.get('SELECT o.*,p.name,p.description FROM orders o JOIN products p ON p.id=o.product_id WHERE o.id=?',id)}
 reserve(uid,pid,payer,minutes=15,expectedPrice=undefined){return this.tx(()=>{
  this.expire();if(this.get("SELECT id FROM orders WHERE user_id=? AND status IN ('pending','review','info','approved','sending')",uid))throw Error('คุณมีคำสั่งซื้อที่ยังไม่เสร็จ กรุณาตรวจห้องเดิม');
  const p=this.get('SELECT * FROM products WHERE id=? AND active=1',pid);if(!p)throw Error('สินค้านี้ปิดขายแล้ว');
  if(expectedPrice!==undefined&&p.price!==expectedPrice)throw Error('ราคาสินค้าเปลี่ยนแล้ว กรุณาเลือกสินค้าใหม่');
  const s=this.get("SELECT id FROM stock WHERE product_id=? AND status='available' ORDER BY id LIMIT 1",pid);if(!s)throw Error('สินค้าหมดแล้ว');
  this.run("UPDATE stock SET status='reserved' WHERE id=?",s.id);
  const id=Number(this.run('INSERT INTO orders(user_id,product_id,stock_id,price,payer,created,expires) VALUES(?,?,?,?,?,?,?)',uid,pid,s.id,p.price,payer,this.now(),this.now()+minutes*60000).lastInsertRowid);return this.order(id);
 })}
 expire(){const rows=this.all("SELECT id,stock_id FROM orders WHERE status='pending' AND expires<=?",this.now());for(const o of rows){this.run("UPDATE orders SET status='expired' WHERE id=?",o.id);this.run("UPDATE stock SET status='available' WHERE id=?",o.stock_id)}return rows}
 release(id, status, reason='', admin='') {
  return this.tx(() => {
   const order = this.order(id);
   if (!order || !(order.status === 'pending' || reviewStatuses.includes(order.status))) {
    throw Error('รายการนี้ปิดแล้วหรืออนุมัติแล้ว');
   }
   this.run('UPDATE orders SET status=?,reason=?,admin_id=? WHERE id=?', status, reason, admin, id);
   if (!late(order.status)) this.run("UPDATE stock SET status='available' WHERE id=?", order.stock_id);
  });
 }
 canSubmitProof(order, userId) {
  return Boolean(order?.user_id === userId && order.method &&
   ['pending','info','expired','late_info'].includes(order.status));
 }
 submit(id, uid, url) {
  return this.tx(() => {
   this.expire();
   const order = this.order(id);
   if (!order?.method) throw Error('เลือกวิธีชำระก่อน');
   if (!this.canSubmitProof(order, uid)) throw Error('รายการนี้ส่งหลักฐานไม่ได้ กรุณาติดต่อแอดมิน');
   const status = order.status === 'expired' || late(order.status) ? 'late_review' : 'review';
   this.run('UPDATE orders SET status=?,proof=?,queued=COALESCE(queued,?),reason=NULL WHERE id=?',
    status, url, this.now(), id);
   return status;
  });
 }
 requestInfo(id, reason) {
  const order = this.order(id);
  if (!order || !reviewStatuses.includes(order.status)) throw Error('สถานะรายการเปลี่ยนแล้ว');
  this.run('UPDATE orders SET status=?,reason=? WHERE id=?', late(order.status) ? 'late_info' : 'info', reason, id);
 }
 approve(id, admin, rawReference) {
  return this.tx(() => {
   const order = this.order(id);
   if (!order || !reviewStatuses.includes(order.status)) throw Error('รายการนี้ไม่อยู่ระหว่างตรวจ หรือยืนยันแล้ว');
   const reference = normalizePaymentReference(rawReference);
   const previous = this.get('SELECT order_id FROM payment_references WHERE reference=?', reference);
   if (previous) throw Error(`เลขอ้างอิงนี้ใช้ยืนยันออเดอร์ #${previous.order_id} ไปแล้ว`);
   let stockId = order.stock_id;
   if (late(order.status)) {
    this.expire();
    const stock = this.get("SELECT id FROM stock WHERE product_id=? AND status='available' ORDER BY id LIMIT 1", order.product_id);
    if (!stock) throw Error('ออเดอร์นี้หมดเวลาจองและไม่มีสต็อกว่าง ให้เติมสต็อกหรือติดต่อผู้ซื้อเพื่อคืนเงิน');
    stockId = stock.id;
   }
   this.run('INSERT INTO payment_references(reference,order_id,recorded) VALUES(?,?,?)', reference, id, this.now());
   this.run("UPDATE orders SET status='approved',admin_id=?,stock_id=?,reason=NULL WHERE id=?", admin, stockId, id);
   this.run("UPDATE stock SET status='sold' WHERE id=?", stockId);
  });
 }
 reviewOrders() {
  return this.all(`SELECT id FROM orders WHERE status IN ${reviewSql} ORDER BY queued,id`);
 }
 ahead(order) {
  return this.get(`SELECT count(*) n FROM orders WHERE status IN ${reviewSql} AND (queued<? OR (queued=? AND id<?))`,
   order.queued, order.queued, order.id).n;
 }
 pendingNotices() {
  return this.all(`SELECT o.id,o.user_id,o.channel_id,
   CASE o.status WHEN 'expired' THEN 'expired' ELSE 'reminder' END kind
   FROM orders o
   WHERE o.channel_id IS NOT NULL AND o.method IS NOT NULL
   AND ((o.status='pending' AND o.expires>? AND o.expires<=?) OR (o.status='expired' AND o.expires>=?))
   AND NOT EXISTS (SELECT 1 FROM payment_notices n WHERE n.order_id=o.id AND
    n.kind=CASE o.status WHEN 'expired' THEN 'expired' ELSE 'reminder' END)
   ORDER BY o.expires LIMIT 20`, this.now(), this.now()+120000, this.now()-86400000);
 }
 settings() {
  const row = this.get('SELECT value FROM shop_settings WHERE id=1');
  return row ? JSON.parse(row.value) : null;
 }
 saveSettings(expected, settings) {
  return this.tx(() => {
   const current = this.settings();
   if (JSON.stringify(current) !== JSON.stringify(expected)) {
    throw Error('การตั้งค่าเปลี่ยนแล้ว กรุณาเปิด /settings ใหม่');
   }
   if (current?.guild && current.guild !== settings.guild) {
    throw Error('ฐานข้อมูลร้านนี้ผูกกับเซิร์ฟเวอร์อื่นแล้ว');
   }
   this.run('INSERT INTO shop_settings(id,value) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value', JSON.stringify(settings));
  });
 }
 hasOpenOrders() {
  return Boolean(this.get("SELECT id FROM orders WHERE status IN ('pending','review','info','late_review','late_info','approved','sending') LIMIT 1"));
 }
 close(){this.db.close()}
}
