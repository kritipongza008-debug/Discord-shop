import {ChannelType} from 'discord.js';

export function createOrderRoomGuard() {
 const active = new Set();
 return {
  isBusy(id) { return active.has(id); },
  async run(id,task) {
   if (active.has(id)) throw Error('กำลังจัดการห้องออเดอร์นี้ ลองใหม่จากออเดอร์ของฉัน');
   active.add(id);
   try { return await task(); }
   finally { active.delete(id); }
  }
 };
}

export async function removeExpiredOrderRoom(store,id,guildId,fetchRoom) {
 const order = store.order(id);
 if (order?.status !== 'expired' || !order.channel_id || order.proof) return false;
 try {
  const room = await fetchRoom(order.channel_id);
  if (room) {
   if (room.guildId !== guildId || room.type !== ChannelType.GuildText || room.name !== `order-${id}`) {
    throw Error('ตรวจสอบไม่ได้ว่าเป็นห้องออเดอร์ที่บอทสร้าง');
   }
   await room.delete(`หมดเวลาจองออเดอร์ #${id}`);
  }
 } catch (error) {
  if (error.code !== 10003) throw error;
 }
 store.run("UPDATE orders SET channel_id=NULL,message_id=NULL WHERE id=? AND channel_id=? AND status='expired'",
  id,order.channel_id);
 return true;
}
