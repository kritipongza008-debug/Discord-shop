import {ChannelType} from 'discord.js';
import {finishedOrderStatuses} from './store.js';

export function createOrderRoomGuard() {
 const active = new Set();
 return {
  isBusy(id) { return active.has(id); },
  async run(id,task) {
   if (active.has(id)) throw Error('กำลังจัดการห้องออเดอร์นี้ ลองใหม่จากออเดอร์ของฉัน');
   active.add(id);
   try { return await task(); }
   finally { active.delete(id); }
  }
 };
}

export async function removeFinishedOrderRoom(store,id,guildId,fetchRoom,manual) {
 const order = store.order(id);
 if (manual) {
  if (!order?.channel_id || order.channel_id!==manual.channel_id || order.status!==manual.status) return false;
  const unstarted = order.status==='pending' && !order.method && !order.proof;
  if (!unstarted && !finishedOrderStatuses.includes(order.status)) return false;
 } else if (!store.roomCanClose(order)) {
  return false;
 }

 let room;
 try {
  room = await fetchRoom(order.channel_id);
 } catch (error) {
  if (error.code !== 10003) throw error;
 }
 if (room && (room.guildId!==guildId || room.type!==ChannelType.GuildText || room.name!==`order-${id}`)) {
  throw Error('ตรวจสอบไม่ได้ว่าเป็นห้องออเดอร์ที่บอทสร้าง');
 }

 const current = store.order(id);
 if (current?.channel_id!==order.channel_id || current.status!==order.status) return false;
 let status = current.status;
 if (manual && status==='pending') {
  if (!store.cancelUnstartedOrder(id,order.channel_id,manual.adminId)) return false;
  status = 'cancelled';
 }
 try {
  if (room) await room.delete(`ปิดห้องออเดอร์ #${id}`);
 } catch (error) {
  if (error.code !== 10003) throw error;
 }
 store.run("UPDATE orders SET channel_id=NULL,message_id=NULL WHERE id=? AND channel_id=? AND status=?",
  id,order.channel_id,status);
 return true;
}
