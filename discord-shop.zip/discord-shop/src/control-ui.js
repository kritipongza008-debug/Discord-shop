import {
 ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType, EmbedBuilder,
 FileUploadBuilder, LabelBuilder, ModalBuilder, StringSelectMenuBuilder, TextInputBuilder, TextInputStyle
} from 'discord.js';
import {activeSalePrice} from './store.js';

const prefix = 'shop-admin:';
const color = 0xc32d36;
const row = (...components) => new ActionRowBuilder().addComponents(...components);
const button = (action,label,style=ButtonStyle.Secondary) =>
 new ButtonBuilder().setCustomId(prefix+action).setLabel(label).setStyle(style);

export function adminEntry() {
 return {
  embeds:[new EmbedBuilder().setColor(color).setTitle('🛠️ แผงจัดการร้าน')
   .setDescription('**สำหรับแอดมิน** · เพิ่มสินค้า เติมสต็อก และเช็กคิวจากปุ่มด้านล่าง')],
  components:[row(button('home','เปิดแผงจัดการ',ButtonStyle.Primary))]
 };
}

export function adminHome(reviewCount) {
 return {
  embeds:[new EmbedBuilder().setColor(color).setTitle('🛠️ จัดการร้าน ZBINGZING RACING')
   .setDescription(`**รอตรวจยอด ${reviewCount} ออเดอร์**\nเลือกสิ่งที่ต้องการทำจากปุ่มด้านล่าง`)],
  components:[
   row(button('add','เพิ่มสินค้า',ButtonStyle.Primary),button('pick:edit:0','แก้สินค้า'),button('stock','ดูสต็อก'),button('sales','ยอดขายวันนี้')),
   row(button('pick:stock:0','เติมสต็อก'),button('pick:import:0','เติมจากไฟล์'),button('queue','ดูคิวตรวจยอด',ButtonStyle.Success)),
   row(button('publish','ลงหน้าร้าน'),button('settings','ตั้งค่าร้าน'),button('alerts','ตั้งเตือนสต็อก')),
   row(button('refunds','ดูรายการคืนเงิน'),button('messages','ข้อความลูกค้า'),button('pick:sale:0','ตั้งโปรลดราคา'),button('cleanup','เคลียร์ห้องออเดอร์'))
  ]
 };
}

export function productPicker(products, action, pageIndex) {
 const labels = {edit:'แก้สินค้า',stock:'เติมสต็อก',import:'เติมสต็อกจากไฟล์',sale:'ตั้งโปรลดราคา'};
 if (!Object.hasOwn(labels,action)) throw Error('เลือกเมนูจากแผงจัดการร้าน');
 const pageCount = Math.max(1,Math.ceil(products.length/25));
 const page = Math.max(0,Math.min(pageIndex,pageCount-1));
 const options = products.slice(page*25,(page+1)*25);
 const components = [];
 if (options.length) {
  components.push(row(new StringSelectMenuBuilder().setCustomId(prefix+'selected:'+action)
   .setPlaceholder('แตะเลือกสินค้า')
   .addOptions(options.map(product=>({label:product.name,value:String(product.id),description:`สินค้า #${product.id}` })))));
 }
 if (pageCount>1) {
  components.push(row(button(`pick:${action}:${page-1}`,'ก่อนหน้า').setDisabled(page===0),
   button(`pick:${action}:${page+1}`,'ถัดไป').setDisabled(page===pageCount-1)));
 }
 components.push(row(button('home','กลับแผงจัดการ')));
 return {content:options.length?`**${labels[action]}** · หน้า ${page+1}/${pageCount}`:'**ยังไม่มีสินค้า** กดเพิ่มสินค้าจากแผงจัดการก่อน',components};
}

function input(label,id,maxLength,value='',style=TextInputStyle.Short,required=true) {
 const field = new TextInputBuilder().setCustomId(id).setStyle(style).setRequired(required).setMaxLength(maxLength);
 if (value) field.setValue(value);
 return new LabelBuilder().setLabel(label).setTextInputComponent(field);
}

export function productForm(product) {
 const upload = new FileUploadBuilder().setCustomId('image').setRequired(false).setMinValues(0).setMaxValues(1);
 const modal = new ModalBuilder().setCustomId(prefix+`save:${product?.id ?? 'new'}`)
  .setTitle(product?`แก้สินค้า #${product.id}`:'เพิ่มสินค้าใหม่')
  .addLabelComponents(
   input('ชื่อสินค้า','name',80,product?.name),
   input('ราคาเป็นบาท เช่น 99 หรือ 99.50','price',12,product ? (product.price/100).toFixed(2) : ''),
   input('คำอธิบายสินค้า','description',500,product?.description,TextInputStyle.Paragraph,false),
   new LabelBuilder().setLabel('รูปสินค้า (เลือกได้)').setDescription('แนบรูปจากมือถือได้เลย บอทย่อให้เอง')
    .setFileUploadComponent(upload)
  );
 if (product) {
  modal.addLabelComponents(new LabelBuilder().setLabel('เปิดขายหรือพักขาย').setStringSelectMenuComponent(
   new StringSelectMenuBuilder().setCustomId('active').setRequired(true).setMinValues(1).setMaxValues(1)
    .addOptions(
     {label:'เปิดขาย',value:'yes',default:Boolean(product.active)},
     {label:'พักขาย',value:'no',default:!product.active}
    )
  ));
 }
 return modal;
}

const thaiOffset = 7*60*60*1000;

export function parseSaleEnd(value) {
 const match = /^(\d{2})\/(\d{2})\/(\d{4}) (\d{2}):(\d{2})$/.exec(value);
 if (!match) throw Error('ใส่เวลาจบโปรเป็น วัน/เดือน/ปี ค.ศ. ชั่วโมง:นาที เช่น 30/11/2026 20:00');
 const [,day,month,year,hour,minute] = match;
 const local = `${year}-${month}-${day}T${hour}:${minute}:00.000Z`;
 const time = Date.parse(local);
 if (!Number.isFinite(time) || new Date(time).toISOString()!==local) throw Error('วันที่หรือเวลาจบโปรไม่ถูกต้อง');
 return time-thaiOffset;
}

export function saleForm(product,now=Date.now()) {
 const price = (product.price/100).toFixed(2);
 const sale = activeSalePrice(product,now);
 const current = sale===null ? '' : (sale/100).toFixed(2);
 let deadline = '';
 if (sale!==null && product.sale_ends_at!=null) {
  const [year,month,day,hour,minute] = new Date(product.sale_ends_at+thaiOffset).toISOString().slice(0,16).split(/[-T:]/);
  deadline = `${day}/${month}/${year} ${hour}:${minute}`;
 }
 return new ModalBuilder().setCustomId(prefix+`sale-save:${product.id}`).setTitle(`ตั้งโปรสินค้า #${product.id}`)
  .addLabelComponents(
   input(`ราคาปกติ ${price} บาท · เว้นว่างเพื่อปิดโปร`,'sale',12,current,TextInputStyle.Short,false),
   input('เวลาจบโปร (เวลาไทย)','ends',16,deadline,TextInputStyle.Short,false)
    .setDescription('เช่น 30/11/2026 20:00 · ใช้ปี ค.ศ. · เว้นว่างเพื่อเปิดโปรต่อเนื่อง')
  );
}

export function stockLinesForm(productId) {
 return new ModalBuilder().setCustomId(prefix+`lines:${productId}`).setTitle('เติมสต็อกทีละบรรทัด')
  .addLabelComponents(new LabelBuilder().setLabel('หนึ่งบรรทัดต่อหนึ่งชิ้น').setDescription('ใส่ชิ้นแรก แล้วกด Enter เพื่อขึ้นบรรทัดใหม่')
   .setTextInputComponent(new TextInputBuilder().setCustomId('lines').setStyle(TextInputStyle.Paragraph)
    .setPlaceholder('โค้ดชิ้นแรก\nโค้ดชิ้นถัดไป').setRequired(true).setMaxLength(3500)));
}

export function importForm(productId) {
 return new ModalBuilder().setCustomId(prefix+`import:${productId}`).setTitle('เติมสต็อกจากไฟล์')
  .addLabelComponents(new LabelBuilder().setLabel('เลือกไฟล์ .txt').setDescription('หนึ่งบรรทัดต่อหนึ่งชิ้น สูงสุด 500 บรรทัด')
   .setFileUploadComponent(new FileUploadBuilder().setCustomId('file').setRequired(true).setMinValues(1).setMaxValues(1)));
}

export function publishPicker() {
 return {content:'**ลงหน้าร้าน**\nแตะเลือกห้องที่ลูกค้าจะเข้ามาซื้อสินค้า',
  components:[row(new ChannelSelectMenuBuilder().setCustomId(prefix+'publish-room')
   .addChannelTypes(ChannelType.GuildText).setPlaceholder('เลือกห้องหน้าร้าน'))]};
}

export function parseBaht(text) {
 const value = text.trim();
 if (!/^\d{1,7}(?:\.\d{1,2})?$/.test(value)) throw Error('ใส่ราคาเป็นบาท เช่น 99 หรือ 99.50');
 const [whole, fraction=''] = value.split('.');
 const price = Number(whole)*100 + Number(fraction.padEnd(2,'0'));
 if (price < 1 || price > 100000000) throw Error('ราคาเริ่มที่ 0.01 บาท และไม่เกิน 1,000,000 บาท');
 return price;
}
