import {
 ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType, EmbedBuilder,
 FileUploadBuilder, LabelBuilder, ModalBuilder, StringSelectMenuBuilder, TextInputBuilder, TextInputStyle
} from 'discord.js';
import {activeSalePrice} from './store.js';

const prefix = 'shop-admin:';
const color = 0xc32d36;
const row = (...components) => new ActionRowBuilder().addComponents(...components);
const button = (action,label,style=ButtonStyle.Secondary) =>
 new ButtonBuilder().setCustomId(prefix+action).setLabel(label).setStyle(style);

export function adminEntry() {
 return {
  embeds:[new EmbedBuilder().setColor(color).setTitle('🛠️ แผงจัดการร้าน')
   .setDescription('**สำหรับแอดมิน** · เพิ่มสินค้า เติมสต็อก และเช็กคิวจากปุ่มด้านล่าง')],
  components:[row(button('home','เปิดแผงจัดการ',ButtonStyle.Primary))]
 };
}

export function adminHome(reviewCount, paused=false) {
 return {
  embeds:[new EmbedBuilder().setColor(color).setTitle('🛠️ จัดการร้าน ZBINGZING RACING')
   .setDescription(`**รอตรวจยอด ${reviewCount} ออเดอร์**\nร้าน${paused ? 'พักรับออเดอร์' : 'เปิดรับออเดอร์'}`)],
  components:[
   row(button('add','เพิ่มสินค้า',ButtonStyle.Primary),button('inventory','สินค้าและสต็อก'),button('queue','ตรวจยอด',ButtonStyle.Success)),
   row(button('orders-tools','จัดการออเดอร์'),button('sales','ยอดขายวันนี้'),button('extras','ตั้งค่าหน้าร้าน')),
   row(paused ? button('resume','เปิดรับออเดอร์',ButtonStyle.Success) : button('pause','พักรับออเดอร์',ButtonStyle.Danger))
  ]
 };
}

export function productPicker(products, action, pageIndex) {
 const labels = {edit:'แก้สินค้า',stock:'เติมสต็อก',import:'เติมสต็อกจากไฟล์',sale:'ตั้งโปรลดราคา',remove:'เลือกสินค้าที่จะลบสต็อก'};
 if (!Object.hasOwn(labels,action)) throw Error('เลือกเมนูจากแผงจัดการร้าน');
 const pageCount = Math.max(1,Math.ceil(products.length/25));
 const page = Math.max(0,Math.min(pageIndex,pageCount-1));
 const options = products.slice(page*25,(page+1)*25);
 const components = [];
 if (options.length) {
  components.push(row(new StringSelectMenuBuilder().setCustomId(prefix+'selected:'+action)
   .setPlaceholder('แตะเลือกสินค้า')
   .addOptions(options.map(product=>({label:product.name,value:String(product.id),description:`สินค้า #${product.id}` })))));
 }
 if (pageCount>1) {
  components.push(row(button(`pick-page:${action}:${page-1}`,'ก่อนหน้า').setDisabled(page===0),
   button(`pick-page:${action}:${page+1}`,'ถัดไป').setDisabled(page===pageCount-1)));
 }
 components.push(row(button('home','กลับแผงจัดการ')));
 return {content:options.length?`**${labels[action]}** · หน้า ${page+1}/${pageCount}`:'**ยังไม่มีสินค้า** กดเพิ่มสินค้าจากแผงจัดการก่อน',components};
}

function input(label,id,maxLength,value='',style=TextInputStyle.Short,required=true) {
 const field = new TextInputBuilder().setCustomId(id).setStyle(style).setRequired(required).setMaxLength(maxLength);
 if (value) field.setValue(value);
 return new LabelBuilder().setLabel(label).setTextInputComponent(field);
}

export function productForm(product) {
 const upload = new FileUploadBuilder().setCustomId('image').setRequired(false).setMinValues(0).setMaxValues(1);
 const modal = new ModalBuilder().setCustomId(prefix+`save:${product?.id ?? 'new'}`)
  .setTitle(product?`แก้สินค้า #${product.id}`:'เพิ่มสินค้าใหม่')
  .addLabelComponents(
   input('ชื่อสินค้า','name',80,product?.name),
   input('ราคาเป็นบาท เช่น 99 หรือ 99.50','price',12,product ? (product.price/100).toFixed(2) : ''),
   input('คำอธิบายสินค้า','description',500,product?.description,TextInputStyle.Paragraph,false),
   new LabelBuilder().setLabel('รูปสินค้า (เลือกได้)').setDescription('แนบรูปจากมือถือได้เลย บอทย่อให้เอง')
    .setFileUploadComponent(upload)
  );
 if (product) {
  modal.addLabelComponents(new LabelBuilder().setLabel('เปิดขายหรือพักขาย').setStringSelectMenuComponent(
   new StringSelectMenuBuilder().setCustomId('active').setRequired(true).setMinValues(1).setMaxValues(1)
    .addOptions(
     {label:'เปิดขาย',value:'yes',default:Boolean(product.active)},
     {label:'พักขาย',value:'no',default:!product.active}
    )
  ));
 }
 return modal;
}

const thaiOffset = 7*60*60*1000;

export function parseSaleEnd(value) {
 const match = /^(\d{2})\/(\d{2})\/(\d{4}) (\d{2}):(\d{2})$/.exec(value);
 if (!match) throw Error('ใส่เวลาจบโปรเป็น วัน/เดือน/ปี ค.ศ. ชั่วโมง:นาที เช่น 30/11/2026 20:00');
 const [,day,month,year,hour,minute] = match;
 const local = `${year}-${month}-${day}T${hour}:${minute}:00.000Z`;
 const time = Date.parse(local);
 if (!Number.isFinite(time) || new Date(time).toISOString()!==local) throw Error('วันที่หรือเวลาจบโปรไม่ถูกต้อง');
 return time-thaiOffset;
}

export function saleForm(product,now=Date.now()) {
 const price = (product.price/100).toFixed(2);
 const sale = activeSalePrice(product,now);
 const current = sale===null ? '' : (sale/100).toFixed(2);
 let deadline = '';
 if (sale!==null && product.sale_ends_at!=null) {
  const [year,month,day,hour,minute] = new Date(product.sale_ends_at+thaiOffset).toISOString().slice(0,16).split(/[-T:]/);
  deadline = `${day}/${month}/${year} ${hour}:${minute}`;
 }
 return new ModalBuilder().setCustomId(prefix+`sale-save:${product.id}`).setTitle(`ตั้งโปรสินค้า #${product.id}`)
  .addLabelComponents(
   input(`ราคาปกติ ${price} บาท · เว้นว่างเพื่อปิดโปร`,'sale',12,current,TextInputStyle.Short,false),
   input('เวลาจบโปร (เวลาไทย)','ends',16,deadline,TextInputStyle.Short,false)
    .setDescription('เช่น 30/11/2026 20:00 · ใช้ปี ค.ศ. · เว้นว่างเพื่อเปิดโปรต่อเนื่อง')
  );
}

export function stockLinesForm(productId) {
 return new ModalBuilder().setCustomId(prefix+`lines:${productId}`).setTitle('เติมสต็อกทีละบรรทัด')
  .addLabelComponents(new LabelBuilder().setLabel('หนึ่งบรรทัดต่อหนึ่งชิ้น').setDescription('ใส่ชิ้นแรก แล้วกด Enter เพื่อขึ้นบรรทัดใหม่')
   .setTextInputComponent(new TextInputBuilder().setCustomId('lines').setStyle(TextInputStyle.Paragraph)
    .setPlaceholder('โค้ดชิ้นแรก\nโค้ดชิ้นถัดไป').setRequired(true).setMaxLength(3500)));
}

export function importForm(productId) {
 return new ModalBuilder().setCustomId(prefix+`import:${productId}`).setTitle('เติมสต็อกจากไฟล์')
  .addLabelComponents(new LabelBuilder().setLabel('เลือกไฟล์ .txt').setDescription('หนึ่งบรรทัดต่อหนึ่งชิ้น สูงสุด 500 บรรทัด')
   .setFileUploadComponent(new FileUploadBuilder().setCustomId('file').setRequired(true).setMinValues(1).setMaxValues(1)));
}

export function publishPicker() {
 return {content:'**ลงหน้าร้าน**\nแตะเลือกห้องที่ลูกค้าจะเข้ามาซื้อสินค้า',
  components:[row(new ChannelSelectMenuBuilder().setCustomId(prefix+'publish-room')
   .addChannelTypes(ChannelType.GuildText).setPlaceholder('เลือกห้องหน้าร้าน'))]};
}

export function parseBaht(text) {
 const value = text.trim();
 if (!/^\d{1,7}(?:\.\d{1,2})?$/.test(value)) throw Error('ใส่ราคาเป็นบาท เช่น 99 หรือ 99.50');
 const [whole, fraction=''] = value.split('.');
 const price = Number(whole)*100 + Number(fraction.padEnd(2,'0'));
 if (price < 1 || price > 100000000) throw Error('ราคาเริ่มที่ 0.01 บาท และไม่เกิน 1,000,000 บาท');
 return price;
}

export const appearanceFields = {
 copy: [['title','ชื่อร้าน',80],['subtitle','ข้อความใต้ชื่อร้าน',180],['guide','วิธีซื้อบนหน้าร้าน',300],
  ['checkout','ข้อความหน้ารายละเอียดสินค้า',300],['footer','ข้อความท้ายบิล',120]],
 labels: [['view','ปุ่มดูสินค้า',40],['buy','ปุ่มสั่งซื้อ',40],['search','ปุ่มค้นหาสินค้า',40],
  ['orders','ปุ่มออเดอร์ของฉัน',40],['help','ปุ่มวิธีซื้อ',40]],
 navigation: [['next','ปุ่มหน้าถัดไป',40],['previous','ปุ่มหน้าก่อนหน้า',40],['back','ปุ่มกลับรายการสินค้า',40],['coupon','ปุ่มใช้คูปอง',40]],
 categories: [['all','ปุ่มสินค้าทั้งหมด',40],['sale','ปุ่มโปรวันนี้',40],['ready','ปุ่มพร้อมส่ง',40]],
 style: [['color','สี Hex เช่น C32D36',7],['minutes','เวลาชำระเงิน 1–120 นาที',3]]
};

export function appearanceForm(group,appearance) {
 return new ModalBuilder().setCustomId(prefix+'appearance-save:'+group).setTitle('ตั้งค่าหน้าร้าน')
  .addLabelComponents(...appearanceFields[group].map(([id,label,max])=>input(label,id,max,
   id==='color' && appearance.color!=null ? appearance.color.toString(16).padStart(6,'0') : String(appearance[id]??''),
   max>120 ? TextInputStyle.Paragraph : TextInputStyle.Short,false)));
}

export function bannerForm() {
 return new ModalBuilder().setCustomId(prefix+'banner-save').setTitle('อัปโหลดแบนเนอร์')
  .addLabelComponents(new LabelBuilder().setLabel('เลือกรูปแบนเนอร์')
   .setFileUploadComponent(new FileUploadBuilder().setCustomId('file').setRequired(true).setMinValues(1).setMaxValues(1)));
}

const couponDigits = value => value.normalize('NFKC').replace(/[๐-๙]/g,digit=>String(digit.charCodeAt(0)-0x0e50));

export function parseCouponFields(fields) {
 const code = fields.code.normalize('NFKC').trim().toUpperCase();
 if (!/^[A-Z0-9_-]{2,20}$/.test(code)) throw Error('ช่องรหัสคูปอง: ใช้ A–Z ตัวเลข ขีด หรือขีดล่าง 2–20 ตัว');

 let discount;
 try {
  discount = parseBaht(couponDigits(fields.discount).replace(/\s*บาท$/,'').replace(',','.'));
 } catch (error) {
  throw Error('ช่องส่วนลด: '+error.message);
 }

 const uses = couponDigits(fields.uses).trim();
 if (!/^\d{1,6}$/.test(uses) || Number(uses)<1) throw Error('ช่องจำนวนสิทธิ์: ใส่จำนวนเต็มตั้งแต่ 1 ถึง 999999');
 const product = couponDigits(fields.product).trim();
 if (product && !/^#?[1-9]\d{0,5}$/.test(product)) throw Error('ช่องรหัสสินค้า: ใส่เลขสินค้า เช่น #12 หรือเว้นว่างเพื่อใช้กับทุกสินค้า');

 const end = couponDigits(fields.ends).trim().replace(/\s+/g,' ');
 let expires = null;
 if (end) {
  const local = /^(\d{1,2})\/(\d{1,2})\/(\d{4}) (\d{1,2})[:.](\d{2})$/.exec(end);
  const iso = /^(\d{4})-(\d{1,2})-(\d{1,2})[ T](\d{1,2})[:.](\d{2})$/.exec(end);
  if (!local && !iso) throw Error('ช่องหมดอายุ: ใส่วัน/เดือน/ปี และเวลา เช่น 8/11/2569 9:30');
  const [,day,month,year,hour,minute] = local ?? [null,iso[3],iso[2],iso[1],iso[4],iso[5]];
  const yearNumber = Number(year);
  const gregorian = yearNumber>=2400 ? yearNumber-543 : yearNumber;
  const pad = value => value.padStart(2,'0');
  try {
   expires = parseSaleEnd(`${pad(day)}/${pad(month)}/${String(gregorian).padStart(4,'0')} ${pad(hour)}:${minute}`);
  } catch {
   throw Error('ช่องหมดอายุ: วันที่หรือเวลาไม่ถูกต้อง ตรวจวันในเดือนและใช้เวลา 00:00–23:59');
  }
 }
 return {code,discount,maxUses:Number(uses),productId:product ? Number(product.replace(/^#/,'')) : null,expires};
}

export function couponForm() {
 return new ModalBuilder().setCustomId(prefix+'coupon-save').setTitle('สร้างคูปอง')
  .addLabelComponents(input('โค้ด A–Z ตัวเลข ขีด หรือขีดล่าง','code',20),
   input('ส่วนลดเป็นบาท','discount',12),input('จำนวนสิทธิ์ทั้งหมด','uses',6),
   input('รหัสสินค้า (ว่าง = ใช้ได้ทุกสินค้า)','product',7,'',TextInputStyle.Short,false),
   input('หมดอายุ (เวลาไทย พ.ศ. หรือ ค.ศ.)','ends',30,'',TextInputStyle.Short,false)
    .setDescription('เช่น 8/11/2569 9:30 · เว้นว่างได้'));
}

export function stockRemovalPicker(product,{items,total,page,pages}) {
 const components = [];
 if (items.length) {
  components.push(row(new StringSelectMenuBuilder().setCustomId(prefix+'stock-remove-select:'+product.id)
   .setPlaceholder('ติ๊กเลือกชิ้นที่จะลบ').setMinValues(1).setMaxValues(items.length)
   .addOptions(items.map(item=>{
    const code = [...item.content.replace(/\s+/g,' ').trim()];
    const suffix = code.length>4 ? code.slice(-4).join('') : '';
    return {label:'ชิ้น #'+item.id,value:String(item.id),description:suffix ? 'ท้ายโค้ด •••• '+suffix : 'ปิดบังโค้ดสั้น'};
   }))));
 }
 if (pages>1) components.push(row(
  button('stock-remove-page:'+product.id+':'+(page-1),'ก่อนหน้า').setDisabled(page===0),
  button('stock-remove-page:'+product.id+':'+(page+1),'ถัดไป').setDisabled(page===pages-1)
 ));
 const actions = [button('pick:remove:0','เลือกสินค้าอื่น'),button('inventory','กลับสินค้าและสต็อก')];
 if (total) actions.unshift(button('stock-remove-all:'+product.id,'ลบสต็อกว่างทั้งหมด',ButtonStyle.Danger));
 components.push(row(...actions));
 return {
  content:`**ลบสต็อกสินค้า #${product.id}** · ว่าง ${total} ชิ้น · หน้า ${page+1}/${pages}\n${total?'เลือกชิ้นที่ต้องการ แล้วตรวจรายการก่อนยืนยัน':'ไม่มีสต็อกว่างให้ลบ'}`,
  components
 };
}
