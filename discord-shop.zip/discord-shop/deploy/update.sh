#!/usr/bin/env bash
set -euo pipefail

app_dir=/opt/discord-shop
runtime="$app_dir/runtime/bin"
source_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
if [[ $EUID -ne 0 ]]; then
  echo 'Run with sudo bash deploy/update.sh'
  exit 1
fi
if [[ ! -x "$runtime/node" || ! -f "$app_dir/.env" || "$source_dir" == "$app_dir" ]]; then
  echo 'Run this from the new extracted ZIP. For a first install use deploy/install.sh.'
  exit 1
fi

stage=$(mktemp -d "$app_dir/.update.XXXXXX")
stopped=false
was_active=false
systemctl is-active --quiet discord-shop.service && was_active=true
cleanup() {
  local result=$?
  trap - EXIT
  if [[ $result -ne 0 && $stopped == true ]]; then
    echo 'Update failed. Restoring previous code and dependencies.' >&2
    for item in src node_modules package.json package-lock.json; do
      if [[ -e "$stage/previous/$item" ]]; then
        if [[ -e "$app_dir/$item" ]]; then mv -- "$app_dir/$item" "$stage/failed/"; fi
        mv -- "$stage/previous/$item" "$app_dir/"
      fi
    done
    if [[ $was_active == true ]]; then systemctl start discord-shop.service || true; fi
  fi
  rm -rf -- "$stage"
  exit "$result"
}
trap cleanup EXIT

mkdir "$stage/previous" "$stage/failed"
cp -R -- "$source_dir/src" "$source_dir/package.json" "$source_dir/package-lock.json" "$stage/"
(
  cd "$stage"
  PATH="$runtime:$PATH" npm ci --omit=dev --include=optional --ignore-scripts
  "$runtime/node" --input-type=module -e 'await import("sharp")'
)

systemctl stop discord-shop.service
stopped=true
systemctl start discord-shop-backup.service
for item in src node_modules package.json package-lock.json; do
  mv -- "$app_dir/$item" "$stage/previous/"
  mv -- "$stage/$item" "$app_dir/"
done
systemctl start discord-shop.service
echo 'Updated. Use /shop in Discord to refresh the storefront.'
