#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Run with sudo bash deploy/install.sh'; exit 1; fi
source_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
if [[ -e /opt/discord-shop ]]; then echo '/opt/discord-shop exists. Stop: do not overwrite existing data. See upgrade guide.'; exit 1; fi
for tool in curl tar xz sha256sum useradd runuser systemctl; do command -v "$tool" >/dev/null || { echo "Missing $tool; install prerequisites first"; exit 1; }; done
case $(uname -m) in x86_64) node_arch=x64;; aarch64|arm64) node_arch=arm64;; *) echo 'Requires x64 or ARM64'; exit 1;; esac
task_tmp=$(mktemp -d)
trap 'rm -rf -- "$task_tmp"' EXIT
curl --fail --silent --show-error --location --proto '=https' https://nodejs.org/dist/latest-v24.x/SHASUMS256.txt -o "$task_tmp/SHASUMS256.txt"
node_file=$(awk -v arch="$node_arch" '$2 ~ ("^node-v24\\.[0-9]+\\.[0-9]+-linux-" arch "\\.tar\\.xz$") {print $2}' "$task_tmp/SHASUMS256.txt")
[[ "$node_file" =~ ^node-v24\.[0-9]+\.[0-9]+-linux-(x64|arm64)\.tar\.xz$ ]] || { echo 'Cannot identify official Node 24 archive'; exit 1; }
curl --fail --silent --show-error --location --proto '=https' "https://nodejs.org/dist/latest-v24.x/$node_file" -o "$task_tmp/$node_file"
(cd "$task_tmp" && awk -v file="$node_file" '$2==file' SHASUMS256.txt | sha256sum --check --strict -)
id discordshop >/dev/null 2>&1 || useradd --system --home-dir /opt/discord-shop --shell /usr/sbin/nologin discordshop
install -d -m 755 /opt/discord-shop
cp -a "$source_dir/src" "$source_dir/package.json" "$source_dir/package-lock.json" /opt/discord-shop/
install -d -m 755 /opt/discord-shop/runtime
tar -xJf "$task_tmp/$node_file" --strip-components=1 -C /opt/discord-shop/runtime
install -d -m 700 -o discordshop -g discordshop /opt/discord-shop/data /opt/discord-shop/backups
install -m 600 -o discordshop -g discordshop "$source_dir/.env.example" /opt/discord-shop/.env
(cd /opt/discord-shop && PATH="/opt/discord-shop/runtime/bin:$PATH" npm ci --omit=dev --include=optional --ignore-scripts)
chown -R root:root /opt/discord-shop/src /opt/discord-shop/node_modules /opt/discord-shop/runtime
install -m 644 "$source_dir/deploy/discord-shop.service" "$source_dir/deploy/discord-shop-backup.service" "$source_dir/deploy/discord-shop-backup.timer" /etc/systemd/system/
systemctl daemon-reload
echo 'Installed. Set DISCORD_TOKEN in /opt/discord-shop/.env, start the bot, then use /settings in Discord.'
