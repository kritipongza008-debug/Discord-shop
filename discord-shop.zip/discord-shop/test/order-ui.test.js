import assert from 'node:assert/strict';
import {test} from 'node:test';
import {orderCard,checkoutCard,slipModal} from '../src/order-ui.js';

test('expired buyer sees the slip recovery action and the modal requires exactly one image', () => {
 const order = {id:7,status:'expired',method:'promptpay',name:'Wave',price:9900,proof:'https://example.com/secret'};
 const card = orderCard(order).toJSON();
 assert.match(card.description,/ออเดอร์ของฉัน.*สลิปย้อนหลัง/);
 assert.ok(!JSON.stringify(card).includes(order.proof));
 const form = slipModal(order.id).toJSON();
 assert.equal(form.custom_id,'slip:7');
 assert.equal(slipModal(order.id,true).toJSON().custom_id,'late-slip:7');
 assert.equal(form.components[0].component.custom_id,'proof');
 assert.equal(form.components[0].component.required,true);
 assert.equal(form.components[0].component.max_values,1);
});

test('checkout card keeps payment details in the order room only while payment is pending',async()=>{
 const order = {id:7,status:'pending',method:'promptpay',name:'Wave',price:9950,expires:100000};
 const settings = {payee:'ร้านทดสอบ',pp:'0812345678',wallet:'0899999999'};
 const promptpay = await checkoutCard(order,settings);
 const card = promptpay.embeds[0].toJSON();
 assert.equal(card.image.url,'attachment://qr-7.png');
 assert.equal(promptpay.files[0].name,'qr-7.png');
 assert.match(JSON.stringify(card),/99.50 บาท/);
 assert.match(JSON.stringify(card),/ร้านทดสอบ/);
 const wallet = await checkoutCard({...order,method:'truemoney'},settings);
 assert.deepEqual(wallet.files,[]);
 assert.match(JSON.stringify(wallet.embeds[0].toJSON()),/0899999999/);
 const review = await checkoutCard({...order,status:'review'},settings);
 assert.deepEqual(review.files,[]);
 assert.equal(review.embeds[0].toJSON().image,undefined);
});
