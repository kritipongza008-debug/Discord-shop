import assert from 'node:assert/strict';
import {test} from 'node:test';
import {orderCard,slipModal} from '../src/order-ui.js';

test('expired buyer sees the slip recovery action and the modal requires exactly one image', () => {
 const order = {id:7,status:'expired',method:'promptpay',name:'Wave',price:9900,proof:'https://example.com/secret'};
 const card = orderCard(order).toJSON();
 assert.match(card.description,/ออเดอร์ของฉัน.*สลิปย้อนหลัง/);
 assert.ok(!JSON.stringify(card).includes(order.proof));
 const form = slipModal(order.id).toJSON();
 assert.equal(form.custom_id,'slip:7');
 assert.equal(slipModal(order.id,true).toJSON().custom_id,'late-slip:7');
 assert.equal(form.components[0].component.custom_id,'proof');
 assert.equal(form.components[0].component.required,true);
 assert.equal(form.components[0].component.max_values,1);
});
