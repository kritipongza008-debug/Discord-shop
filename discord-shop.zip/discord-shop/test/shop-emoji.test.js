import {test} from 'node:test';
import assert from 'node:assert/strict';
import {appearanceForm} from '../src/control-ui.js';
import {parseShopEmoji,shopEmoji} from '../src/shop-emoji.js';

test('emoji settings accept standard and Discord emoji, reject other text, and allow resetting to the default',()=>{
 for (const emoji of ['🔥','🏷','👩🏽‍💻','🇹🇭','<:stock:123456789012345678>','<a:stock:123456789012345678>']) {
  assert.equal(parseShopEmoji(' '+emoji+' '),emoji);
 }
 for (const invalid of ['🔥🔥','fire','<@123456789012345678>','<:stock:123>','1']) {
  assert.throws(()=>parseShopEmoji(invalid),/ใส่อีโมจิ/);
 }
 assert.equal(shopEmoji({lowEmoji:parseShopEmoji(' ')},'lowEmoji'),'🟠');
 const form=appearanceForm('emojis',{lowEmoji:'🔥'}).toJSON();
 assert.equal(form.components.length,5);
 assert.equal(form.components[1].component.value,'🔥');
 assert.equal(form.components[1].component.required,false);
});
