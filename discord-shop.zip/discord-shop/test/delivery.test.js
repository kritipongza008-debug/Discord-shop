import assert from 'node:assert/strict';
import {test} from 'node:test';
import {productDelivery,receiptDelivery,isProductDelivery} from '../src/delivery.js';

test('HTTPS stock sends a clickable message and reconciliation checks the author and exact link',()=>{
 const url = 'https://example.com/redeem?id=1&key=a%20b';
 const payload = productDelivery(8,url);
 assert.equal(payload.content,`**สินค้า · ออเดอร์ #8**\n<${url}>`);
 assert.equal(payload.files,undefined);
 assert.equal(productDelivery(8,url+'\nวิธีใช้').content,payload.content+'\nวิธีใช้');
 const message = {...payload,author:{id:'bot'},attachments:[]};
 assert.equal(isProductDelivery(message,8,url,'bot'),true);
 assert.equal(isProductDelivery(message,9,url,'bot'),false);
 assert.equal(isProductDelivery(message,8,url+'c','bot'),false);
 assert.equal(isProductDelivery(message,8,url,'different bot'),false);
});

test('non-link stock and oversized links keep their exact content as a file',()=>{
 for (const stock of ['Code: ABC\nPassword: 123','https://', 'http://example.com','https://example.com/'+ 'a'.repeat(2000)]) {
  const payload = productDelivery(8,stock);
  assert.equal(payload.files[0].name,'order-8.txt');
  assert.equal(payload.files[0].attachment.toString('utf8'),stock);
 }
 assert.equal(isProductDelivery({author:{id:'bot'},attachments:[{name:'order-8.txt'}]},8,'https://example.com','bot'),true);
});

test('the bill accompanies either a link or an attachment and preserves delivery verification',()=>{
 const order = {id:8,product_name:'Wave *Red*',name:'Renamed',price:7950,method:'truemoney',
  paid_at:Date.parse('2026-11-07T11:15:00Z')};
 const url = 'https://example.com/redeem?key=1';
 const payload = receiptDelivery(order,url);
 const bill = payload.embeds[0].toJSON();
 assert.match(bill.title,/#8/);
 const fields = Object.fromEntries(bill.fields.map(field=>[field.name,field.value]));
 assert.equal(fields['รายการสินค้า'],'Wave \\*Red\\*');
 assert.equal(fields['จำนวน'],'1 ชิ้น');
 assert.equal(fields['ยอดชำระแล้ว'],'**79.50 บาท**');
 assert.equal(fields['วิธีชำระ'],'TrueMoney');
 assert.match(fields['ยืนยันยอด (เวลาไทย)'],/18:15/);
 assert.match(payload.content,/<https:\/\/example.com\/redeem\?key=1>/);
 assert.equal(isProductDelivery({...payload,author:{id:'bot'},attachments:[]},8,url,'bot'),true);
 assert.equal(receiptDelivery(order,'secret').files[0].name,'order-8.txt');
});
