import assert from 'node:assert/strict';
import {test} from 'node:test';
import {Collection,ChannelType,OverwriteType,PermissionFlagsBits as P,PermissionsBitField} from 'discord.js';
import {productDelivery,receiptDelivery,isProductDelivery,isPrivateDeliveryRoom,sendOrderCopies} from '../src/delivery.js';

test('HTTPS stock sends a clickable message and reconciliation checks the author and exact link',()=>{
 const url = 'https://example.com/redeem?id=1&key=a%20b';
 const payload = productDelivery(8,url);
 assert.equal(payload.content,`**สินค้า · ออเดอร์ #8**\n<${url}>`);
 assert.equal(payload.files,undefined);
 assert.equal(productDelivery(8,url+'\nวิธีใช้').content,payload.content+'\nวิธีใช้');
 const message = {...payload,author:{id:'bot'},attachments:[]};
 assert.equal(isProductDelivery(message,8,url,'bot'),true);
 assert.equal(isProductDelivery(message,9,url,'bot'),false);
 assert.equal(isProductDelivery(message,8,url+'c','bot'),false);
 assert.equal(isProductDelivery(message,8,url,'different bot'),false);
});

test('short stock uses code formatting while long stock keeps its exact content in a file',()=>{
 const heading = '**สินค้า · ออเดอร์ #8**';
 assert.equal(productDelivery(8,'ABC-123').content,heading+'\n`ABC-123`');
 assert.equal(productDelivery(8,'Code: ABC\nPassword: 123').content,heading+'\n```\nCode: ABC\nPassword: 123\n```');
 assert.equal(productDelivery(8,'A`B').content,heading+'\n```\nA`B\n```');
 for (const stock of ['x'.repeat(501), 'A```B', 'https://example.com/'+ 'a'.repeat(2000)]) {
  const payload = productDelivery(8,stock);
  assert.equal(payload.files[0].name,'order-8.txt');
  assert.equal(payload.files[0].attachment.toString('utf8'),stock);
 }
 assert.equal(isProductDelivery({author:{id:'bot'},attachments:[{name:'order-8.txt'}]},8,'secret','bot'),true);
});

test('the bill accompanies a link, inline stock or an attachment and preserves delivery verification',()=>{
 const order = {id:8,product_name:'Wave *Red*',name:'Renamed',price:7950,method:'truemoney',
  paid_at:Date.parse('2026-11-07T11:15:00Z')};
 const url = 'https://example.com/redeem?key=1';
 const payload = receiptDelivery(order,url);
 const bill = payload.embeds[0].toJSON();
 assert.match(bill.title,/#8/);
 const fields = Object.fromEntries(bill.fields.map(field=>[field.name,field.value]));
 assert.equal(fields['รายการสินค้า'],'Wave \\*Red\\*');
 assert.equal(fields['จำนวน'],'1 ชิ้น');
 assert.equal(fields['ยอดชำระแล้ว'],'**79.50 บาท**');
 assert.equal(fields['วิธีชำระ'],'TrueMoney');
 assert.match(fields['ยืนยันยอด (เวลาไทย)'],/18:15/);
 assert.match(payload.content,/<https:\/\/example.com\/redeem\?key=1>/);
 assert.equal(isProductDelivery({...payload,author:{id:'bot'},attachments:[]},8,url,'bot'),true);
 assert.match(receiptDelivery(order,'secret').content,/`secret`/);
 assert.equal(receiptDelivery(order,'x'.repeat(501)).files[0].name,'order-8.txt');
});


test('stock is posted only to the private room assigned to the order',()=>{
 const entry=(id,type,allow=0n,deny=0n)=>({id,type,allow:new PermissionsBitField(allow),deny:new PermissionsBitField(deny)});
 const cache=new Collection([
  ['guild',entry('guild',OverwriteType.Role,0n,P.ViewChannel)],
  ['buyer',entry('buyer',OverwriteType.Member,P.ViewChannel)],
  ['bot',entry('bot',OverwriteType.Member,P.ViewChannel)],
  ['admin',entry('admin',OverwriteType.Role,P.ViewChannel)]
 ]);
 const room={id:'room',guildId:'guild',name:'order-8',type:ChannelType.GuildText,permissionOverwrites:{cache}};
 const order={id:8,channel_id:'room',user_id:'buyer'};
 const check=channel=>isPrivateDeliveryRoom(channel,order,'guild','admin','bot');
 assert.equal(check(room),true);
 assert.equal(check({...room,id:'other'}),false);
 cache.set('outsider',entry('outsider',OverwriteType.Role,P.ViewChannel));
 assert.equal(check(room),false);
 cache.delete('outsider');
 cache.delete('guild');
 assert.equal(check(room),false);
});

test('delivery tries both destinations and one successful copy is enough to finish',async()=>{
 const errors=[];
 const report=error=>errors.push(error.message);
 const failed=async()=>{throw Error('network');};
 assert.deepEqual(await sendOrderCopies(()=> 'dm',()=> 'room',report),{dm:'dm',room:'room'});
 assert.deepEqual(await sendOrderCopies(()=>null,()=> 'room',report),{dm:null,room:'room'});
 assert.deepEqual(await sendOrderCopies(failed,()=> 'room',report),{dm:null,room:'room'});
 assert.deepEqual(await sendOrderCopies(()=> 'dm',failed,report),{dm:'dm',room:null});
 await assert.rejects(sendOrderCopies(failed,()=>null,report),/network/);
 assert.deepEqual(errors,['network','network','network']);
});
