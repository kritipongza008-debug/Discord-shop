import {test} from 'node:test';
import assert from 'node:assert/strict';
import {appearancePreview} from '../src/appearance-preview.js';

test('appearance drafts preview banner, navigation and receipt without changing saved values',()=>{
 const appearance = {title:'ชื่อเดิม',bannerMode:'none'};
 const store = {appearance:()=>appearance,now:()=>0,shopBanner:()=>null};
 const banner = Buffer.from('example banner');
 const draft = {token:'draft',banner,patch:{
  title:'ชื่อใหม่',bannerMode:'custom',buy:'เลือกซื้อ',footer:'ข้อความท้ายบิลใหม่',sale:'ช่วงลดราคา',color:0x123456,minutes:12
 }};
 const shop = appearancePreview(store,draft,'shop',20);
 const [controls,...sample] = shop.components;
 const intro = controls.toJSON();
 assert.match(JSON.stringify(intro),/12 นาที/);
 assert.match(JSON.stringify(intro),/preview-apply:draft/);
 assert.match(JSON.stringify(sample),/ชื่อใหม่/);
 assert.equal(shop.files[0].attachment.compare(banner),0);
 assert.equal(sample[0].accent_color,0x123456);
 for (const row of sample[0].components.filter(part=>part.type===1)) {
  assert.ok(row.components.every(part=>part.disabled));
 }
 assert.match(JSON.stringify(appearancePreview(store,draft,'product',20).components),/เลือกซื้อ/);
 assert.match(JSON.stringify(appearancePreview(store,draft,'categories',20).components),/ช่วงลดราคา/);
 assert.match(JSON.stringify(appearancePreview(store,draft,'bill',20).components),/ข้อความท้ายบิลใหม่/);
 assert.equal(appearancePreview(store,null,'shop',20).files.length,0);
 assert.equal(appearance.title,'ชื่อเดิม');
});
