import assert from 'node:assert/strict';
import {test} from 'node:test';
import {PermissionFlagsBits} from 'discord.js';
import {canConfigure, handleSettings, settingsPanel, shopReady} from '../src/settings.js';
import {Store} from '../src/store.js';

const guild = '100000000000000001';
const role = '100000000000000002';
const review = '100000000000000003';
const category = '100000000000000004';
const member = (roles = [], manage = false) => ({
 guildId: guild,
 member: {roles},
 memberPermissions: {has: (permission) => manage && permission === PermissionFlagsBits.ManageGuild}
});

test('any member can open first setup but only a server manager can bind the first role', () => {
 assert.equal(canConfigure(member(), null), true);
 assert.equal(canConfigure(member(), null, true), false);
 assert.equal(canConfigure(member([], true), null, true), true);
});

test('after binding, settings requires the exact shop role even on previously opened menus', async () => {
 const settings = {guild, role};
 assert.equal(canConfigure(member([role]), settings, true), true);
 assert.equal(canConfigure(member([], true), settings), false);
 assert.equal(canConfigure({...member([role]), guildId: 'other'}, settings), false);
 await assert.rejects(handleSettings({
  ...member([], true), customId: 'shop-settings:role', isChatInputCommand: () => false
 }, {settings: () => settings}), /เฉพาะยศ/);
});

test('role selection persists settings and blocks a stale first-save attempt', async () => {
 const store = new Store(':memory:');
 try {
  let panel;
  let registered = false;
  await handleSettings({
   ...member([role], true),
   customId: 'shop-settings:role',
   isChatInputCommand: () => false,
   isRoleSelectMenu: () => true,
   roles: new Map([[role, {id: role}]]),
   values: [role],
   update: async (payload) => { panel = payload; }
  }, store, () => {}, async () => { registered = true; });
  assert.deepEqual(store.settings(), {guild, role});
  assert.equal(registered, true);
  assert.equal(panel.components[0].toJSON().components[0].default_values[0].id, role);
  assert.throws(() => store.saveSettings(null, {guild, role: review}), /เปลี่ยนแล้ว/);
 } finally {
  store.close();
 }
});

test('configured settings uses native pickers and shop remains closed until payment fields are set', () => {
 const settings = {guild, role, admin: review, category};
 assert.deepEqual(settingsPanel(settings).components.map((row) => row.toJSON().components[0].type), [6, 8, 8, 2]);
 assert.equal(shopReady(settings), false);
 assert.equal(shopReady({...settings, pp: '0812345678', wallet: '0812345678', payee: 'ร้าน'}), true);
});
