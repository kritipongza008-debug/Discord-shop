import assert from 'node:assert/strict';
import {test} from 'node:test';
import {setTimeout as sleep} from 'node:timers/promises';
import {MessageFlags,MessageFlagsBitField} from 'discord.js';
import {ephemeralCleanup} from '../src/ephemeral-cleanup.js';

const privateMessage = id=>({id,flags:new MessageFlagsBitField(MessageFlags.Ephemeral)});
const publicMessage = id=>({id,flags:new MessageFlagsBitField()});
function mockInteraction(deleted, name, message) {
 return {
  message,
  reply:async options=>({resource:{message:privateMessage('private')},options}),
  editReply:async()=>message,
  followUp:async()=>privateMessage('follow-up'),
  update:async()=>{},
  deferUpdate:async()=>{},
  deleteReply:async target=>deleted.push([name,target])
 };
}

test('private replies and follow-ups expire while public messages stay',async()=>{
 const watch = ephemeralCleanup(assert.fail,10);
 const deleted = [];
 const original = mockInteraction(deleted,'original',publicMessage('public'));
 watch(original);
 await original.reply({flags:MessageFlags.Ephemeral});
 await original.editReply('public test');
 await original.update('public update');
 await original.followUp({});
 await sleep(30);
 assert.deepEqual(deleted,[['original','@original'],['original','follow-up']]);
});

test('updating the same private message replaces its previous deletion timer',async()=>{
 const watch = ephemeralCleanup(assert.fail,10);
 const deleted = [];
 const original = mockInteraction(deleted,'original');
 const next = mockInteraction(deleted,'new',privateMessage('private'));
 watch(original);
 watch(next);
 await original.reply({flags:MessageFlags.Ephemeral});
 await next.deferUpdate();
 await next.editReply('refreshed');
 await sleep(30);
 assert.deepEqual(deleted,[['new','@original']]);
});
