import {test} from 'node:test';
import assert from 'node:assert/strict';
import {syncReviewMessage} from '../src/review-message.js';

test('review message replaces a deleted card and reports its replacement ID',async()=>{
 const sent = [];
 const room = {
  messages:{edit:async()=>{throw {code:10008};}},
  send:async payload=>{sent.push(payload);return {id:'new'};}
 };
 assert.equal(await syncReviewMessage(room,'old',{embeds:[]},20),'new');
 assert.deepEqual(sent,[{embeds:[],nonce:'rold',enforceNonce:true}]);
 room.messages.edit=async()=>{throw {code:50013};};
 await assert.rejects(syncReviewMessage(room,'old',{embeds:[]},20),{code:50013});
 assert.equal(sent.length,1);
 room.messages.edit=async()=>{};
 assert.equal(await syncReviewMessage(room,'new',{embeds:[]},20),'new');
 room.messages.edit=async()=>assert.fail('unchanged cards should not be edited');
 room.messages.fetch=async options=>{
  assert.deepEqual(options,{message:'new',force:true,cache:false});
 };
 assert.equal(await syncReviewMessage(room,'new',{embeds:[]},20,true),'new');
});
