import test from 'node:test';
import assert from 'node:assert/strict';
import {evaluateSlip,verifyUploadedSlip} from '../src/slip-verification.js';

const stamp='2026-11-09T12:03:30+07:00';
const time=Date.parse(stamp);
const order={method:'promptpay',price:9900,created:time-60000,expires:time+60000};
const config={pp:'0812345678',wallet:'0891234567',slipKey:'test'};
const bank={success:true,data:{isDuplicate:false,isAmountMatched:true,rawSlip:{
 date:stamp,transRef:'REF1234',amount:{amount:99},receiver:{account:{proxy:{type:'MSISDN',account:'081-234-5678'}}}
}}};
const wallet={success:true,data:{isDuplicate:false,isAmountMatched:true,matchedAccount:{bankNumber:'0891234567'},rawSlip:{
 date:stamp,transactionId:'TR1234',amount:99,receiver:{phone:'08x-xxx-4567'}
}}};

test('auto verification requires exact receiver, matching amount, order time and unused reference',()=>{
 const check=(response,parameters=order)=>evaluateSlip(response,parameters,config,time);
 assert.equal(check(bank).reference,'REF1234');
 assert.equal(check(bank,{...order,price:10000}).reference,undefined);
 assert.equal(check(bank,{...order,created:time+1}).reference,undefined);
 assert.equal(check({...bank,data:{...bank.data,isDuplicate:true}}).reference,undefined);
 assert.match(check(wallet,{...order,method:'truemoney'}).note,/บางส่วน/);
 const full=structuredClone(wallet);
 full.data.rawSlip.receiver.phone=config.wallet;
 assert.equal(check(full,{...order,method:'truemoney'}).reference,'TR1234');
 const ambiguous=structuredClone(bank);
 ambiguous.data.rawSlip.receiver.account.proxy.account='081-xxx-5678';
 ambiguous.data.matchedAccount={bankNumber:config.pp};
 assert.equal(check(ambiguous).reference,undefined);
});

test('uploads a Wallet slip to the Wallet endpoint and handles exhausted quota',async()=>{
 const calls=[];
 const result=await verifyUploadedSlip({size:5,url:'https://cdn.discordapp.com/attachments/test.png',contentType:'image/png'},
  {...order,method:'truemoney'},config,async(url,options)=>{
   calls.push(String(url));
   if (calls.length===1) return new Response('image');
   assert.equal(options.body.get('matchAmount'),'99');
   assert.equal(options.body.get('checkDuplicate'),'true');
   assert.equal(options.headers.Authorization,'Bearer test');
   return Response.json({error:{code:'QUOTA_EXCEEDED'}},{status:403});
  });
 assert.deepEqual(calls,['https://cdn.discordapp.com/attachments/test.png','https://api.easyslip.com/v2/verify/truewallet']);
 assert.match(result.note,/โควตา/);
});
