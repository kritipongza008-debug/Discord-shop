import assert from 'node:assert/strict';
import {test} from 'node:test';
import {adminHome, productForm, productPicker, saleForm, parseSaleEnd, parseCouponFields, couponForm, stockRemovalPicker, parseBaht, stockLinesForm} from '../src/control-ui.js';

test('admin buttons open a product form with photo upload and safe baht conversion',()=>{
 const home = adminHome(2);
 assert.ok(home.components.flatMap(row=>row.toJSON().components).some(button=>button.custom_id==='shop-admin:add'));
 const form = productForm({id:7,name:'โค้ด',price:9950,description:'',active:1}).toJSON();
 assert.equal(form.custom_id,'shop-admin:save:7');
 assert.equal(form.components.find(label=>label.component.custom_id==='price').component.value,'99.50');
 assert.equal(form.components.find(label=>label.component.custom_id==='image').component.type,19);
 assert.equal(form.components.find(label=>label.component.custom_id==='active').component.options[0].default,true);
 assert.equal(parseBaht('99.50'),9950);
 assert.equal(parseBaht('0.01'),1);
 assert.throws(()=>parseBaht('1.005'));
 assert.throws(()=>parseBaht('0'));
});

test('admin can select a product past the first 25 without typing an id',()=>{
 const products = Array.from({length:26},(_,index)=>({id:index+1,name:`สินค้า ${index+1}`}));
 const picker = productPicker(products,'import',1);
 assert.equal(picker.components[0].toJSON().components[0].options[0].value,'26');
 assert.equal(picker.components[1].toJSON().components[1].disabled,true);
});

test('stock entry supports one item per line for the product selected from the picker',()=>{
 const form = stockLinesForm(26).toJSON();
 assert.equal(form.custom_id,'shop-admin:lines:26');
 assert.equal(form.components[0].component.style,2);
 assert.match(form.components[0].component.placeholder,/โค้ดชิ้นแรก\nโค้ดชิ้นถัดไป/);
});

test('sale form lets admins replace or clear the current promotional price',()=>{
 const home = adminHome(0);
 assert.ok(home.components.flatMap(row=>row.toJSON().components).some(button=>button.custom_id==='shop-admin:inventory'));
 const form = saleForm({id:5,price:9900,sale_price:7900}).toJSON();
 assert.equal(form.custom_id,'shop-admin:sale-save:5');
 assert.equal(form.components[0].component.value,'79.00');
 assert.equal(form.components[0].component.required,false);
});

test('promotion deadline is entered and shown in Thai time with strict calendar validation',()=>{
 const deadline = parseSaleEnd('30/11/2026 20:00');
 assert.equal(new Date(deadline).toISOString(),'2026-11-30T13:00:00.000Z');
 assert.throws(()=>parseSaleEnd('31/11/2026 20:00'),/ไม่ถูกต้อง/);
 assert.throws(()=>parseSaleEnd('30/11/2026 24:00'),/ไม่ถูกต้อง/);
 assert.throws(()=>parseSaleEnd('2026-11-30 20:00'),/วัน\/เดือน/);
 const product = {id:5,price:9900,sale_price:7900,sale_ends_at:deadline};
 const current = saleForm(product,deadline-1).toJSON().components;
 assert.equal(current[1].component.value,'30/11/2026 20:00');
 assert.equal(current[1].component.required,false);
 const expired = saleForm(product,deadline).toJSON().components;
 assert.equal(expired[0].component.value,undefined);
 assert.equal(expired[1].component.value,undefined);
});

test('coupon forms accept mobile Thai dates and report the offending field',()=>{
 const fields = {code:'sale',discount:'๑๐,๕๐ บาท',uses:'๒',product:'#12',ends:'๘/๑๑/๒๕๖๙  ๙:๓๐'};
 const expected = Date.parse('2026-11-08T02:30:00.000Z');
 assert.deepEqual(parseCouponFields(fields),{code:'SALE',discount:1050,maxUses:2,productId:12,expires:expected});
 for (const ends of ['08/11/2026 09:30','2026-11-08T09:30','8/11/2569 9.30']) {
  assert.equal(parseCouponFields({...fields,ends}).expires,expected);
 }
 assert.equal(parseCouponFields({...fields,ends:'',product:''}).expires,null);
 assert.throws(()=>parseCouponFields({...fields,ends:'31/11/2569 9:30'}),/ช่องหมดอายุ/);
 assert.throws(()=>parseCouponFields({...fields,uses:'0'}),/ช่องจำนวนสิทธิ์/);
 assert.throws(()=>parseCouponFields({...fields,discount:'10%'}),/ช่องส่วนลด/);
 assert.equal(couponForm().toJSON().components.length,5);
});

test('stock removal picker provides multiselect, preview and page controls',()=>{
 const data={items:[{id:4,content:'CODE-1234'},{id:9,content:'ABCD'}],total:22,page:1,pages:2};
 const payload=stockRemovalPicker({id:7},data);
 const components=payload.components.map(row=>row.toJSON().components);
 assert.equal(components[0][0].max_values,2);
 assert.deepEqual(components[0][0].options.map(option=>option.value),['4','9']);
 assert.deepEqual(components[0][0].options.map(option=>option.description),['ท้ายโค้ด •••• 1234','ปิดบังโค้ดสั้น']);
 assert.equal(components[1][1].disabled,true);
 assert.equal(components[2][0].custom_id,'shop-admin:stock-remove-all:7');
});
