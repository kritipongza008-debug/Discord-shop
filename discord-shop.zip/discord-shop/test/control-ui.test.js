import assert from 'node:assert/strict';
import {test} from 'node:test';
import {adminHome, productForm, productPicker, parseBaht, stockLinesForm} from '../src/control-ui.js';

test('admin buttons open a product form with photo upload and safe baht conversion',()=>{
 const home = adminHome(2);
 assert.ok(home.components.flatMap(row=>row.toJSON().components).some(button=>button.custom_id==='shop-admin:add'));
 const form = productForm({id:7,name:'โค้ด',price:9950,description:'',active:1}).toJSON();
 assert.equal(form.custom_id,'shop-admin:save:7');
 assert.equal(form.components.find(label=>label.component.custom_id==='price').component.value,'99.50');
 assert.equal(form.components.find(label=>label.component.custom_id==='image').component.type,19);
 assert.equal(form.components.find(label=>label.component.custom_id==='active').component.options[0].default,true);
 assert.equal(parseBaht('99.50'),9950);
 assert.equal(parseBaht('0.01'),1);
 assert.throws(()=>parseBaht('1.005'));
 assert.throws(()=>parseBaht('0'));
});

test('admin can select a product past the first 25 without typing an id',()=>{
 const products = Array.from({length:26},(_,index)=>({id:index+1,name:`สินค้า ${index+1}`}));
 const picker = productPicker(products,'import',1);
 assert.equal(picker.components[0].toJSON().components[0].options[0].value,'26');
 assert.equal(picker.components[1].toJSON().components[1].disabled,true);
});

test('stock entry supports one item per line for the product selected from the picker',()=>{
 const form = stockLinesForm(26).toJSON();
 assert.equal(form.custom_id,'shop-admin:lines:26');
 assert.equal(form.components[0].component.style,2);
 assert.match(form.components[0].component.placeholder,/โค้ดชิ้นแรก\nโค้ดชิ้นถัดไป/);
});
