import assert from 'node:assert/strict';
import {randomBytes} from 'node:crypto';
import {test} from 'node:test';
import sharp from 'sharp';
import {compressProductImage,downloadProductImage} from '../src/product-image.js';

test('a product photo larger than the old 2 MB cap becomes a smaller WebP',async()=>{
 const original = await sharp(randomBytes(1700*1350*3),{raw:{width:1700,height:1350,channels:3}}).png().toBuffer();
 assert.ok(original.byteLength > 2*1024*1024);
 const result = await compressProductImage(original);
 const info = await sharp(result.bytes).metadata();
 assert.equal(result.extension,'webp');
 assert.equal(info.format,'webp');
 assert.ok(info.width <= 1200 && info.height <= 1200);
 assert.ok(result.bytes.length < original.length / 5);
});

test('image upload still rejects oversized inputs and non-Discord URLs',async()=>{
 await assert.rejects(downloadProductImage({size:21*1024*1024}),/20 MB/);
 await assert.rejects(downloadProductImage({size:100,url:'https://example.com/photo.png'}),/Discord/);
 await assert.rejects(compressProductImage(Buffer.from('not an image')));
});
