import assert from 'node:assert/strict';
import {test} from 'node:test';
import {parseStockFile} from '../src/stock-import.js';

test('stock file supports UTF-8 BOM and mobile line endings without importing empty lines', () => {
 assert.deepEqual(parseStockFile(Buffer.from('\uFEFFABC\r\n\r\n โค้ดไทย \rDEF\n')), ['ABC','โค้ดไทย','DEF']);
 assert.throws(() => parseStockFile(Buffer.from([0xff,0xfe])), /UTF-8/);
 assert.throws(() => parseStockFile(Buffer.from('A\n'.repeat(501))), /1–500/);
});
