import test from 'node:test';import assert from 'node:assert/strict';import {mkdtempSync,rmSync} from 'node:fs';import {tmpdir} from 'node:os';import {join} from 'node:path';import {Store} from '../src/store.js';import {spawn} from 'node:child_process';
function fixture(t){const d=mkdtempSync(join(tmpdir(),'shop-'));let now=100000;const path=join(d,'db.sqlite'),s=new Store(path,()=>now);t.after(()=>{s.close();rmSync(d,{recursive:true,force:true})});const p=s.addProduct('สินค้า','รายละเอียด',9900);s.addStock(p,'secret-1');return {s,p,path,advance:n=>now+=n}}
test('last stock cannot be reserved twice and empty product fails',t=>{const{s,p}=fixture(t);s.reserve('A',p,'นาย A');assert.throws(()=>s.reserve('B',p,'นาย B'),/หมด/);assert.equal(s.products()[0].remaining,0)});
test('one open order per user',t=>{const{s,p}=fixture(t);s.addStock(p,'secret-2');s.reserve('A',p,'A');assert.throws(()=>s.reserve('A',p,'A'),/ยังไม่เสร็จ/)});
test('expiry releases stock and new buyer can reserve',t=>{const{s,p,advance}=fixture(t);const a=s.reserve('A',p,'A');advance(900001);const b=s.reserve('B',p,'B');assert.equal(s.order(a.id).status,'expired');assert.equal(a.stock_id,b.stock_id)});
test('review keeps reservation after timeout',t=>{const{s,p,advance}=fixture(t);const a=s.reserve('A',p,'A');s.run("UPDATE orders SET method='promptpay' WHERE id=?",a.id);s.submit(a.id,'A','proof');advance(9999999);s.tx(()=>s.expire());assert.equal(s.order(a.id).status,'review');assert.equal(s.products()[0].remaining,0)});
test('ownership and chosen payment method required',t=>{const{s,p}=fixture(t);const a=s.reserve('A',p,'A');assert.throws(()=>s.submit(a.id,'B','proof'));assert.throws(()=>s.submit(a.id,'A','proof'),/เลือกวิธี/)});
test('queue updates after approval and rejection; no duplicate approval',t=>{const{s,p}=fixture(t);s.addStock(p,'secret-2');s.addStock(p,'secret-3');const os=['A','B','C'].map(u=>s.reserve(u,p,u));for(const o of os){s.run("UPDATE orders SET method='promptpay' WHERE id=?",o.id);s.submit(o.id,o.user_id,'proof')};assert.equal(s.ahead(s.order(os[2].id)),2);s.approve(os[0].id,'admin','REF-A001');assert.equal(s.ahead(s.order(os[2].id)),1);assert.throws(()=>s.approve(os[0].id,'admin','REF-A001'));s.release(os[1].id,'rejected','bad proof','admin');assert.equal(s.ahead(s.order(os[2].id)),0);assert.equal(s.products()[0].remaining,1);assert.throws(()=>s.release(os[0].id,'rejected'))});
test('asking for more proof preserves original queue timestamp',t=>{const{s,p,advance}=fixture(t);const a=s.reserve('A',p,'A');s.run("UPDATE orders SET method='promptpay' WHERE id=?",a.id);s.submit(a.id,'A','proof1');const q=s.order(a.id).queued;s.run("UPDATE orders SET status='info' WHERE id=?",a.id);advance(100);s.submit(a.id,'A','proof2');assert.equal(s.order(a.id).queued,q)});
test('state survives reopen',t=>{const{s,p,path}=fixture(t);const a=s.reserve('A',p,'A');const other=new Store(path);assert.equal(other.order(a.id).stock_id,a.stock_id);other.close()});
test('inactive product and invalid price fail',t=>{const{s,p}=fixture(t);assert.throws(()=>s.addProduct('bad','',0));s.run('UPDATE products SET active=0 WHERE id=?',p);assert.throws(()=>s.reserve('A',p,'A'),/ปิดขาย/)});
test('independent processes race for one stock: only one succeeds',async t=>{const{s,p,path}=fixture(t);const source=`import {Store} from './src/store.js';const s=new Store(process.argv[1]);try{s.reserve(process.argv[2],Number(process.argv[3]),'payer');console.log('won')}catch{console.log('lost')}s.close()`;const run=u=>new Promise((resolve,reject)=>{const cp=spawn(process.execPath,['--input-type=module','-e',source,path,u,String(p)],{cwd:process.cwd()});let out='';cp.stdout.on('data',b=>out+=b);cp.on('error',reject);cp.on('exit',code=>code===0?resolve(out.trim()):reject(Error('worker failed')))});const results=await Promise.all([run('A'),run('B')]);assert.deepEqual(results.sort(),['lost','won']);assert.equal(s.products()[0].remaining,0)});
import {deliverOrder} from '../src/delivery.js';
function approved(t){const f=fixture(t),o=f.s.reserve('A',f.p,'A');f.s.run("UPDATE orders SET method='promptpay' WHERE id=?",o.id);f.s.submit(o.id,'A','proof');f.s.approve(o.id,'admin','REF-A001');return {...f,o}}
test('delivery sends exact reserved stock once',async t=>{const{s,o}=approved(t);let calls=0;await deliverOrder(s,o.id,async(order,content)=>{calls++;assert.equal(content,'secret-1');assert.equal(order.user_id,'A');return 'message-1'});assert.equal(s.order(o.id).status,'delivered');assert.equal(s.order(o.id).delivery_id,'message-1');await assert.rejects(deliverOrder(s,o.id,async()=>calls++));assert.equal(calls,1)});
test('concurrent delivery cannot dispatch twice',async t=>{const{s,o}=approved(t);let release;const gate=new Promise(r=>release=r);let calls=0;const first=deliverOrder(s,o.id,async()=>{calls++;await gate;return 'msg'});await assert.rejects(deliverOrder(s,o.id,async()=>calls++));release();await first;assert.equal(calls,1)});
test('uncertain delivery holds sold stock and blocks automatic retry',async t=>{const{s,o}=approved(t);await assert.rejects(deliverOrder(s,o.id,async()=>{throw Error('timeout')}));assert.equal(s.order(o.id).status,'sending');assert.equal(s.get('SELECT status FROM stock WHERE id=?',o.stock_id).status,'sold');await assert.rejects(deliverOrder(s,o.id,async()=> 'msg'));await deliverOrder(s,o.id,async()=> 'manual-retry',true);assert.equal(s.order(o.id).status,'delivered')});
test('unpaid order cannot dispatch',async t=>{const{s,p}=fixture(t);const o=s.reserve('A',p,'A');let calls=0;await assert.rejects(deliverOrder(s,o.id,async()=>calls++));assert.equal(calls,0)});

test('a stale preview price cannot reserve a stock item', t => {
 const {s, p} = fixture(t);
 const quotedPrice = s.products()[0].price;
 s.run('UPDATE products SET price=? WHERE id=?', quotedPrice + 100, p);
 assert.throws(() => s.reserve('A', p, 'A', 15, quotedPrice), /ราคา.*เปลี่ยน/);
 assert.equal(s.products()[0].remaining, 1);
 assert.equal(s.reserve('A', p, 'A', 15, quotedPrice + 100).price, quotedPrice + 100);
});

function chooseMethod(store, order) {
 store.run("UPDATE orders SET method='promptpay' WHERE id=?", order.id);
}

test('same verified transfer reference cannot approve a second order', t => {
 const {s, p} = fixture(t);
 s.addStock(p, 'secret-2');
 const first = s.reserve('A', p, 'A');
 const second = s.reserve('B', p, 'B');
 for (const order of [first, second]) {
  chooseMethod(s, order);
  s.submit(order.id, order.user_id, 'proof');
 }
 assert.throws(() => s.approve(first.id, 'admin', ''), /กรอกเลขอ้างอิง/);
 s.approve(first.id, 'admin', ' ref-0123 ');
 assert.throws(() => s.approve(second.id, 'admin', 'REF 0123'), /ใช้ยืนยันออเดอร์/);
 assert.equal(s.order(second.id).status, 'review');
 assert.equal(s.get('SELECT status FROM stock WHERE id=?', second.stock_id).status, 'reserved');
});

test('late proof never takes someone else’s stock and can approve after restocking', t => {
 const {s, p, advance} = fixture(t);
 const first = s.reserve('A', p, 'A');
 chooseMethod(s, first);
 advance(900001);
 const second = s.reserve('B', p, 'B');
 assert.equal(first.stock_id, second.stock_id);
 assert.equal(s.submit(first.id, 'A', 'late proof'), 'late_review');
 assert.deepEqual(s.reviewOrders().map(row => row.id), [first.id]);
 s.requestInfo(first.id, 'ขอภาพชัดขึ้น');
 assert.equal(s.order(first.id).status, 'late_info');
 assert.equal(s.submit(first.id, 'A', 'clear proof'), 'late_review');
 assert.throws(() => s.approve(first.id, 'admin', 'REF-1000'), /ไม่มีสต็อกว่าง/);
 assert.equal(s.get('SELECT count(*) n FROM payment_references').n, 0);
 s.addStock(p, 'new stock');
 s.approve(first.id, 'admin', 'REF-1000');
 assert.notEqual(s.order(first.id).stock_id, second.stock_id);
 assert.equal(s.get('SELECT status FROM stock WHERE id=?', second.stock_id).status, 'reserved');
});

test('rejecting a late proof does not release stock reserved by the next buyer', t => {
 const {s, p, advance} = fixture(t);
 const first = s.reserve('A', p, 'A');
 chooseMethod(s, first);
 advance(900001);
 const second = s.reserve('B', p, 'B');
 s.submit(first.id, 'A', 'late proof');
 s.release(first.id, 'rejected');
 assert.equal(s.get('SELECT status FROM stock WHERE id=?', second.stock_id).status, 'reserved');
});

test('payment reminders are scheduled once before the room is eligible for deletion', t => {
 const {s, p, advance} = fixture(t);
 const order = s.reserve('A', p, 'A');
 chooseMethod(s, order);
 s.run("UPDATE orders SET channel_id='room' WHERE id=?", order.id);
 assert.equal(s.pendingNotices().length, 0);
 advance(800000);
 assert.equal(s.pendingNotices()[0].kind, 'reminder');
 s.run("INSERT INTO payment_notices(order_id,kind) VALUES(?,'reminder')", order.id);
 assert.equal(s.pendingNotices().length, 0);
 advance(100001);
 s.tx(() => s.expire());
 assert.equal(s.pendingNotices().length, 0);
 assert.deepEqual(s.expiredRooms().map(row=>row.id), [order.id]);
 s.submit(order.id, 'A', 'proof');
 assert.equal(s.pendingNotices().length, 0);
});

test('stock confirmation rechecks duplicates that appeared after preview', t => {
 const {s, p} = fixture(t);
 const codes = ['secret-1', 'code-a', 'code-a', 'code-b'];
 assert.deepEqual(s.stockImportPlan(p, codes), {fresh:['code-a','code-b'], skipped:2});
 s.addStock(p, 'code-a');
 assert.deepEqual(s.importStock(p, codes), {added:1, skipped:3});
 assert.equal(s.products()[0].remaining, 3);
});

test('verified refund prevents resale of the payment reference and releases only its own reservation', t => {
 const {s,p} = fixture(t);
 const order = s.reserve('A',p,'');
 chooseMethod(s,order);
 s.submit(order.id,'A','proof');
 s.beginRefund(order.id,'admin','RF-1200');
 assert.equal(s.order(order.id).status,'refund_pending');
 assert.equal(s.products()[0].remaining,1);
 assert.equal(s.hasOpenOrders(),true);

 const other = s.reserve('B',p,'');
 assert.equal(other.stock_id,order.stock_id);
 chooseMethod(s,other);
 s.submit(other.id,'B','proof');
 assert.throws(()=>s.approve(other.id,'admin','RF 1200'),/ใช้ยืนยันออเดอร์/);
 s.completeRefund(order.id,'admin');
 assert.equal(s.order(order.id).status,'refunded');
 assert.equal(s.order(other.id).status,'review');
 assert.throws(()=>s.completeRefund(order.id,'admin'));
});

test('support requests stay scoped to the buyer and do not accept a second pending message',t=>{
 const {s,p} = fixture(t);
 const order = s.reserve('A',p,'');
 assert.throws(()=>s.createSupport(order.id,'B','wrong buyer'));
 const id = s.createSupport(order.id,'A','ต้องการความช่วยเหลือ');
 assert.equal(s.latestSupport(order.id,'B'),undefined);
 assert.throws(()=>s.createSupport(order.id,'A','อีกข้อความ'),/ยังไม่ได้ตอบ/);
 s.answerSupport(id,'admin','ตรวจสอบให้แล้ว');
 assert.equal(s.latestSupport(order.id,'A').answer,'ตรวจสอบให้แล้ว');
 assert.throws(()=>s.answerSupport(id,'admin','แก้คำตอบซ้ำ'));
 assert.ok(s.createSupport(order.id,'A','ถามต่อ')>id);
});

test('stock notification re-arms only after stock rises above the threshold',t=>{
 const {s,p} = fixture(t);
 const unstocked = s.addProduct('New','',200);
 assert.deepEqual(s.lowStock(2).map(row=>row.id),[p]);
 s.run('INSERT INTO stock_alerts(product_id) VALUES(?)',p);
 s.addStock(p,'second');
 s.resetStockAlerts(2);
 assert.equal(s.lowStock(2).length,0);
 s.addStock(p,'third');
 s.resetStockAlerts(2);
 assert.equal(s.lowStock(2).length,0);
 s.reserve('A',p,'');
 assert.deepEqual(s.lowStock(2).map(row=>row.id),[p]);
 assert.equal(s.lowStock(0).length,0);
 assert.ok(!s.lowStock(2).some(row=>row.id===unstocked));
});
