import test from 'node:test';import assert from 'node:assert/strict';import {mkdtempSync,rmSync} from 'node:fs';import {tmpdir} from 'node:os';import {join} from 'node:path';import {Store} from '../src/store.js';import {spawn} from 'node:child_process';
function fixture(t){const d=mkdtempSync(join(tmpdir(),'shop-'));let now=100000;const path=join(d,'db.sqlite'),s=new Store(path,()=>now);t.after(()=>{s.close();rmSync(d,{recursive:true,force:true})});const p=s.addProduct('สินค้า','รายละเอียด',9900);s.addStock(p,'secret-1');return {s,p,path,advance:n=>now+=n}}
test('last stock cannot be reserved twice and empty product fails',t=>{const{s,p}=fixture(t);s.reserve('A',p,'นาย A');assert.throws(()=>s.reserve('B',p,'นาย B'),/หมด/);assert.equal(s.products()[0].remaining,0)});
test('one open order per user',t=>{const{s,p}=fixture(t);s.addStock(p,'secret-2');s.reserve('A',p,'A');assert.throws(()=>s.reserve('A',p,'A'),/ยังไม่เสร็จ/)});
test('expiry releases stock and new buyer can reserve',t=>{const{s,p,advance}=fixture(t);const a=s.reserve('A',p,'A');advance(900001);const b=s.reserve('B',p,'B');assert.equal(s.order(a.id).status,'expired');assert.equal(a.stock_id,b.stock_id)});
test('review keeps reservation after timeout',t=>{const{s,p,advance}=fixture(t);const a=s.reserve('A',p,'A');s.run("UPDATE orders SET method='promptpay' WHERE id=?",a.id);s.submit(a.id,'A','proof');advance(9999999);s.tx(()=>s.expire());assert.equal(s.order(a.id).status,'review');assert.equal(s.products()[0].remaining,0)});
test('ownership and chosen payment method required',t=>{const{s,p}=fixture(t);const a=s.reserve('A',p,'A');assert.throws(()=>s.submit(a.id,'B','proof'));assert.throws(()=>s.submit(a.id,'A','proof'),/เลือกวิธี/)});
test('queue updates after approval and rejection; no duplicate approval',t=>{const{s,p}=fixture(t);s.addStock(p,'secret-2');s.addStock(p,'secret-3');const os=['A','B','C'].map(u=>s.reserve(u,p,u));for(const o of os){s.run("UPDATE orders SET method='promptpay' WHERE id=?",o.id);s.submit(o.id,o.user_id,'proof')};assert.equal(s.ahead(s.order(os[2].id)),2);s.approve(os[0].id,'admin','REF-A001');assert.equal(s.ahead(s.order(os[2].id)),1);assert.throws(()=>s.approve(os[0].id,'admin','REF-A001'));s.release(os[1].id,'rejected','bad proof','admin');assert.equal(s.ahead(s.order(os[2].id)),0);assert.equal(s.products()[0].remaining,1);assert.throws(()=>s.release(os[0].id,'rejected'))});
test('asking for more proof preserves original queue timestamp',t=>{const{s,p,advance}=fixture(t);const a=s.reserve('A',p,'A');s.run("UPDATE orders SET method='promptpay' WHERE id=?",a.id);s.submit(a.id,'A','proof1');const q=s.order(a.id).queued;s.run("UPDATE orders SET status='info' WHERE id=?",a.id);advance(100);s.submit(a.id,'A','proof2');assert.equal(s.order(a.id).queued,q)});
test('state survives reopen',t=>{const{s,p,path}=fixture(t);const a=s.reserve('A',p,'A');const other=new Store(path);assert.equal(other.order(a.id).stock_id,a.stock_id);other.close()});
test('inactive product and invalid price fail',t=>{const{s,p}=fixture(t);assert.throws(()=>s.addProduct('bad','',0));s.run('UPDATE products SET active=0 WHERE id=?',p);assert.throws(()=>s.reserve('A',p,'A'),/ปิดขาย/)});
test('independent processes race for one stock: only one succeeds',async t=>{const{s,p,path}=fixture(t);const source=`import {Store} from './src/store.js';const s=new Store(process.argv[1]);try{s.reserve(process.argv[2],Number(process.argv[3]),'payer');console.log('won')}catch{console.log('lost')}s.close()`;const run=u=>new Promise((resolve,reject)=>{const cp=spawn(process.execPath,['--input-type=module','-e',source,path,u,String(p)],{cwd:process.cwd()});let out='';cp.stdout.on('data',b=>out+=b);cp.on('error',reject);cp.on('exit',code=>code===0?resolve(out.trim()):reject(Error('worker failed')))});const results=await Promise.all([run('A'),run('B')]);assert.deepEqual(results.sort(),['lost','won']);assert.equal(s.products()[0].remaining,0)});
import {deliverOrder,sendPrivateProduct} from '../src/delivery.js';
function approved(t){const f=fixture(t),o=f.s.reserve('A',f.p,'A');f.s.run("UPDATE orders SET method='promptpay' WHERE id=?",o.id);f.s.submit(o.id,'A','proof');f.s.approve(o.id,'admin','REF-A001');return {...f,o}}
test('delivery sends exact reserved stock once',async t=>{const{s,o}=approved(t);let calls=0;await deliverOrder(s,o.id,async(order,content)=>{calls++;assert.equal(content,'secret-1');assert.equal(order.user_id,'A');return 'message-1'});assert.equal(s.order(o.id).status,'delivered');assert.equal(s.order(o.id).delivery_id,'message-1');await assert.rejects(deliverOrder(s,o.id,async()=>calls++));assert.equal(calls,1)});
test('concurrent delivery cannot dispatch twice',async t=>{const{s,o}=approved(t);let release;const gate=new Promise(r=>release=r);let calls=0;const first=deliverOrder(s,o.id,async()=>{calls++;await gate;return 'msg'});await assert.rejects(deliverOrder(s,o.id,async()=>calls++));release();await first;assert.equal(calls,1)});
test('uncertain delivery holds sold stock and blocks automatic retry',async t=>{const{s,o}=approved(t);await assert.rejects(deliverOrder(s,o.id,async()=>{throw Error('timeout')}));assert.equal(s.order(o.id).status,'sending');assert.equal(s.get('SELECT status FROM stock WHERE id=?',o.stock_id).status,'sold');await assert.rejects(deliverOrder(s,o.id,async()=> 'msg'));await deliverOrder(s,o.id,async()=> 'manual-retry',true);assert.equal(s.order(o.id).status,'delivered')});
test('unpaid order cannot dispatch',async t=>{const{s,p}=fixture(t);const o=s.reserve('A',p,'A');let calls=0;await assert.rejects(deliverOrder(s,o.id,async()=>calls++));assert.equal(calls,0)});

test('a stale preview price cannot reserve a stock item', t => {
 const {s, p} = fixture(t);
 const quotedPrice = s.products()[0].price;
 s.run('UPDATE products SET price=? WHERE id=?', quotedPrice + 100, p);
 assert.throws(() => s.reserve('A', p, 'A', 15, quotedPrice), /ราคา.*เปลี่ยน/);
 assert.equal(s.products()[0].remaining, 1);
 assert.equal(s.reserve('A', p, 'A', 15, quotedPrice + 100).price, quotedPrice + 100);
});

function chooseMethod(store, order) {
 store.run("UPDATE orders SET method='promptpay' WHERE id=?", order.id);
}

test('same verified transfer reference cannot approve a second order', t => {
 const {s, p} = fixture(t);
 s.addStock(p, 'secret-2');
 const first = s.reserve('A', p, 'A');
 const second = s.reserve('B', p, 'B');
 for (const order of [first, second]) {
  chooseMethod(s, order);
  s.submit(order.id, order.user_id, 'proof');
 }
 assert.throws(() => s.approve(first.id, 'admin', ''), /กรอกเลขอ้างอิง/);
 s.approve(first.id, 'admin', ' ref-0123 ');
 assert.throws(() => s.approve(second.id, 'admin', 'REF 0123'), /ใช้ยืนยันออเดอร์/);
 assert.equal(s.order(second.id).status, 'review');
 assert.equal(s.get('SELECT status FROM stock WHERE id=?', second.stock_id).status, 'reserved');
});

test('late proof never takes someone else’s stock and can approve after restocking', t => {
 const {s, p, advance} = fixture(t);
 const first = s.reserve('A', p, 'A');
 chooseMethod(s, first);
 advance(900001);
 const second = s.reserve('B', p, 'B');
 assert.equal(first.stock_id, second.stock_id);
 assert.equal(s.submit(first.id, 'A', 'late proof'), 'late_review');
 assert.deepEqual(s.reviewOrders().map(row => row.id), [first.id]);
 s.requestInfo(first.id, 'ขอภาพชัดขึ้น');
 assert.equal(s.order(first.id).status, 'late_info');
 assert.equal(s.submit(first.id, 'A', 'clear proof'), 'late_review');
 assert.throws(() => s.approve(first.id, 'admin', 'REF-1000'), /สินค้าหมด/);
 assert.equal(s.get('SELECT count(*) n FROM payment_references').n, 0);
 s.addStock(p, 'new stock');
 s.approve(first.id, 'admin', 'REF-1000');
 assert.notEqual(s.order(first.id).stock_id, second.stock_id);
 assert.equal(s.get('SELECT status FROM stock WHERE id=?', second.stock_id).status, 'reserved');
});

test('rejecting a late proof does not release stock reserved by the next buyer', t => {
 const {s, p, advance} = fixture(t);
 const first = s.reserve('A', p, 'A');
 chooseMethod(s, first);
 advance(900001);
 const second = s.reserve('B', p, 'B');
 s.submit(first.id, 'A', 'late proof');
 s.release(first.id, 'rejected');
 assert.equal(s.get('SELECT status FROM stock WHERE id=?', second.stock_id).status, 'reserved');
});

test('payment reminders are scheduled once before the room is eligible for deletion', t => {
 const {s, p, advance} = fixture(t);
 const order = s.reserve('A', p, 'A');
 chooseMethod(s, order);
 s.run("UPDATE orders SET channel_id='room' WHERE id=?", order.id);
 assert.equal(s.pendingNotices().length, 0);
 advance(800000);
 assert.equal(s.pendingNotices()[0].kind, 'reminder');
 s.run("INSERT INTO payment_notices(order_id,kind) VALUES(?,'reminder')", order.id);
 assert.equal(s.pendingNotices().length, 0);
 advance(100001);
 s.tx(() => s.expire());
 assert.equal(s.pendingNotices().length, 0);
 assert.deepEqual(s.finishedRooms(), []);
 advance(120000);
 assert.deepEqual(s.finishedRooms().map(row=>row.id), [order.id]);
 s.submit(order.id, 'A', 'proof');
 assert.equal(s.pendingNotices().length, 0);
 assert.deepEqual(s.finishedRooms(), []);
});

test('stock confirmation rechecks duplicates that appeared after preview', t => {
 const {s, p} = fixture(t);
 const codes = ['secret-1', 'code-a', 'code-a', 'code-b'];
 assert.deepEqual(s.stockImportPlan(p, codes), {fresh:['code-a','code-b'], skipped:2});
 s.addStock(p, 'code-a');
 assert.deepEqual(s.importStock(p, codes), {added:1, skipped:3});
 assert.equal(s.products()[0].remaining, 3);
});

test('verified refund prevents resale of the payment reference and releases only its own reservation', t => {
 const {s,p} = fixture(t);
 const order = s.reserve('A',p,'');
 chooseMethod(s,order);
 s.submit(order.id,'A','proof');
 s.beginRefund(order.id,'admin','RF-1200');
 assert.equal(s.order(order.id).status,'refund_pending');
 assert.equal(s.products()[0].remaining,1);
 assert.equal(s.hasOpenOrders(),true);

 const other = s.reserve('B',p,'');
 assert.equal(other.stock_id,order.stock_id);
 chooseMethod(s,other);
 s.submit(other.id,'B','proof');
 assert.throws(()=>s.approve(other.id,'admin','RF 1200'),/ใช้ยืนยันออเดอร์/);
 s.completeRefund(order.id,'admin');
 assert.equal(s.order(order.id).status,'refunded');
 assert.equal(s.order(other.id).status,'review');
 assert.throws(()=>s.completeRefund(order.id,'admin'));
});

test('support requests stay scoped to the buyer and do not accept a second pending message',t=>{
 const {s,p} = fixture(t);
 const order = s.reserve('A',p,'');
 assert.throws(()=>s.createSupport(order.id,'B','wrong buyer'));
 const id = s.createSupport(order.id,'A','ต้องการความช่วยเหลือ');
 assert.equal(s.latestSupport(order.id,'B'),undefined);
 assert.throws(()=>s.createSupport(order.id,'A','อีกข้อความ'),/ยังไม่ได้ตอบ/);
 s.answerSupport(id,'admin','ตรวจสอบให้แล้ว');
 assert.equal(s.latestSupport(order.id,'A').answer,'ตรวจสอบให้แล้ว');
 assert.throws(()=>s.answerSupport(id,'admin','แก้คำตอบซ้ำ'));
 assert.ok(s.createSupport(order.id,'A','ถามต่อ')>id);
});

test('stock notification re-arms only after stock rises above the threshold',t=>{
 const {s,p} = fixture(t);
 const unstocked = s.addProduct('New','',200);
 assert.deepEqual(s.lowStock(2).map(row=>row.id),[p]);
 s.run('INSERT INTO stock_alerts(product_id) VALUES(?)',p);
 s.addStock(p,'second');
 s.resetStockAlerts(2);
 assert.equal(s.lowStock(2).length,0);
 s.addStock(p,'third');
 s.resetStockAlerts(2);
 assert.equal(s.lowStock(2).length,0);
 s.reserve('A',p,'');
 assert.deepEqual(s.lowStock(2).map(row=>row.id),[p]);
 assert.equal(s.lowStock(0).length,0);
 assert.ok(!s.lowStock(2).some(row=>row.id===unstocked));
});

test('blocked DMs leave the paid file available privately and the room closes after two minutes', async t => {
 const {s,o,path,advance} = approved(t);
 s.run("UPDATE orders SET channel_id='room' WHERE id=?",o.id);
 const blocked = Object.assign(Error('Cannot send messages to this user'),{code:50007});
 assert.equal(s.deliveredStock(o.id,'A'),undefined);
 await deliverOrder(s,o.id,()=>sendPrivateProduct(async()=>{throw blocked}));
 assert.equal(s.order(o.id).status,'delivered');
 assert.equal(s.order(o.id).delivery_id,null);
 advance(119999);
 assert.deepEqual(s.finishedRooms(),[]);
 const restarted = new Store(path,()=>s.now());
 t.after(()=>restarted.close());
 advance(1);
 assert.deepEqual(restarted.finishedRooms().map(row=>row.id),[o.id]);
 restarted.run('UPDATE orders SET channel_id=NULL WHERE id=?',o.id);
 assert.equal(restarted.deliveredStock(o.id,'A').content,'secret-1');
 assert.equal(restarted.deliveredStock(o.id,'B'),undefined);
});

test('an uncertain DM leaves the room and file pending', async t => {
 const {s,o,advance} = approved(t);
 s.run("UPDATE orders SET channel_id='room' WHERE id=?",o.id);
 await assert.rejects(deliverOrder(s,o.id,()=>sendPrivateProduct(async()=>{throw Error('timeout')})),/timeout/);
 advance(120000);
 assert.equal(s.order(o.id).status,'sending');
 assert.deepEqual(s.finishedRooms(),[]);
 assert.equal(s.deliveredStock(o.id,'A'),undefined);
});

test('cancelled, rejected and refunded rooms close on their own deadlines', t => {
 const {s,p,advance} = fixture(t);
 const cancelled = s.reserve('A',p,'');
 s.run("UPDATE orders SET channel_id='cancel-room' WHERE id=?",cancelled.id);
 s.release(cancelled.id,'cancelled');
 advance(1000);
 const rejected = s.reserve('B',p,'');
 s.run("UPDATE orders SET channel_id='reject-room' WHERE id=?",rejected.id);
 chooseMethod(s,rejected);
 s.submit(rejected.id,'B','proof');
 s.release(rejected.id,'rejected');
 advance(1000);
 const refunded = s.reserve('C',p,'');
 s.run("UPDATE orders SET channel_id='refund-room' WHERE id=?",refunded.id);
 chooseMethod(s,refunded);
 s.submit(refunded.id,'C','proof');
 s.beginRefund(refunded.id,'admin','RF-1234');
 advance(118000);
 assert.deepEqual(s.finishedRooms().map(row=>row.id),[cancelled.id]);
 advance(1000);
 assert.deepEqual(s.finishedRooms().map(row=>row.id),[cancelled.id,rejected.id]);
 s.completeRefund(refunded.id,'admin');
 advance(120000);
 assert.deepEqual(s.finishedRooms().map(row=>row.id),[cancelled.id,rejected.id,refunded.id]);
 assert.equal(s.deliveredStock(refunded.id,'C'),undefined);
});

test('sales validate and persist, reject stale prices, and preserve existing order totals', t => {
 const {s,p,path} = fixture(t);
 s.addStock(p,'secret-2');
 assert.throws(()=>s.setSalePrice(p,9900),/ราคาโปร/);
 assert.throws(()=>s.setSalePrice(p,0),/ราคาโปร/);
 s.setSalePrice(p,7900);
 assert.throws(()=>s.reserve('A',p,'',15,9900),/ราคา.*เปลี่ยน/);
 const discounted = s.reserve('A',p,'',15,7900);
 const restarted = new Store(path);
 t.after(()=>restarted.close());
 assert.equal(restarted.products()[0].sale_price,7900);
 restarted.setSalePrice(p,null);
 assert.throws(()=>s.reserve('B',p,'',15,7900),/ราคา.*เปลี่ยน/);
 assert.equal(s.reserve('B',p,'',15,9900).price,9900);
 assert.equal(s.order(discounted.id).price,7900);
});

test('timed promotions survive restarts and stop at the deadline before cleanup runs', t => {
 const {s,p,path,advance} = fixture(t);
 s.addStock(p,'secret-2');
 const permanent = s.addProduct('โปรต่อเนื่อง','',6000);
 s.setSalePrice(permanent,5000);
 const endsAt = s.now()+1000;
 assert.throws(()=>s.setSalePrice(p,7900,s.now()),/ยังมาไม่ถึง/);
 s.setSalePrice(p,7900,endsAt);
 advance(999);
 const before = s.reserve('A',p,'',15,7900);
 const restarted = new Store(path,()=>s.now());
 t.after(()=>restarted.close());
 assert.equal(restarted.products().find(product=>product.id===p).sale_ends_at,endsAt);
 advance(1);
 assert.throws(()=>restarted.reserve('B',p,'',15,7900),/ราคา.*เปลี่ยน/);
 assert.equal(restarted.reserve('B',p,'',15,9900).price,9900);
 assert.equal(restarted.order(before.id).price,7900);
 assert.equal(restarted.expireSales(),1);
 assert.equal(restarted.expireSales(),0);
 assert.equal(restarted.products().find(product=>product.id===permanent).sale_price,5000);
});

test('restock follows are persistent, opt-in, cancellable and claimed once when stock is available',t=>{
 const {s,p,path}=fixture(t);
 const reserved = s.reserve('buyer',p,'');
 s.setRestockFollow(p,'A',true);
 s.setRestockFollow(p,'A',true);
 s.setRestockFollow(p,'B',true);
 s.setRestockFollow(p,'B',false);
 const restarted = new Store(path,()=>s.now());
 t.after(()=>restarted.close());
 assert.equal(restarted.followsRestock(p,'A'),true);
 assert.deepEqual(restarted.restockNotices(),[]);
 s.importStock(p,['restocked']);
 assert.throws(()=>s.setRestockFollow(p,'C',true),/พร้อมขาย/);
 assert.deepEqual(restarted.restockNotices().map(notice=>notice.user_id),['A']);
 const newOrder = s.reserve('another buyer',p,'');
 assert.equal(restarted.claimRestockNotice(p,'A'),false);
 s.release(newOrder.id,'cancelled');
 s.release(reserved.id,'cancelled');
 assert.equal(restarted.claimRestockNotice(p,'A'),true);
 assert.equal(s.claimRestockNotice(p,'A'),false);
 assert.equal(s.followsRestock(p,'A'),false);
});

test('bills preserve the ordered name and confirmed sales use the Thai day boundary',t=>{
 const {s,p,advance}=fixture(t);
 const midnight=Date.parse('2026-11-07T17:00:00Z');
 advance(midnight-s.now()-100);
 const prior = s.reserve('A',p,'');
 chooseMethod(s,prior);
 s.submit(prior.id,'A','proof');
 s.approve(prior.id,'admin','REF-PRIOR');
 s.run("UPDATE products SET name='New name' WHERE id=?",p);
 assert.equal(s.order(prior.id).product_name,'สินค้า');
 assert.equal(s.order(prior.id).paid_at,midnight-100);
 advance(100);
 assert.deepEqual({...s.salesToday().received},{orders:0,amount:0});
 s.addStock(p,'next item');
 const current = s.reserve('B',p,'');
 chooseMethod(s,current);
 s.submit(current.id,'B','proof');
 s.beginRefund(current.id,'admin','REF-CURRENT');
 assert.deepEqual({...s.salesToday().received},{orders:1,amount:9900});
 assert.deepEqual({...s.salesToday().refunded},{orders:0,amount:0});
 s.completeRefund(current.id,'admin');
 assert.deepEqual({...s.salesToday().refunded},{orders:1,amount:9900});
});

test('pausing persists, rejects new orders and leaves existing proof and approval available',t=>{
 const {s,p,path}=fixture(t);
 const order = s.reserve('A',p,'');
 chooseMethod(s,order);
 s.setPauseNotice('Back at 19:00','owner');
 const restarted = new Store(path,()=>s.now());
 t.after(()=>restarted.close());
 assert.equal(restarted.pauseNotice(),'Back at 19:00');
 assert.throws(()=>restarted.reserve('B',p,''),/พักรับออเดอร์/);
 restarted.submit(order.id,'A','proof');
 restarted.approve(order.id,'admin','REF-PAUSE');
 restarted.setPauseNotice(null,'owner');
 restarted.importStock(p,['new code'],'admin');
 assert.equal(restarted.reserve('B',p,'').status,'pending');
 assert.deepEqual(restarted.recentActivity().map(row=>row.actor),['admin','owner','admin','owner']);
});

test('order lookup and overdue notices only include matching eligible orders',t=>{
 const {s,p,advance}=fixture(t);
 const buyer = '123456789012345678';
 const order = s.reserve(buyer,p,'');
 chooseMethod(s,order);
 s.submit(order.id,buyer,'proof');
 assert.deepEqual(s.findOrders(buyer),[order.id]);
 assert.deepEqual(s.findOrders('#'+order.id),[order.id]);
 assert.deepEqual(s.findOrders('987654321098765432'),[]);
 advance(15*60*1000-1);
 assert.deepEqual(s.overdueReviewNotices(),[]);
 advance(1);
 assert.deepEqual(s.overdueReviewNotices().map(row=>row.id),[order.id]);
 s.run("INSERT INTO payment_notices VALUES(?,'review_overdue')",order.id);
 assert.deepEqual(s.overdueReviewNotices(),[]);
});
