import assert from 'node:assert/strict';
import {test} from 'node:test';
import {ChannelType} from 'discord.js';
import {Store} from '../src/store.js';
import {createOrderRoomGuard,removeExpiredOrderRoom} from '../src/order-room.js';

test('room cleanup removes only expired orders and preserves the record for a late slip',async t=>{
 let now = 100000;
 const store = new Store(':memory:',()=>now);
 t.after(()=>store.close());
 const product = store.addProduct('Test','',100);
 store.addStock(product,'item-a');
 store.addStock(product,'item-b');
 const expired = store.reserve('A',product,'',1);
 const review = store.reserve('B',product,'',1);
 for (const order of [expired,review]) {
  store.run("UPDATE orders SET method='promptpay',channel_id=?,message_id='old' WHERE id=?",`room-${order.id}`,order.id);
 }
 store.submit(review.id,'B','proof');
 now += 61000;
 store.tx(()=>store.expire());

 const deleted = [];
 const fetchRoom = async id=>({guildId:'shop',name:`order-${expired.id}`,type:ChannelType.GuildText,delete:async()=>deleted.push(id)});
 assert.equal(await removeExpiredOrderRoom(store,review.id,'shop',fetchRoom),false);
 assert.equal(await removeExpiredOrderRoom(store,expired.id,'shop',fetchRoom),true);
 assert.deepEqual(deleted,[`room-${expired.id}`]);
 assert.equal(store.order(expired.id).channel_id,null);
 assert.equal(store.order(expired.id).status,'expired');
 assert.equal(store.order(review.id).status,'review');
 assert.equal(store.submit(expired.id,'A','new proof'),'late_review');
});

test('a concurrent room cleanup cannot run during a proof submission',async()=>{
 const guard = createOrderRoomGuard();
 let finish;
 const first = guard.run(7,()=>new Promise(resolve=>{finish=resolve;}));
 assert.equal(guard.isBusy(7),true);
 await assert.rejects(guard.run(7,async()=>{}),/กำลังจัดการห้อง/);
 finish();
 await first;
 assert.equal(guard.isBusy(7),false);
 assert.equal(await guard.run(7,async()=>true),true);
});
