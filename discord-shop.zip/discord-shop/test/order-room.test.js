import assert from 'node:assert/strict';
import {test} from 'node:test';
import {ChannelType} from 'discord.js';
import {Store,paymentGraceMs} from '../src/store.js';
import {createOrderRoomGuard,removeFinishedOrderRoom} from '../src/order-room.js';

test('room cleanup waits two minutes after expiry and preserves orders under review',async t=>{
 let now = 100000;
 const store = new Store(':memory:',()=>now);
 t.after(()=>store.close());
 const product = store.addProduct('Test','',100);
 store.addStock(product,'item-a');
 store.addStock(product,'item-b');
 const expired = store.reserve('A',product,'',1);
 const review = store.reserve('B',product,'',1);
 for (const order of [expired,review]) {
  store.run("UPDATE orders SET method='promptpay',channel_id=?,message_id='old' WHERE id=?",`room-${order.id}`,order.id);
 }
 store.submit(review.id,'B','proof');
 now += 61000;
 store.tx(()=>store.expire());

 const deleted = [];
 const fetchRoom = async id=>({guildId:'shop',name:`order-${expired.id}`,type:ChannelType.GuildText,delete:async()=>deleted.push(id)});
 assert.equal(await removeFinishedOrderRoom(store,review.id,'shop',fetchRoom),false);
 assert.equal(await removeFinishedOrderRoom(store,expired.id,'shop',fetchRoom),false);
 now = expired.expires + paymentGraceMs + 120000;
 store.tx(()=>store.expire());
 assert.equal(await removeFinishedOrderRoom(store,expired.id,'shop',fetchRoom),true);
 assert.deepEqual(deleted,[`room-${expired.id}`]);
 assert.equal(store.order(expired.id).channel_id,null);
 assert.equal(store.order(expired.id).status,'expired');
 assert.equal(store.order(review.id).status,'review');
 assert.equal(store.submit(expired.id,'A','new proof'),'late_review');
});

test('a concurrent room cleanup cannot run during a proof submission',async()=>{
 const guard = createOrderRoomGuard();
 let finish;
 const first = guard.run(7,()=>new Promise(resolve=>{finish=resolve;}));
 assert.equal(guard.isBusy(7),true);
 await assert.rejects(guard.run(7,async()=>{}),/กำลังจัดการห้อง/);
 finish();
 await first;
 assert.equal(guard.isBusy(7),false);
 assert.equal(await guard.run(7,async()=>true),true);
});

test('manual cleanup cancels unpaid rooms without a payment method and clears legacy finished rooms',async t=>{
 const store = new Store(':memory:',()=>100000);
 t.after(()=>store.close());
 const product = store.addProduct('Test','',100);
 const makeOrder = user=>{
  store.addStock(product,`item-${user}`);
  const order = store.reserve(user,product,'');
  store.run('UPDATE orders SET channel_id=? WHERE id=?',String(order.id),order.id);
  return order;
 };
 const unstarted = makeOrder('A');
 const awaitingSlip = makeOrder('B');
 const finished = makeOrder('C');
 const review = makeOrder('D');
 for (const order of [awaitingSlip,finished,review]) {
  store.run("UPDATE orders SET method='promptpay' WHERE id=?",order.id);
 }
 store.submit(finished.id,'C','proof');
 store.approve(finished.id,'admin','LEGACY-1');
 store.run("UPDATE orders SET status='delivered' WHERE id=?",finished.id);
 store.submit(review.id,'D','proof');
 const preview = store.roomsForAdminCleanup();
 assert.deepEqual(preview.map(room=>room.id),[unstarted.id,finished.id]);
 const deleted = [];
 const fetch = async id=>({guildId:'shop',type:ChannelType.GuildText,name:`order-${id}`,delete:async()=>deleted.push(id)});
 for (const room of preview) {
  assert.equal(await removeFinishedOrderRoom(store,room.id,'shop',fetch,{...room,adminId:'admin'}),true);
 }
 assert.deepEqual(deleted,[String(unstarted.id),String(finished.id)]);
 assert.equal(store.order(unstarted.id).status,'cancelled');
 assert.equal(store.order(unstarted.id).admin_id,'admin');
 assert.equal(store.products()[0].remaining,1);
 assert.equal(store.order(finished.id).channel_id,null);
 assert.equal(store.paidStock(finished.id,'C').content,'item-C');
 assert.equal(store.order(awaitingSlip.id).status,'pending');
 assert.equal(store.order(review.id).status,'review');
});

test('manual cleanup skips an order if the customer chooses a payment method after preview',async t=>{
 const store = new Store(':memory:',()=>100000);
 t.after(()=>store.close());
 const product = store.addProduct('Test','',100);
 store.addStock(product,'item');
 const order = store.reserve('A',product,'');
 store.run("UPDATE orders SET channel_id='room' WHERE id=?",order.id);
 const [room] = store.roomsForAdminCleanup();
 const fetch = async()=>{
  store.run("UPDATE orders SET method='promptpay' WHERE id=?",order.id);
  return {guildId:'shop',type:ChannelType.GuildText,name:`order-${order.id}`,delete:()=>assert.fail('must keep room')};
 };
 assert.equal(await removeFinishedOrderRoom(store,room.id,'shop',fetch,{...room,adminId:'admin'}),false);
 assert.equal(store.order(order.id).status,'pending');
 assert.equal(store.products()[0].remaining,0);
});

test('a failed manual deletion leaves the cancelled room available for cleanup without releasing stock twice',async t=>{
 const store = new Store(':memory:',()=>100000);
 t.after(()=>store.close());
 const product = store.addProduct('Test','',100);
 store.addStock(product,'item');
 const order = store.reserve('A',product,'');
 store.run("UPDATE orders SET channel_id='room' WHERE id=?",order.id);
 const room = {guildId:'shop',type:ChannelType.GuildText,name:`order-${order.id}`};
 let [preview] = store.roomsForAdminCleanup();
 await assert.rejects(removeFinishedOrderRoom(store,order.id,'shop',
  async()=>({...room,delete:async()=>{throw Error('failed');}}),{...preview,adminId:'admin'}),/failed/);
 assert.equal(store.order(order.id).status,'cancelled');
 assert.equal(store.order(order.id).channel_id,'room');
 const next = store.reserve('B',product,'');
 [preview] = store.roomsForAdminCleanup();
 assert.equal(await removeFinishedOrderRoom(store,order.id,'shop',
  async()=>({...room,delete:async()=>{}}),{...preview,adminId:'admin'}),true);
 assert.equal(store.order(next.id).status,'pending');
 assert.equal(store.products()[0].remaining,0);
});
