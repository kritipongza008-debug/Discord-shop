import assert from 'node:assert/strict';
import {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {test} from 'node:test';
import {catalogPayload, productPayload} from '../src/catalog.js';
import {Store} from '../src/store.js';
import {MessageFlags} from 'discord.js';

const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jkJQAAAAASUVORK5CYII=', 'base64');

test('catalog uses stored images after reopening and keeps additional pages private', t => {
 const dir = mkdtempSync(join(tmpdir(), 'shop-catalog-'));
 t.after(() => rmSync(dir, {recursive:true, force:true}));
 const path = join(dir, 'shop.sqlite');
 let store = new Store(path);
 const first = store.addProduct('ชิ้นแรก', 'คำอธิบาย', 9900);
 store.setProductImage(first, {extension: 'png', bytes: png});
 for (let i=2; i<=5; i++) store.addProduct(`สินค้า ${i}`, '', 1000);
 store.close();
 store = new Store(path);
 try {
  const publicPage = catalogPayload(store);
  assert.equal(publicPage.flags, MessageFlags.IsComponentsV2);
  const components = publicPage.components[0].toJSON().components;
  const productRows = components.filter(component => component.type === 9);
  assert.equal(productRows.length, 4);
  assert.match(productRows[0].components[0].content,/ชิ้นแรก/);
  assert.equal(productRows[0].accessory.media.url,`attachment://product-${first}.png`);
  assert.deepEqual(publicPage.files[0].attachment,png);
  assert.ok(components.some(component => component.components?.[0]?.custom_id === `catalog:product:${first}:0`));
  assert.ok(components.some(component=>component.components?.[0]?.custom_id==='catalog:open'));
  assert.deepEqual(components.at(-1).components.map(button=>button.custom_id),['catalog:orders','catalog:help']);

  const pageTwo = catalogPayload(store, 1, true);
  const nextComponents = pageTwo.components[0].toJSON().components;
  assert.equal(nextComponents.filter(component=>component.type===9).length,1);
  assert.match(nextComponents.find(component=>component.type===9).components[0].content,/สินค้า 5/);
  assert.equal(nextComponents.find(component=>component.components?.[0]?.custom_id==='catalog:page:0').components[1].disabled,true);
  assert.equal(pageTwo.files.length,0);

  const details = productPayload(store,store.products()[0]);
  const detailsComponents = details.components[0].toJSON().components;
  assert.equal(detailsComponents.find(component=>component.type===12).items[0].media.url,`attachment://product-${first}.png`);
  assert.equal(detailsComponents.at(-1).components[0].disabled,true);
  assert.equal(detailsComponents.at(-1).components[1].custom_id,'catalog:page:0');
 } finally {
  store.close();
 }
});

