import assert from 'node:assert/strict';
import {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {test} from 'node:test';
import {catalogPayload, productPayload} from '../src/catalog.js';
import {Store} from '../src/store.js';
import {MessageFlags} from 'discord.js';

const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jkJQAAAAASUVORK5CYII=', 'base64');

test('catalog uses stored images after reopening and keeps additional pages private', t => {
 const dir = mkdtempSync(join(tmpdir(), 'shop-catalog-'));
 t.after(() => rmSync(dir, {recursive:true, force:true}));
 const path = join(dir, 'shop.sqlite');
 let store = new Store(path);
 const first = store.addProduct('ชิ้นแรก', 'คำอธิบาย', 9900);
 store.setProductImage(first, {extension: 'png', bytes: png});
 for (let i=2; i<=5; i++) store.addProduct(`สินค้า ${i}`, '', 1000);
 store.close();
 store = new Store(path);
 try {
  const publicPage = catalogPayload(store);
  assert.equal(publicPage.flags, MessageFlags.IsComponentsV2);
  const components = publicPage.components[0].toJSON().components;
  const productRows = components.filter(component => component.type === 9);
  assert.equal(productRows.length, 4);
  assert.match(productRows[0].components[0].content,/ชิ้นแรก/);
  assert.equal(productRows[0].accessory.media.url,`attachment://product-${first}.png`);
  assert.equal(publicPage.files[0].name,'racing-banner.webp');
  assert.deepEqual(publicPage.files[1].attachment,png);
  assert.ok(components.some(component => component.components?.[0]?.custom_id === `catalog:product:${first}:0`));
  assert.ok(components.some(component=>component.components?.[0]?.custom_id==='catalog:open'));
  assert.deepEqual(components.at(-1).components.map(button=>button.custom_id),['catalog:orders','catalog:help']);

  const pageTwo = catalogPayload(store, 1, true);
  const nextComponents = pageTwo.components[0].toJSON().components;
  assert.equal(nextComponents.filter(component=>component.type===9).length,1);
  assert.match(nextComponents.find(component=>component.type===9).components[0].content,/สินค้า 5/);
  assert.equal(nextComponents.find(component=>component.components?.[0]?.custom_id==='catalog:page:0').components[1].disabled,true);
  assert.equal(pageTwo.files.length,0);

  const details = productPayload(store,store.products()[0]);
  const detailsComponents = details.components[0].toJSON().components;
  assert.equal(detailsComponents.find(component=>component.type===12).items[0].media.url,`attachment://product-${first}.png`);
  assert.equal(detailsComponents.at(-1).components[0].disabled,true);
  assert.equal(detailsComponents.at(-1).components[1].custom_id,'catalog:page:0');
 } finally {
  store.close();
 }
});


test('sale price appears in the catalog and is quoted on the purchase button', t => {
 const store = new Store(':memory:');
 t.after(()=>store.close());
 const id = store.addProduct('สินค้าโปร','',9900);
 store.addStock(id,'test code');
 store.setSalePrice(id,7900);
 const catalog = catalogPayload(store).components[0].toJSON();
 const item = catalog.components.find(component=>component.type===9);
 assert.match(item.components[0].content,/\*\*79\.00 บาท\*\* · ~~99\.00 บาท~~/);
 const detail = productPayload(store,store.products()[0]).components[0].toJSON();
 assert.match(detail.components[0].content,/\*\*79\.00 บาท\*\* · ~~99\.00 บาท~~/);
 assert.equal(detail.components.at(-1).components[0].custom_id,`buyconfirm:${id}:7900`);
});

test('the catalog displays the sale deadline and normal pricing at expiry', t => {
 let now = 100000;
 const store = new Store(':memory:',()=>now);
 t.after(()=>store.close());
 const id = store.addProduct('สินค้าโปร','',9900);
 store.addStock(id,'test code');
 store.setSalePrice(id,7900,101000);
 const panelText = () => JSON.stringify(catalogPayload(store).components[0].toJSON());
 assert.match(panelText(),/จบโปร <t:101:R>/);
 now = 101000;
 assert.doesNotMatch(panelText(),/79\.00 บาท|จบโปร/);
 const detail = productPayload(store,store.products()[0]).components[0].toJSON();
 assert.equal(detail.components.at(-1).components[0].custom_id,`buyconfirm:${id}:9900`);
});

test('product details offer restock follow only when sold out and support cancellation',t=>{
 const store = new Store(':memory:');
 t.after(()=>store.close());
 const id = store.addProduct('สินค้า','',1000);
 const actions = following=>productPayload(store,store.products()[0],0,following)
  .components[0].toJSON().components.at(-1).components;
 assert.ok(actions(false).some(button=>button.custom_id===`catalog:restock:${id}:0:on`));
 assert.ok(actions(true).some(button=>button.custom_id===`catalog:restock:${id}:0:off`));
 store.addStock(id,'item');
 assert.ok(!actions(false).some(button=>button.custom_id.startsWith('catalog:restock')));
});

test('storefront filters in-stock and discounted products and preserves navigation',t=>{
 const store = new Store(':memory:',()=>100000);
 t.after(()=>store.close());
 const sale = store.addProduct('Sale','',1000);
 const ready = store.addProduct('Ready','',1000);
 store.addStock(ready,'code');
 store.setSalePrice(sale,900);
 const readySections = catalogPayload(store,0,true,'ready').components[0].toJSON().components.filter(c=>c.type===9);
 const saleSections = catalogPayload(store,0,true,'sale').components[0].toJSON().components.filter(c=>c.type===9);
 assert.deepEqual(readySections.map(c=>c.accessory.custom_id),[`catalog:product:${ready}:0:ready`]);
 assert.deepEqual(saleSections.map(c=>c.accessory.custom_id),[`catalog:product:${sale}:0:sale`]);
 const detail = productPayload(store,store.products()[0],0,false,'sale').components[0].toJSON();
 assert.equal(detail.components.at(-1).components[1].custom_id,'catalog:page:0:sale');
});

test('public catalog exposes paging and private pages keep navigation without uploading images',t=>{
 const store = new Store(':memory:');
 t.after(()=>store.close());
 for (let i=1;i<=5;i++) {
  const product = store.addProduct(`Item ${i}`,'',1000);
  store.setProductImage(product,{extension:'png',bytes:png});
 }
 const buttons = payload=>payload.components[0].toJSON().components.flatMap(component=>component.components ?? []);
 const publicPage = catalogPayload(store);
 const countComponents = component => 1
  + (component.components ?? []).reduce((total,child)=>total+countComponents(child),0)
  + (component.accessory ? countComponents(component.accessory) : 0);
 const publicComponents = publicPage.components.map(component=>component.toJSON());
 assert.ok(publicComponents.reduce((total,component)=>total+countComponents(component),0)<=40);
 assert.equal(publicPage.files.length,5);
 const publicNext = buttons(publicPage).find(component=>component.custom_id==='catalog:page:1');
 assert.equal(publicNext.disabled,false);
 const firstPrivate = catalogPayload(store,0,true);
 assert.deepEqual(firstPrivate.files,[]);
 assert.ok(buttons(firstPrivate).some(component=>component.custom_id==='catalog:page:1'));
 const lastPrivate = catalogPayload(store,1,true);
 assert.deepEqual(lastPrivate.files,[]);
 assert.ok(buttons(lastPrivate).some(component=>component.custom_id==='catalog:page:0'));
 assert.equal(buttons(lastPrivate).find(component=>component.custom_id==='catalog:page:2').disabled,true);
 assert.equal(productPayload(store,store.products()[4]).files.length,1);
});

test('search results page by matching names and closed shops disable buying',t=>{
 const store = new Store(':memory:');
 t.after(()=>store.close());
 const id = store.addProduct('Wave 125','',1000);
 store.addStock(id,'item');
 store.addProduct('Other','',1000);
 const payload = catalogPayload(store,0,true,'search-test','WAVE');
 const page = JSON.stringify(payload.components[0].toJSON());
 assert.match(page,/Wave 125/);
 assert.doesNotMatch(page,/Other/);
 assert.match(page,/catalog:product:\d+:0:search-test/);
 store.setPauseNotice('กลับมา 19:00','admin');
 assert.match(JSON.stringify(catalogPayload(store).components[0].toJSON()),/กลับมา 19:00/);
 const product = productPayload(store,store.products()[0]).components[0].toJSON();
 assert.equal(product.components.at(-1).components[0].disabled,true);
});
