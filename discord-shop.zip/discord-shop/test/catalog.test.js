import assert from 'node:assert/strict';
import {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {test} from 'node:test';
import {catalogPayload, downloadProductImage} from '../src/catalog.js';
import {Store} from '../src/store.js';

const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jkJQAAAAASUVORK5CYII=', 'base64');

test('catalog uses stored images after reopening and keeps additional pages private', t => {
 const dir = mkdtempSync(join(tmpdir(), 'shop-catalog-'));
 t.after(() => rmSync(dir, {recursive:true, force:true}));
 const path = join(dir, 'shop.sqlite');
 let store = new Store(path);
 const first = store.addProduct('ชิ้นแรก', 'คำอธิบาย', 9900);
 store.setProductImage(first, {extension: 'png', bytes: png});
 for (let i=2; i<=5; i++) store.addProduct(`สินค้า ${i}`, '', 1000);
 store.close();
 store = new Store(path);
 try {
  const publicPage = catalogPayload(store);
  assert.equal(publicPage.embeds.length, 4);
  assert.equal(publicPage.embeds[0].toJSON().title, 'ชิ้นแรก');
  assert.equal(publicPage.embeds[0].toJSON().thumbnail.url, `attachment://product-${first}.png`);
  assert.deepEqual(publicPage.files[0].attachment, png);
  assert.equal(publicPage.embeds[1].toJSON().thumbnail, undefined);
  assert.equal(publicPage.components[1].toJSON().components[0].custom_id, 'catalog:open');

  const pageTwo = catalogPayload(store, 1, true);
  assert.deepEqual(pageTwo.embeds.map(embed => embed.toJSON().title), ['สินค้า 5']);
  assert.equal(pageTwo.components[0].toJSON().components[0].options[0].label, 'สินค้า 5');
  assert.equal(pageTwo.components[1].toJSON().components[1].disabled, true);
  assert.equal(pageTwo.files.length, 0);
 } finally {
  store.close();
 }
});

test('unsupported files and non-Discord URLs cannot become catalog images', async () => {
 await assert.rejects(downloadProductImage({contentType:'image/heic', size:100}), /PNG/);
 await assert.rejects(downloadProductImage({contentType:'image/png', size:3*1024*1024}), /2 MB/);
 await assert.rejects(downloadProductImage({contentType:'image/png', size:100, url:'https://example.com/test.png'}), /Discord/);
});
